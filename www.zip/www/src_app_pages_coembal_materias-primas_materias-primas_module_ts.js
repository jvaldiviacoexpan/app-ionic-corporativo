"use strict";
(self["webpackChunkapp_ionic_corporativo"] = self["webpackChunkapp_ionic_corporativo"] || []).push([["src_app_pages_coembal_materias-primas_materias-primas_module_ts"],{

/***/ 97838:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/materias-primas/etq-ent-materias-primas/etq-ent-materias-primas.component.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtqEntMateriasPrimasComponent": () => (/* binding */ EtqEntMateriasPrimasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_etq_ent_materias_primas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./etq-ent-materias-primas.component.html */ 61391);
/* harmony import */ var _etq_ent_materias_primas_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./etq-ent-materias-primas.component.scss */ 62017);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/providers/internal/cxp.service */ 1743);
/* harmony import */ var _models_anymodels_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../models/anymodels.model */ 58301);







let EtqEntMateriasPrimasComponent = class EtqEntMateriasPrimasComponent {
    constructor(menu, cxpService, toastController, alertController) {
        this.menu = menu;
        this.cxpService = cxpService;
        this.toastController = toastController;
        this.alertController = alertController;
        this.ocRows = [];
    }
    ngOnInit() {
        // this.buscarNumeroCarpeta('CXMP-PRUEBA');
    }
    menuToogle() {
        this.menu.toggle();
    }
    buscarNumeroCarpeta(ncarpeta) {
        if (!localStorage.getItem('sapusr')) {
            this.presentToast('Inicie sesión en Sap Business One para Continuar.', 5000, 'warning');
            return;
        }
        this.ocRows = [];
        this.loadSkeleton = true;
        const info = {
            login: localStorage.getItem('sapusr'),
            doc: ncarpeta.trim()
        };
        this.cxpService.obtenerInformacionOc(info).then((data) => {
            if (data.Status.Status !== 'T') {
                this.presentToast(data.Status.Message, 5000, 'primary');
            }
            else {
                this.ocRows = data.Objeto;
                this.proveedor = data.Objeto[0].H_CardName;
                this.area = data.Objeto[0].H_U_AREA === '0' ? 'Sin Area' : data.Objeto[0].H_U_AREA;
            }
        }, (err) => {
            console.warn(err);
        })
            .finally(() => {
            this.loadSkeleton = false;
        });
    }
    alertaConfirmarEtiqueta(oc) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            console.log(oc);
            if (!localStorage.getItem('ipimp')) {
                this.presentToast('Seleccione una impresora antes de continuar.', 2000, 'warning');
                return;
            }
            const alert = yield this.alertController.create({
                header: 'Emisión de Etiquetas',
                message: 'Ingrese la <strong>Cantidad de Pallets</strong> y el Peso del Pallet. ',
                inputs: [
                    {
                        name: 'cantEtqs',
                        type: 'number',
                        min: 1, max: 50,
                        cssClass: '',
                        placeholder: 'Cantidad Etiquetas'
                    },
                    {
                        name: 'pesoPallet',
                        type: 'number',
                        min: 1, max: 10000,
                        cssClass: '',
                        placeholder: 'Cantidad/Peso'
                    }
                ],
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            // console.log('Confirm Cancel.');
                        }
                    },
                    {
                        text: 'Enviar',
                        cssClass: 'btnAlertSuccess',
                        handler: (data) => {
                            const usr = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_3__.TstUser();
                            usr.docNum = Number(oc.H_DocNum);
                            usr.cantEtq = data.cantEtqs;
                            oc.B_PesoPallet = data.pesoPallet.toString();
                            usr.numAtCard = oc.H_NumAtCard;
                            usr.usuario = 'jordan.valdivia@coexpan.cl';
                            usr.fecha = '.';
                            this.alertaVeriricarEmisionEtiquetas(usr, oc);
                            // console.log(`Cantidad: ${data.cantPallets}`);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    alertaVeriricarEmisionEtiquetas(usr, oc) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirmación Envío',
                message: `Se enviarán <strong>${usr.cantEtq} Etiquetas.</strong><hr>¿Desea Continuar?`,
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            // console.log('Confirm Cancel.');
                        }
                    }, {
                        text: 'Si, confirmar',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            this.enviarEtiquetasServicio(usr, oc);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    enviarEtiquetasServicio(us, oc) {
        const emision = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_3__.EmisionEtiquetaMpModel();
        const dat = this.generarObjetoDatos(oc);
        const imp = this.generarObjetoParamzebra();
        emision.datos = dat;
        emision.tstUser = us;
        emision.paramZebra = imp;
        this.cxpService.emisionEtiquetasMateriasPrimas(emision).then((data) => {
            // console.log(data);
            if (data.Status === 'T') {
                this.presentToast(data.Message, 5000, 'success');
            }
            else {
                this.presentToast(`${data.Message}: ${data.Message_Exception_Descr}`, 5000, 'danger');
            }
        }, (err) => {
            console.warn(err);
        });
    }
    generarObjetoDatos(oc) {
        const dat = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_3__.Datos();
        dat.bAcctCode = oc.B_AcctCode;
        dat.bCurrency = oc.B_Currency;
        dat.bDscription = oc.B_Dscription;
        dat.bItemCode = oc.B_ItemCode;
        dat.bLineTotal = Number(oc.B_LineTotal.replace(',', '.'));
        dat.bOcrCode = oc.B_OcrCode;
        dat.bQuantity = Number(oc.B_Quantity.replace(',', '.'));
        dat.bRate = Number(oc.B_Rate.replace(',', '.'));
        dat.bUomEntry = Number(oc.B_UomEntry);
        dat.bWhsCode = oc.B_WhsCode;
        dat.hCardCode = oc.H_CardCode;
        dat.hCardName = oc.H_CardName;
        dat.hComments = oc.H_Comments;
        dat.hDocCur = oc.H_DocCur;
        dat.hDocDate = oc.H_DocDate;
        dat.hDocNum = Number(oc.H_DocNum);
        dat.hDocRate = Number(oc.H_DocRate.replace(',', '.'));
        dat.hDocStatus = oc.H_DocStatus;
        dat.hDocTotal = Number(oc.H_DocTotal.replace(',', '.'));
        dat.hDocTotalFc = Number(oc.H_DocTotalFC.replace(',', '.'));
        dat.hJrnlMemo = oc.H_JrnlMemo;
        dat.hNumAtCard = oc.H_NumAtCard;
        dat.hRef1 = Number(oc.H_Ref1);
        dat.huArea = oc.H_U_AREA;
        dat.huClausulas = oc.H_U_CLAUSULAS;
        dat.hunCarpeta = oc.H_U_N_CARPETA;
        dat.huTipo = oc.H_U_TIPO;
        dat.bPrice = Number(oc.B_Price.replace(',', '.'));
        dat.bTotalFrgn = Number(oc.B_TotalFrgn.trim().replace(',', '.'));
        dat.bPesoPallet = Number(oc.B_PesoPallet.trim().replace(',', '.'));
        return dat;
    }
    generarObjetoParamzebra() {
        const p = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_3__.ParamZebra();
        p.ip = localStorage.getItem('ipimp');
        return p;
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
};
EtqEntMateriasPrimasComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: src_providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController }
];
EtqEntMateriasPrimasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-ent-materias-primas',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_etq_ent_materias_primas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_etq_ent_materias_primas_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], EtqEntMateriasPrimasComponent);



/***/ }),

/***/ 93981:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/coembal/materias-primas/materias-primas-routing.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MateriasPrimasRoutingModule": () => (/* binding */ MateriasPrimasRoutingModule),
/* harmony export */   "materiasPrimasRouterComponents": () => (/* binding */ materiasPrimasRouterComponents)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _materias_primas_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./materias-primas.component */ 52394);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _etq_ent_materias_primas_etq_ent_materias_primas_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./etq-ent-materias-primas/etq-ent-materias-primas.component */ 97838);
/* harmony import */ var _menu_materias_primas_menu_materias_primas_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./menu-materias-primas/menu-materias-primas.component */ 1596);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);







const routes = [{
        path: '',
        component: _materias_primas_component__WEBPACK_IMPORTED_MODULE_0__.MateriasPrimasComponent,
        children: [
            {
                path: 'menu',
                component: _menu_materias_primas_menu_materias_primas_component__WEBPACK_IMPORTED_MODULE_2__.MenuMateriasPrimasComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_3__.AuthGuard],
            },
            {
                path: 'etiqueta',
                component: _etq_ent_materias_primas_etq_ent_materias_primas_component__WEBPACK_IMPORTED_MODULE_1__.EtqEntMateriasPrimasComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_3__.AuthGuard],
            }
        ]
    }];
let MateriasPrimasRoutingModule = class MateriasPrimasRoutingModule {
};
MateriasPrimasRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule]
    })
], MateriasPrimasRoutingModule);

const materiasPrimasRouterComponents = [
    _materias_primas_component__WEBPACK_IMPORTED_MODULE_0__.MateriasPrimasComponent,
    _etq_ent_materias_primas_etq_ent_materias_primas_component__WEBPACK_IMPORTED_MODULE_1__.EtqEntMateriasPrimasComponent,
    _menu_materias_primas_menu_materias_primas_component__WEBPACK_IMPORTED_MODULE_2__.MenuMateriasPrimasComponent
];


/***/ }),

/***/ 52394:
/*!****************************************************************************!*\
  !*** ./src/app/pages/coembal/materias-primas/materias-primas.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MateriasPrimasComponent": () => (/* binding */ MateriasPrimasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


let MateriasPrimasComponent = class MateriasPrimasComponent {
    constructor() {
    }
    ngOnInit() {
    }
};
MateriasPrimasComponent.ctorParameters = () => [];
MateriasPrimasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'app-materias-primas',
        template: '<ion-router-outlet></ion-router-outlet>',
    })
], MateriasPrimasComponent);



/***/ }),

/***/ 11947:
/*!*************************************************************************!*\
  !*** ./src/app/pages/coembal/materias-primas/materias-primas.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MateriasPrimasModule": () => (/* binding */ MateriasPrimasModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ionic-selectable */ 74068);
/* harmony import */ var _materias_primas_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./materias-primas-routing.module */ 93981);







let MateriasPrimasModule = class MateriasPrimasModule {
};
MateriasPrimasModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _materias_primas_routing_module__WEBPACK_IMPORTED_MODULE_0__.MateriasPrimasRoutingModule
        ],
        declarations: [
            ..._materias_primas_routing_module__WEBPACK_IMPORTED_MODULE_0__.materiasPrimasRouterComponents,
        ]
    })
], MateriasPrimasModule);



/***/ }),

/***/ 1596:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/coembal/materias-primas/menu-materias-primas/menu-materias-primas.component.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuMateriasPrimasComponent": () => (/* binding */ MenuMateriasPrimasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_menu_materias_primas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./menu-materias-primas.component.html */ 38558);
/* harmony import */ var _menu_materias_primas_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu-materias-primas.component.scss */ 14515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/security.service */ 46691);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);











let MenuMateriasPrimasComponent = class MenuMateriasPrimasComponent {
    constructor(menu, route, auth, auth0Serv, securityService, toolService) {
        this.menu = menu;
        this.route = route;
        this.auth = auth;
        this.auth0Serv = auth0Serv;
        this.securityService = securityService;
        this.toolService = toolService;
        this.enabled = {
            mpr01: false,
            mpr02: false,
        };
        this.showThisContent$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject({});
    }
    ngOnInit() { }
    ngAfterViewInit() {
        this.toolService.simpleLoader('Cargando...');
        this.obtenerRoles();
    }
    irEmisionPallet() {
        this.route.navigateByUrl('/pages/materias-primas/etiqueta');
    }
    menuToogle() {
        this.menu.toggle();
    }
    obtenerRoles() {
        this.auth.user$.subscribe((user) => {
            this.auth0Serv.getAuth().then((resp) => {
                const userdata = {
                    idToken: resp.access_token,
                    idUser: user.sub,
                };
                const datarest = this.securityService.encrypt(JSON.stringify(userdata));
                this.auth0Serv.getUserRoles(datarest).then((restuser) => {
                    this.showThisContent$.next({ datauser: restuser.app_metadata.roles });
                    this.habilitarModulos();
                }, (err) => {
                    // Todo Falta informacion adicional
                });
            }, (err) => {
                // Todo Falta informacion adicional
            }).finally(() => this.toolService.dismissLoader());
        });
    }
    habilitarModulos() {
        const mpr01 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'mpr01' && el.enabled === true);
        const mpr02 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'mpr02' && el.enabled === true);
        if (mpr01 !== undefined) {
            this.enabled.mpr01 = true;
        }
        if (mpr02 !== undefined) {
            this.enabled.mpr02 = true;
        }
    }
};
MenuMateriasPrimasComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__.AuthService },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__.SecurityService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__.ToolService }
];
MenuMateriasPrimasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-menu-materias-primas',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_menu_materias_primas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_menu_materias_primas_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MenuMateriasPrimasComponent);



/***/ }),

/***/ 61391:
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/materias-primas/etq-ent-materias-primas/etq-ent-materias-primas.component.html ***!
  \*****************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-grid fixed>\n      <ion-row class=\"ion-align-items-center ion-header-row\">\n        <ion-col size=\"2\">\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\n            <ion-icon name=\"menu-outline\"></ion-icon>\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"10\" class=\"ion-text-left\">\n          <ion-title>Etiq. Materias Primas</ion-title>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"background-image\">\n  <ion-grid fixed>\n    <ion-row class=\"ion-align-items-center ion-header-row\">\n      <ion-col size=\"10\">\n        <ion-item>\n          <ion-label position=\"floating\">N° de Carpeta</ion-label>\n          <ion-input type=\"text\" #numCarpeta\n          (keyup.enter)=\"buscarNumeroCarpeta(numCarpeta.value.toString())\">\n          </ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"2\">\n        <ion-item button lines=\"none\"\n        (click)=\"buscarNumeroCarpeta(numCarpeta.value.toString())\">\n          <ion-icon color=\"dark\" name=\"search-outline\"></ion-icon>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <ion-grid *ngIf=\"loadSkeleton\" fixed>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card>\n          <ion-card-header>\n            <ion-skeleton-text animated style=\"width: 70%\"></ion-skeleton-text>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </ion-card-header>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card>\n          <ion-card-header>\n            <ion-skeleton-text animated style=\"width: 30%\"></ion-skeleton-text>\n            <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n          </ion-card-header>\n          <ion-card-content>\n            <ion-grid fixed>\n              <ion-row class=\"ion-justify-content-center\">\n                <ion-col size=\"10\">\n                  <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-card-content>\n          <ion-grid fixed>\n          </ion-grid>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <ion-grid fixed *ngIf=\"ocRows.length > 0\" >\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-subtitle>Area: <strong>{{area}}</strong></ion-card-subtitle>\n            <ion-card-subtitle>Prov: <strong>{{proveedor}}</strong></ion-card-subtitle>\n          </ion-card-header>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"12\" *ngFor=\"let row of ocRows\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-subtitle>Código: <strong>{{row['B_ItemCode']}}</strong></ion-card-subtitle>\n            <ion-card-title>{{row['B_Dscription']}}</ion-card-title>\n          </ion-card-header>\n          <ion-grid fixed>\n            <ion-row class=\"ion-justify-content-center\">\n              <ion-col size=\"10\">\n                <ion-button expand=\"block\" color=\"success\" (click)=\"alertaConfirmarEtiqueta(row)\">\n                  Seleccionar\n                </ion-button>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n          <ion-card-content>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ 38558:
/*!***********************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/materias-primas/menu-materias-primas/menu-materias-primas.component.html ***!
  \***********************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title color=\"medium\"><strong>Menu Materias Primas</strong></ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content class=\"background-image\">\r\n  <ion-grid>\r\n    <ion-row class=\"ion-margin-top\">\r\n      <ion-col size=\"12\" *ngIf=\"enabled.mpr01 || enabled.mpr02\">\r\n        <ion-label color=\"medium\"><strong>Gestión Etiquetas</strong></ion-label>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"ion-justify-content-start\">\r\n      <ion-col size=\"6\" *ngIf=\"enabled.mpr01\">\r\n        <ion-button class=\"btn-color-cxp\" size=\"large\"  expand=\"block\" (click)=\"irEmisionPallet()\">\r\n          <span class=\"btn-text\">Emisión Etiqueta</span>\r\n        </ion-button>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"6\" *ngIf=\"enabled.mpr02\">\r\n        <ion-button class=\"btn-color-cxp\" size=\"large\" expand=\"block\" disabled=\"false\">\r\n          <ion-grid>\r\n            <ion-row class=\"ion-no-margin ion-no-padding\">\r\n              <ion-col>\r\n                <span class=\"btn-text\">Re-Imprimir Etiqueta</span><br>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col>\r\n                <span class=\"btn-text\">(Disabled)</span><br>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n\r\n");

/***/ }),

/***/ 62017:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/materias-primas/etq-ent-materias-primas/etq-ent-materias-primas.component.scss ***!
  \**************************************************************************************************************/
/***/ ((module) => {

module.exports = ".background-image {\n  --background: url('background-login.png') 0 0/100% 100% no-repeat;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV0cS1lbnQtbWF0ZXJpYXMtcHJpbWFzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksaUVBQUE7QUFBSiIsImZpbGUiOiJldHEtZW50LW1hdGVyaWFzLXByaW1hcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uYmFja2dyb3VuZC1pbWFnZXtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKCcuLi8uLi8uLi8uLi8uLi9hc3NldHMvaW1nL2xvZ2luL2JhY2tncm91bmQtbG9naW4ucG5nJykgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XHJcbn1cclxuXHJcblxyXG4iXX0= */";

/***/ }),

/***/ 14515:
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/coembal/materias-primas/menu-materias-primas/menu-materias-primas.component.scss ***!
  \********************************************************************************************************/
/***/ ((module) => {

module.exports = ".background-image {\n  --background: url('background-login.png') 0 0/100% 100% no-repeat;\n}\n\n.ion-header-row {\n  padding-left: 0px;\n}\n\n.btn-text {\n  font-size: 0.6em;\n  font-weight: bold;\n  color: #797979;\n}\n\n.btn-prop {\n  --background: #8d8f050b;\n}\n\n.row {\n  margin-top: 2em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnUtbWF0ZXJpYXMtcHJpbWFzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksaUVBQUE7QUFBSjs7QUFHQTtFQUNFLGlCQUFBO0FBQUY7O0FBR0E7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQUFGOztBQUdBO0VBQ0UsdUJBQUE7QUFBRjs7QUFHQTtFQUNFLGVBQUE7QUFBRiIsImZpbGUiOiJtZW51LW1hdGVyaWFzLXByaW1hcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uYmFja2dyb3VuZC1pbWFnZXtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKCcuLi8uLi8uLi8uLi8uLi9hc3NldHMvaW1nL2xvZ2luL2JhY2tncm91bmQtbG9naW4ucG5nJykgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XHJcbn1cclxuXHJcbi5pb24taGVhZGVyLXJvdyB7XHJcbiAgcGFkZGluZy1sZWZ0OiAwcHg7XHJcbn1cclxuXHJcbi5idG4tdGV4dCB7XHJcbiAgZm9udC1zaXplOiAwLjZlbTtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBjb2xvcjogcmdiKDEyMSwgMTIxLCAxMjEpO1xyXG59XHJcblxyXG4uYnRuLXByb3Age1xyXG4gIC0tYmFja2dyb3VuZDogIzhkOGYwNTBiO1xyXG59XHJcblxyXG4ucm93IHtcclxuICBtYXJnaW4tdG9wOiAyZW07XHJcbn1cclxuXHJcbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coembal_materias-primas_materias-primas_module_ts.js.map