"use strict";
(self["webpackChunkapp_ionic_corporativo"] = self["webpackChunkapp_ionic_corporativo"] || []).push([["src_app_pages_root_root_module_ts"],{

/***/ 26129:
/*!*********************************************************************!*\
  !*** ./src/app/pages/root/configuracion/configuracion.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfiguracionComponent": () => (/* binding */ ConfiguracionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 71258);



let ConfiguracionComponent = class ConfiguracionComponent {
    constructor(route) {
        this.route = route;
    }
    ngOnInit() {
        console.log('Componente inicializado');
        // console.log(user);
    }
};
ConfiguracionComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_0__.Router }
];
ConfiguracionComponent.propDecorators = {
    user: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input }]
};
ConfiguracionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'app-configuracion',
        template: '<ion-router-outlet></ion-router-outlet>'
    })
], ConfiguracionComponent);



/***/ }),

/***/ 10761:
/*!*****************************************************!*\
  !*** ./src/app/pages/root/login/login.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_login_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./login.component.html */ 58306);
/* harmony import */ var _login_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.component.scss */ 40551);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);







let LoginComponent = class LoginComponent {
    constructor(route, auth) {
        this.route = route;
        this.auth = auth;
        // eslint-disable-next-line max-len
        // public oauth2 = 'https://login.microsoftonline.com/98f040fe-7e06-4d87-95ab-dc04af2c44ec/oauth2/authorize?client_id=433dd8a8-1973-4979-89dc-275bf5851afd&response_type=token&redirect_uri=http%3A%2F%2Flocalhost%2F&resource=40662057-6321-44ec-bdf6-8bd32c44eaf2&response_mode=fragment&state=12345&nonce=678910&sso_reload=true';
        this.profileJson = '';
    }
    ngOnInit() {
    }
    navInicio() {
        this.route.navigateByUrl('/pages/root/inicio');
        // console.log('se hizo click!');
    }
    login() {
        this.auth.loginWithRedirect({
            // eslint-disable-next-line @typescript-eslint/naming-convention
            redirect_uri: `${src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.urlBase}/#/pages/root/inicio`,
        });
    }
};
LoginComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_4__.AuthService }
];
LoginComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-login',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_login_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_login_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginComponent);



/***/ }),

/***/ 9422:
/*!*********************************************************************!*\
  !*** ./src/app/pages/root/main-menu-cmb/main-menu-cmb.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainMenuCmbComponent": () => (/* binding */ MainMenuCmbComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_main_menu_cmb_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./main-menu-cmb.component.html */ 10019);
/* harmony import */ var _main_menu_cmb_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main-menu-cmb.component.scss */ 65425);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../providers/external/security.service */ 46691);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 76491);










let MainMenuCmbComponent = class MainMenuCmbComponent {
    constructor(router, auth, menu, auth0Serv, securityService) {
        this.router = router;
        this.auth = auth;
        this.menu = menu;
        this.auth0Serv = auth0Serv;
        this.securityService = securityService;
        this.modulos = {
            logistica: false,
            extrusion: false,
            loading: true,
        };
        this.showThisContent$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.BehaviorSubject({});
        this.authRoles$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.BehaviorSubject({});
    }
    ngAfterViewInit() {
        this.obtenerRoles();
    }
    menuToogle() {
        this.menu.toggle();
    }
    navMenuLogistica() {
        this.router.navigateByUrl('/pages/cmb/logistica/menu-logistica');
    }
    navMenuExtrusion() {
        this.router.navigateByUrl('/pages/cmb/extrusion/menu-extrusion');
    }
    obtenerRoles() {
        this.auth.user$.subscribe((user) => {
            this.auth0Serv.getAuth().then((resp) => {
                const userdata = {
                    idToken: resp.access_token,
                    idUser: user.sub,
                };
                const datarest = this.securityService.encrypt(JSON.stringify(userdata));
                this.auth0Serv.getUserRoles(datarest).then((restuser) => {
                    this.showThisContent$.next({ datauser: restuser.app_metadata.roles });
                    this.habilitarModulos();
                }, (err) => {
                });
            }, (err) => {
            }).finally(() => this.modulos.loading = false);
        });
    }
    habilitarModulos() {
        const foundExtrusion = this.showThisContent$.value.datauser.find((el) => el.zone === 'extrusion' && el.business === 'cmb');
        const foundLogistica = this.showThisContent$.value.datauser.find((el) => el.zone === 'logistica' && el.business === 'cmb');
        if (foundExtrusion !== undefined) {
            this.modulos.extrusion = true;
        }
        if (foundLogistica !== undefined) {
            this.modulos.logistica = true;
        }
    }
};
MainMenuCmbComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__.SecurityService }
];
MainMenuCmbComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-main-menu-cmb',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_main_menu_cmb_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_main_menu_cmb_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MainMenuCmbComponent);



/***/ }),

/***/ 78397:
/*!*********************************************************************!*\
  !*** ./src/app/pages/root/main-menu-cxp/main-menu-cxp.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainMenuCxpComponent": () => (/* binding */ MainMenuCxpComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_main_menu_cxp_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./main-menu-cxp.component.html */ 84808);
/* harmony import */ var _main_menu_cxp_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./main-menu-cxp.component.scss */ 91778);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../providers/external/security.service */ 46691);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 76491);










let MainMenuCxpComponent = class MainMenuCxpComponent {
    constructor(route, auth, menu, auth0Serv, securityService) {
        this.route = route;
        this.auth = auth;
        this.menu = menu;
        this.auth0Serv = auth0Serv;
        this.securityService = securityService;
        this.modulos = {
            logistica: false,
            extrusion: false,
            rrhh: false,
            finanzas: false,
            loading: true,
        };
        this.showThisContent$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.BehaviorSubject({});
        this.authRoles$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.BehaviorSubject({});
    }
    ngOnInit() { }
    ngAfterViewInit() {
        this.obtenerRoles();
    }
    obtenerRoles() {
        this.auth.user$.subscribe((user) => {
            this.auth0Serv.getAuth().then((resp) => {
                const userdata = {
                    idToken: resp.access_token,
                    idUser: user.sub,
                };
                const datarest = this.securityService.encrypt(JSON.stringify(userdata));
                this.auth0Serv.getUserRoles(datarest).then((restuser) => {
                    this.showThisContent$.next({ datauser: restuser.app_metadata.roles });
                    this.modulos.loading = false;
                    this.habilitarModulos();
                }, (err) => {
                });
            }, (err) => {
            }).finally(() => this.modulos.loading = false);
        });
    }
    menuToogle() {
        this.menu.toggle();
    }
    irMenuLogistica() {
        this.route.navigateByUrl('/pages/logistica/menu-logistica');
    }
    irMenuExtrusion() {
        this.route.navigateByUrl('/pages/extrusion/menu-extrusion');
    }
    habilitarModulos() {
        const foundExtrusion = this.showThisContent$.value.datauser
            .find((el) => el.zone === 'extrusion' && el.business === 'cxp');
        const foundLogistica = this.showThisContent$.value.datauser
            .find((el) => el.zone === 'logistica' && el.business === 'cxp');
        const foundRrhh = this.showThisContent$.value.datauser
            .find((el) => el.zone === 'finanzas' && el.business === 'cxp');
        const foundFinanzas = this.showThisContent$.value.datauser
            .find((el) => el.zone === 'rrhh' && el.business === 'cxp');
        if (foundExtrusion !== undefined) {
            this.modulos.extrusion = true;
        }
        if (foundLogistica !== undefined) {
            this.modulos.logistica = true;
        }
        if (foundRrhh !== undefined) {
            this.modulos.rrhh = true;
        }
        if (foundFinanzas !== undefined) {
            this.modulos.finanzas = true;
        }
    }
};
MainMenuCxpComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__.SecurityService }
];
MainMenuCxpComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-main-menu',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_main_menu_cxp_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_main_menu_cxp_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MainMenuCxpComponent);



/***/ }),

/***/ 9924:
/*!*************************************************************!*\
  !*** ./src/app/pages/root/principal/principal.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrincipalComponent": () => (/* binding */ PrincipalComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_principal_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./principal.component.html */ 95940);
/* harmony import */ var _principal_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./principal.component.scss */ 69314);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../providers/external/security.service */ 46691);











let PrincipalComponent = class PrincipalComponent {
    constructor(auth, route, menu, auth0Serv, securityService) {
        this.auth = auth;
        this.route = route;
        this.menu = menu;
        this.auth0Serv = auth0Serv;
        this.securityService = securityService;
        this.modulos = {
            materiasprimas: false,
            inventario: false,
            entradaMercancia: false,
            registroParadas: false,
            configuracion: false,
            loading: true,
        };
        this.showThisContent$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject({});
        this.authRoles$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject({});
        this.tiempoDia = '';
        this.loading = true;
    }
    ngOnInit() {
        this.tiempoDia = this.obtenertiempoDia();
        this.auth.user$.subscribe((data) => {
            this.loading = false;
        });
        this.asignarEmpresa();
    }
    ngAfterViewInit() {
        this.comprobarUsuario();
        this.obtenerRoles();
    }
    comprobarUsuario() {
        setTimeout(() => {
            this.auth.isAuthenticated$.subscribe(data => {
                if (data === false) {
                    this.route.navigateByUrl('/pages/root/login');
                }
            });
        }, 2000);
    }
    irMenuMenuConfig() {
        this.route.navigateByUrl('pages/root/config/conf-menu');
    }
    asignarEmpresa() {
        localStorage.setItem('sapdb', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.dbCoembal);
    }
    obtenertiempoDia() {
        const TIEMPO = new Date();
        if (TIEMPO.getHours() >= 5 && TIEMPO.getHours() <= 11) {
            return 'Buenos Días';
        }
        else if (TIEMPO.getHours() >= 12 && TIEMPO.getHours() <= 20) {
            return 'Buenas Tardes';
        }
        else {
            return 'Buenas Noches';
        }
    }
    menuToogle() {
        this.menu.toggle();
    }
    navMenuMateriasPrimas() {
        this.route.navigateByUrl('/pages/materias-primas/menu');
    }
    navMenuInventario() {
        this.route.navigateByUrl('/pages/inventario/menu-inventario');
    }
    navMenuEntradaMercancia() {
        this.route.navigateByUrl('/pages/entrada-mercancia/menu');
    }
    navMenuRegistroParadas() {
        this.route.navigateByUrl('/pages/registro-paradas/menu');
    }
    obtenerRoles() {
        this.auth.user$.subscribe((user) => {
            this.auth0Serv.getAuth().then((resp) => {
                const userdata = {
                    idToken: resp.access_token,
                    idUser: user.sub,
                };
                const datarest = this.securityService.encrypt(JSON.stringify(userdata));
                this.auth0Serv.getUserRoles(datarest).then((restuser) => {
                    this.showThisContent$.next({ datauser: restuser.app_metadata.roles });
                    this.habilitarModulos();
                }, (err) => {
                });
            }, (err) => {
            }).finally(() => this.modulos.loading = false);
        });
    }
    habilitarModulos() {
        const foundConfiguracion = this.showThisContent$.value.datauser.find((el) => el.zone === 'configuracion');
        const foundMateriasPrimas = this.showThisContent$.value.datauser.find((el) => el.zone === 'materias-primas');
        const foundInventario = this.showThisContent$.value.datauser.find((el) => el.zone === 'inventario');
        const foundEntradaMercancia = this.showThisContent$.value.datauser.find((el) => el.zone === 'entrada-mercancia');
        const foundRegistroParadas = this.showThisContent$.value.datauser.find((el) => el.zone === 'registro-paradas');
        if (foundConfiguracion !== undefined) {
            this.modulos.configuracion = true;
        }
        if (foundMateriasPrimas !== undefined) {
            this.modulos.materiasprimas = true;
        }
        if (foundInventario !== undefined) {
            this.modulos.inventario = true;
        }
        if (foundEntradaMercancia !== undefined) {
            this.modulos.entradaMercancia = true;
        }
        if (foundRegistroParadas !== undefined) {
            this.modulos.registroParadas = true;
        }
    }
};
PrincipalComponent.ctorParameters = () => [
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.MenuController },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_3__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_4__.SecurityService }
];
PrincipalComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-principal',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_principal_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_principal_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], PrincipalComponent);



/***/ }),

/***/ 53246:
/*!***************************************************!*\
  !*** ./src/app/pages/root/root-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RootRoutingModule": () => (/* binding */ RootRoutingModule),
/* harmony export */   "rootRouterComponents": () => (/* binding */ rootRouterComponents)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _principal_principal_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./principal/principal.component */ 9924);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login/login.component */ 10761);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _root_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./root.component */ 43589);
/* harmony import */ var _main_menu_cxp_main_menu_cxp_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./main-menu-cxp/main-menu-cxp.component */ 78397);
/* harmony import */ var _main_menu_cmb_main_menu_cmb_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./main-menu-cmb/main-menu-cmb.component */ 9422);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _configuracion_configuracion_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./configuracion/configuracion.component */ 26129);










const routes = [{
        path: '',
        component: _root_component__WEBPACK_IMPORTED_MODULE_2__.RootComponent,
        children: [
            {
                path: 'inicio',
                component: _principal_principal_component__WEBPACK_IMPORTED_MODULE_0__.PrincipalComponent,
            },
            {
                path: 'main',
                component: _main_menu_cxp_main_menu_cxp_component__WEBPACK_IMPORTED_MODULE_3__.MainMenuCxpComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__.AuthGuard],
            },
            {
                path: 'cmb-main',
                component: _main_menu_cmb_main_menu_cmb_component__WEBPACK_IMPORTED_MODULE_4__.MainMenuCmbComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__.AuthGuard],
            },
            {
                path: 'config',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_root_configuracion_configuracion_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./configuracion/configuracion.module */ 80858))
                    .then(m => m.ConfiguracionModule)
            },
            {
                path: 'login',
                component: _login_login_component__WEBPACK_IMPORTED_MODULE_1__.LoginComponent,
            },
            {
                path: '',
                redirectTo: 'login',
                pathMatch: 'full',
            }
        ]
    }];
let RootRoutingModule = class RootRoutingModule {
};
RootRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule]
    })
], RootRoutingModule);

const rootRouterComponents = [
    _root_component__WEBPACK_IMPORTED_MODULE_2__.RootComponent,
    _login_login_component__WEBPACK_IMPORTED_MODULE_1__.LoginComponent,
    _main_menu_cxp_main_menu_cxp_component__WEBPACK_IMPORTED_MODULE_3__.MainMenuCxpComponent,
    _main_menu_cmb_main_menu_cmb_component__WEBPACK_IMPORTED_MODULE_4__.MainMenuCmbComponent,
    _principal_principal_component__WEBPACK_IMPORTED_MODULE_0__.PrincipalComponent,
    _configuracion_configuracion_component__WEBPACK_IMPORTED_MODULE_5__.ConfiguracionComponent,
];


/***/ }),

/***/ 43589:
/*!**********************************************!*\
  !*** ./src/app/pages/root/root.component.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RootComponent": () => (/* binding */ RootComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);



let RootComponent = class RootComponent {
    constructor(auth) {
        this.auth = auth;
    }
    ngOnInit() {
        this.auth.user$.subscribe((data) => {
            // console.log(data.email_verified);
        });
    }
};
RootComponent.ctorParameters = () => [
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_0__.AuthService }
];
RootComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-root',
        template: '<ion-router-outlet></ion-router-outlet>'
    })
], RootComponent);



/***/ }),

/***/ 10480:
/*!*******************************************!*\
  !*** ./src/app/pages/root/root.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RootModule": () => (/* binding */ RootModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _root_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./root-routing.module */ 53246);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);





let RootModule = class RootModule {
};
RootModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _root_routing_module__WEBPACK_IMPORTED_MODULE_0__.RootRoutingModule,
        ],
        declarations: [
            ..._root_routing_module__WEBPACK_IMPORTED_MODULE_0__.rootRouterComponents,
        ]
    })
], RootModule);



/***/ }),

/***/ 58306:
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/root/login/login.component.html ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content class=\"background-image\">\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-justify-content-center\">\r\n      <ion-col size=\"10\" class=\"col-img\">\r\n        <img src=\"https://www.coexpan.com/wp-content/uploads/2019/02/logotipo-coexpan.png\" alt=\"Logo coexpan\">\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-grid class=\"ion-margin-top\">\r\n\r\n    <ion-row class=\"ion-justify-content-center\">\r\n      <ion-col size=\"9\" class=\"\">\r\n        <ion-button expand=\"block\" color=\"tertiary\" class=\"btn-ms\" (click)=\"login()\">\r\n          <ion-icon name=\"logo-windows\"></ion-icon>\r\n          <span class=\"txt-msf\">Continuar con Microsoft ©</span>\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n</ion-content>\r\n");

/***/ }),

/***/ 10019:
/*!**************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/root/main-menu-cmb/main-menu-cmb.component.html ***!
  \**************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title color=\"medium\"><Strong>Selección Módulo</Strong></ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"\" *ngIf=\"modulos.loading\">\r\n  <ion-grid fixed class=\"ion-margin-top\">\r\n    <ion-row>\r\n      <ion-col class=\"ion-margin-top ion-padding-bottom\" size=\"12\">\r\n        <ion-item lines=\"full\">\r\n          <ion-avatar slot=\"start\">\r\n            <ion-skeleton-text animated></ion-skeleton-text>\r\n          </ion-avatar>\r\n          <ion-label>\r\n            <p>\r\n              <ion-skeleton-text animated style=\"width: 80%; height: 1.5rem;\"></ion-skeleton-text>\r\n            </p>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"12\">\r\n        <ion-item lines=\"full\">\r\n          <ion-avatar slot=\"start\">\r\n            <ion-skeleton-text animated></ion-skeleton-text>\r\n          </ion-avatar>\r\n          <ion-label>\r\n            <p>\r\n              <ion-skeleton-text animated style=\"width: 80%; height: 1.5rem;\"></ion-skeleton-text>\r\n            </p>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-content class=\"background-image ion-padding-top\" *ngIf=\"!modulos.loading\">\r\n  <ion-grid>\r\n\r\n    <ion-list class=\"ion-margin-top\">\r\n      <div>\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"modulos.logistica\"\r\n        (click)=\"navMenuLogistica()\">\r\n          <ion-icon slot=\"start\" name=\"bus\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Logistica</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"modulos.extrusion\" (click)=\"navMenuExtrusion()\">\r\n          <ion-icon slot=\"start\" name=\"bus\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Extrusion</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n\r\n        <!--\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"i === 'rrhh'\">\r\n          <ion-icon slot=\"start\" name=\"accessibility\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Recursos Humanos</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"i === 'finanza'\">\r\n          <ion-icon slot=\"start\" name=\"wallet-outline\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Finanzas</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n        -->\r\n\r\n      </div>\r\n    </ion-list>\r\n\r\n  </ion-grid>\r\n</ion-content>\r\n");

/***/ }),

/***/ 84808:
/*!**************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/root/main-menu-cxp/main-menu-cxp.component.html ***!
  \**************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title color=\"medium\"><Strong>Selección Módulo</Strong></ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"\" *ngIf=\"modulos.loading\">\r\n  <ion-grid fixed class=\"ion-margin-top\">\r\n    <ion-row>\r\n      <ion-col class=\"ion-margin-top ion-padding-bottom\" size=\"12\">\r\n        <ion-item lines=\"full\">\r\n          <ion-avatar slot=\"start\">\r\n            <ion-skeleton-text animated></ion-skeleton-text>\r\n          </ion-avatar>\r\n          <ion-label>\r\n            <p><ion-skeleton-text animated style=\"width: 80%; height: 1.5rem;\"></ion-skeleton-text></p>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"12\">\r\n        <ion-item lines=\"full\">\r\n          <ion-avatar slot=\"start\">\r\n            <ion-skeleton-text animated></ion-skeleton-text>\r\n          </ion-avatar>\r\n          <ion-label>\r\n            <p>\r\n              <ion-skeleton-text animated style=\"width: 80%; height: 1.5rem;\"></ion-skeleton-text>\r\n            </p>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-content class=\"background-image ion-padding-top\" *ngIf=\"!modulos.loading\">\r\n  <ion-grid>\r\n\r\n    <ion-list class=\"ion-margin-top\">\r\n      <div>\r\n      <ion-item class=\"ion-padding-bottom\" lines=\"full\" button (click)=\"irMenuLogistica()\"\r\n      *ngIf=\"modulos.logistica\" >\r\n        <ion-icon slot=\"start\"  name=\"bus\"></ion-icon>\r\n        <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Logistica</strong></ion-label>\r\n        <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n      </ion-item>\r\n\r\n      <ion-item class=\"ion-padding-bottom\" lines=\"full\" button (click)=\"irMenuExtrusion()\"\r\n      *ngIf=\"modulos.extrusion\" >\r\n        <ion-icon slot=\"start\" name=\"disc-outline\"></ion-icon>\r\n        <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Extrusión</strong></ion-label>\r\n        <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n      </ion-item>\r\n\r\n      <ion-item class=\"ion-padding-bottom\" lines=\"full\" button\r\n      *ngIf=\"modulos.rrhh\">\r\n        <ion-icon slot=\"start\" name=\"accessibility\"></ion-icon>\r\n        <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Recursos Humanos</strong></ion-label>\r\n        <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n      </ion-item>\r\n\r\n      <ion-item class=\"ion-padding-bottom\" lines=\"full\" button\r\n      *ngIf=\"modulos.finanzas\">\r\n        <ion-icon slot=\"start\" name=\"wallet-outline\"></ion-icon>\r\n        <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Finanzas</strong></ion-label>\r\n        <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n      </ion-item>\r\n      </div>\r\n    </ion-list>\r\n\r\n  </ion-grid>\r\n</ion-content>\r\n");

/***/ }),

/***/ 95940:
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/root/principal/principal.component.html ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title color=\"medium\"><Strong>Selección Módulo</Strong></ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"\" *ngIf=\"modulos.loading\">\r\n  <ion-grid fixed class=\"ion-margin-top\">\r\n    <ion-row>\r\n      <ion-col class=\"ion-margin-top ion-padding-bottom\" size=\"12\">\r\n        <ion-item lines=\"full\">\r\n          <ion-avatar slot=\"start\">\r\n            <ion-skeleton-text animated></ion-skeleton-text>\r\n          </ion-avatar>\r\n          <ion-label>\r\n            <p>\r\n              <ion-skeleton-text animated style=\"width: 80%; height: 1.5rem;\"></ion-skeleton-text>\r\n            </p>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"12\">\r\n        <ion-item lines=\"full\">\r\n          <ion-avatar slot=\"start\">\r\n            <ion-skeleton-text animated></ion-skeleton-text>\r\n          </ion-avatar>\r\n          <ion-label>\r\n            <p>\r\n              <ion-skeleton-text animated style=\"width: 80%; height: 1.5rem;\"></ion-skeleton-text>\r\n            </p>\r\n          </ion-label>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-content class=\"background-image ion-padding-top\" *ngIf=\"!modulos.loading\">\r\n  <ion-grid>\r\n\r\n    <ion-list class=\"ion-margin-top\">\r\n      <div>\r\n\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"modulos.materiasprimas\" (click)=\"navMenuMateriasPrimas()\">\r\n          <ion-icon slot=\"start\" name=\"color-filter\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Materias Primas</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"modulos.inventario\" (click)=\"navMenuInventario()\">\r\n          <ion-icon slot=\"start\" name=\"cube\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Inventario</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"modulos.entradaMercancia\" (click)=\"navMenuEntradaMercancia()\">\r\n          <ion-icon slot=\"start\" name=\"enter\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Entrada Mercancía</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"modulos.registroParadas\" (click)=\"navMenuRegistroParadas()\">\r\n          <ion-icon slot=\"start\" name=\"create\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Registro Paradas</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"modulos.configuracion\" (click)=\"irMenuMenuConfig()\">\r\n          <ion-icon slot=\"start\" name=\"settings\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Configuracion</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n\r\n        <!--\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"i === 'rrhh'\">\r\n          <ion-icon slot=\"start\" name=\"accessibility\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Recursos Humanos</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n\r\n        <ion-item class=\"ion-padding-bottom\" lines=\"full\" button *ngIf=\"i === 'finanza'\">\r\n          <ion-icon slot=\"start\" name=\"wallet-outline\"></ion-icon>\r\n          <ion-label style=\"font-size: 1.4rem;\" color=\"medium\"><strong>Finanzas</strong></ion-label>\r\n          <ion-icon slot=\"end\" name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-item>\r\n        -->\r\n\r\n      </div>\r\n    </ion-list>\r\n\r\n  </ion-grid>\r\n</ion-content>\r\n");

/***/ }),

/***/ 40551:
/*!*******************************************************!*\
  !*** ./src/app/pages/root/login/login.component.scss ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = ".inputs {\n  --background: #f5f6f9;\n  text-align: center;\n}\n\n.background-image {\n  --background: url('background-login.png') 0 0/100% 100% no-repeat;\n}\n\n.col-img {\n  text-align: center;\n  padding-top: 6rem;\n  padding-bottom: 3rem;\n}\n\n.col-btnlogin {\n  padding-top: 3rem;\n}\n\n.btn-ms {\n  font-size: 0.71em;\n}\n\n.txt-msf {\n  padding-left: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsaUVBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtBQUNGIiwiZmlsZSI6ImxvZ2luLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmlucHV0cyB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjZjVmNmY5O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmJhY2tncm91bmQtaW1hZ2V7XHJcbiAgLS1iYWNrZ3JvdW5kOiB1cmwoJy4uLy4uLy4uLy4uL2Fzc2V0cy9pbWcvbG9naW4vYmFja2dyb3VuZC1sb2dpbi5wbmcnKSAwIDAvMTAwJSAxMDAlIG5vLXJlcGVhdDtcclxufVxyXG5cclxuLmNvbC1pbWcge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBwYWRkaW5nLXRvcDogNnJlbTtcclxuICBwYWRkaW5nLWJvdHRvbTogM3JlbTtcclxufVxyXG5cclxuLmNvbC1idG5sb2dpbiB7XHJcbiAgcGFkZGluZy10b3A6IDNyZW07XHJcbn1cclxuXHJcbi5idG4tbXMge1xyXG4gIGZvbnQtc2l6ZTogMC43MWVtO1xyXG59XHJcblxyXG4udHh0LW1zZiB7XHJcbiAgcGFkZGluZy1sZWZ0OiA4cHg7XHJcbn1cclxuXHJcbiJdfQ== */";

/***/ }),

/***/ 65425:
/*!***********************************************************************!*\
  !*** ./src/app/pages/root/main-menu-cmb/main-menu-cmb.component.scss ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = ".background-image {\n  --background: url('background-login.png') 0 0/100% 100% no-repeat;\n}\n\n.titulo {\n  margin-top: 1.5rem;\n  margin-bottom: 1rem;\n}\n\n.btn {\n  --background: #D5D95D;\n  --color: #676a18;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4tbWVudS1jbWIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpRUFBQTtBQUNKOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7RUFDQSxnQkFBQTtBQUNGIiwiZmlsZSI6Im1haW4tbWVudS1jbWIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmFja2dyb3VuZC1pbWFnZXtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKCcuLi8uLi8uLi8uLi9hc3NldHMvaW1nL2xvZ2luL2JhY2tncm91bmQtbG9naW4ucG5nJykgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XHJcbn1cclxuXHJcbi50aXR1bG8ge1xyXG4gIG1hcmdpbi10b3A6IDEuNXJlbTtcclxuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG59XHJcblxyXG4uYnRuIHtcclxuICAtLWJhY2tncm91bmQ6ICNENUQ5NUQ7XHJcbiAgLS1jb2xvcjogIzY3NmExODtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 91778:
/*!***********************************************************************!*\
  !*** ./src/app/pages/root/main-menu-cxp/main-menu-cxp.component.scss ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = ".background-image {\n  --background: url('background-login.png') 0 0/100% 100% no-repeat;\n}\n\n.titulo {\n  margin-top: 1.5rem;\n  margin-bottom: 1rem;\n}\n\n.btn {\n  --background: #D5D95D;\n  --color: #676a18;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4tbWVudS1jeHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpRUFBQTtBQUNKOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7RUFDQSxnQkFBQTtBQUNGIiwiZmlsZSI6Im1haW4tbWVudS1jeHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmFja2dyb3VuZC1pbWFnZXtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKCcuLi8uLi8uLi8uLi9hc3NldHMvaW1nL2xvZ2luL2JhY2tncm91bmQtbG9naW4ucG5nJykgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XHJcbn1cclxuXHJcbi50aXR1bG8ge1xyXG4gIG1hcmdpbi10b3A6IDEuNXJlbTtcclxuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG59XHJcblxyXG4uYnRuIHtcclxuICAtLWJhY2tncm91bmQ6ICNENUQ5NUQ7XHJcbiAgLS1jb2xvcjogIzY3NmExODtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 69314:
/*!***************************************************************!*\
  !*** ./src/app/pages/root/principal/principal.component.scss ***!
  \***************************************************************/
/***/ ((module) => {

module.exports = ".background-image {\n  --background: url('background-login.png') 0 0/100% 100% no-repeat;\n}\n\n.col-header {\n  margin: 3em 0 0 0;\n}\n\n.col-header .label-header {\n  font-size: x-large;\n}\n\n.col-label {\n  margin: 3em 0 2em 0;\n}\n\n.col-label .label-1 {\n  font-size: large;\n}\n\n.btn-cxp {\n  --border-radius: 5px;\n  font-size: x-large;\n  --background: #3c84fc;\n  color: white;\n}\n\n.btn-cmb {\n  --border-radius: 5px;\n  font-size: x-large;\n}\n\n.btn-prueba-coembal {\n  --border-radius: 5px;\n  font-size: x-large;\n  --background: #5486fc;\n  color: white;\n}\n\n.btn-conf {\n  --border-radius: 5px;\n  font-size: 20px;\n  color: white;\n  margin-top: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByaW5jaXBhbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlFQUFBO0FBQ0o7O0FBRUE7RUFDRSxpQkFBQTtBQUNGOztBQUFFO0VBQ0Usa0JBQUE7QUFFSjs7QUFFQTtFQUNFLG1CQUFBO0FBQ0Y7O0FBQUU7RUFDRSxnQkFBQTtBQUVKOztBQUVBO0VBQ0Usb0JBQUE7RUFFQSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtBQUFGOztBQUdBO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtBQUFGOztBQUdBO0VBQ0Usb0JBQUE7RUFFQSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtBQURGOztBQUlBO0VBQ0Usb0JBQUE7RUFFQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBRkYiLCJmaWxlIjoicHJpbmNpcGFsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJhY2tncm91bmQtaW1hZ2V7XHJcbiAgICAtLWJhY2tncm91bmQ6IHVybCgnLi4vLi4vLi4vLi4vYXNzZXRzL2ltZy9sb2dpbi9iYWNrZ3JvdW5kLWxvZ2luLnBuZycpIDAgMC8xMDAlIDEwMCUgbm8tcmVwZWF0O1xyXG59XHJcblxyXG4uY29sLWhlYWRlciB7XHJcbiAgbWFyZ2luOiAzZW0gMCAwIDA7XHJcbiAgLmxhYmVsLWhlYWRlciB7XHJcbiAgICBmb250LXNpemU6IHgtbGFyZ2U7XHJcbiAgfVxyXG59XHJcblxyXG4uY29sLWxhYmVsIHtcclxuICBtYXJnaW46IDNlbSAwIDJlbSAwO1xyXG4gIC5sYWJlbC0xe1xyXG4gICAgZm9udC1zaXplOiBsYXJnZTtcclxuICB9XHJcbn1cclxuXHJcbi5idG4tY3hwIHtcclxuICAtLWJvcmRlci1yYWRpdXM6IDVweDtcclxuICAvLyBtYXJnaW46IDAgMCA0ZW0gMDtcclxuICBmb250LXNpemU6IHgtbGFyZ2U7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjM2M4NGZjO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLmJ0bi1jbWIge1xyXG4gIC0tYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIGZvbnQtc2l6ZTogeC1sYXJnZTtcclxufVxyXG5cclxuLmJ0bi1wcnVlYmEtY29lbWJhbCB7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgLy8gbWFyZ2luOiAwIDAgNGVtIDA7XHJcbiAgZm9udC1zaXplOiB4LWxhcmdlO1xyXG4gIC0tYmFja2dyb3VuZDogIzU0ODZmYztcclxuICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5idG4tY29uZiB7XHJcbiAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgLy8gbWFyZ2luOiAwIDAgNGVtIDA7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBtYXJnaW4tdG9wOiA1MHB4O1xyXG59XHJcblxyXG5cclxuIl19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_root_root_module_ts.js.map