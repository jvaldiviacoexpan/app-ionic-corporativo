"use strict";
(self["webpackChunkapp_ionic_corporativo"] = self["webpackChunkapp_ionic_corporativo"] || []).push([["src_app_pages_coembal_entrada-mercancia_entrada-mercancia_module_ts"],{

/***/ 10374:
/*!****************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/eliminar-etiqueta-bobina/eliminar-etiqueta-bobina.component.ts ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EliminarEtiquetaBobinaComponent": () => (/* binding */ EliminarEtiquetaBobinaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_eliminar_etiqueta_bobina_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./eliminar-etiqueta-bobina.component.html */ 30396);
/* harmony import */ var _eliminar_etiqueta_bobina_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./eliminar-etiqueta-bobina.component.scss */ 66751);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);







let EliminarEtiquetaBobinaComponent = class EliminarEtiquetaBobinaComponent {
    constructor(menuCtrl, toastController, alertController, cxpService, toolService) {
        this.menuCtrl = menuCtrl;
        this.toastController = toastController;
        this.alertController = alertController;
        this.cxpService = cxpService;
        this.toolService = toolService;
        this.dtoDatosResponse = {};
    }
    ngOnInit() {
        this.loading = false;
    }
    get disabledBotonImprimir() {
        let sts = true;
        if (this.dtoDatosResponse) {
            if (this.dtoDatosResponse.NOM_PRODUCTO) {
                sts = false;
            }
        }
        return sts;
    }
    menuToogle() {
        this.menuCtrl.toggle();
    }
    obtenerInformacionCaja(cod) {
        this.reestablecerDatos();
        this.loading = true;
        const data = { data: '', ipPrint: '' };
        if (cod.length === 0) {
            this.presentToast('Escanee un codigo antes de continuar.', 2000, 'warning');
            this.loading = false;
            this.codigoSetFocus();
            return;
        }
        data.data = cod.trim();
        this.accionBusqueda(true);
        this.cxpService.postObtenerDatosEtiquetaBobinaEm(data).then((resp) => {
            if (resp.Status.Status === 'T') {
                this.dtoDatosResponse = resp.Response[0];
                console.log(this.dtoDatosResponse);
            }
            else {
                this.presentToast(resp.Status.Message, 2000, 'warning');
            }
        }, (err) => {
            console.warn(err);
        }).finally(() => {
            this.accionBusqueda(false);
        });
    }
    alertaReimprimirEtiquetaPalletBobina(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Eliminar Etiqueta Pallet',
                message: 'Desea eliminar la etiqueta <Strong>Pallet Bobina</Strong> del sistema?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            if (event) {
                                event.target.complete();
                            }
                        }
                    }, {
                        text: 'Si, Eliminar',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            this.reimprimirEtiquetaPalletBobina();
                        }
                    }
                ]
            });
            yield alert.present().finally(() => {
                if (event) {
                    event.target.complete();
                }
            });
        });
    }
    reimprimirEtiquetaPalletBobina() {
        const data = { data: '', ipPrint: '' };
        data.data = this.dtoDatosResponse.CODBAR_MULTI;
        this.toolService.simpleLoader('Esperando Respuesta...');
        this.accionBusqueda(true);
        this.cxpService.postEliminarEtiquetaBobinaEm(data).then((resp) => {
            if (resp.Status === 'T') {
                this.presentToast(resp.Message, 3000, 'success');
            }
            else {
                this.presentToast(resp.Message, 4000, 'warning');
            }
        }, (err) => {
            console.warn(err);
        }).finally(() => {
            this.toolService.dismissLoader();
            this.reestablecerDatos();
            this.accionBusqueda(false);
        });
    }
    accionBusqueda(action) {
        this.txtCodigo.disabled = action;
        this.btnCodigo.disabled = action;
        this.loading = action;
        if (action) {
            this.txtCodigo.value = '';
        }
    }
    codigoSetFocus() { setTimeout(() => { this.txtCodigo.setFocus(); }, 300); }
    reestablecerDatos() {
        this.dtoDatosResponse = {};
        this.txtCodigo.value = '';
        this.codigoSetFocus();
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
};
EliminarEtiquetaBobinaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__.ToolService }
];
EliminarEtiquetaBobinaComponent.propDecorators = {
    txtCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['txtCodigo',] }],
    btnCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['btnCodigo',] }]
};
EliminarEtiquetaBobinaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-eliminar-etiqueta-bobina',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_eliminar_etiqueta_bobina_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_eliminar_etiqueta_bobina_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], EliminarEtiquetaBobinaComponent);



/***/ }),

/***/ 82909:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/em-materias-primas/em-materias-primas.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmMateriasPrimasComponent": () => (/* binding */ EmMateriasPrimasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_em_materias_primas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./em-materias-primas.component.html */ 83401);
/* harmony import */ var _ent_materias_primas_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ent-materias-primas.component.scss */ 19815);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);
/* harmony import */ var _models_sapbo_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../models/sapbo.model */ 20553);








let EmMateriasPrimasComponent = class EmMateriasPrimasComponent {
    constructor(menu, cxpService, toastController, toolService) {
        this.menu = menu;
        this.cxpService = cxpService;
        this.toastController = toastController;
        this.toolService = toolService;
        this.loadCodbar = false;
        this.arrayPallet = [];
    }
    ngOnInit() {
    }
    get getCantidadPallet() {
        return this.arrayPallet.length;
    }
    menuToogle() {
        this.menu.toggle();
    }
    obtenerPallet(cod) {
        // arrayPallet
        this.codBarra.disabled = true;
        this.loadCodbar = true;
        this.cxpService.obtenerPalletCodigoBarra(cod).then((data) => {
            console.log(data);
            if (data.Status.Status === 'T') {
                if (data.Objeto[0]) {
                    if (this.arrayPallet.find(m => m.CodBarra === data.Objeto[0].CodBarra)) {
                        this.presentToast('El Pallet ya se encuentra en la lista.', 4000, 'warning');
                    }
                    else if (this.arrayPallet.length > 0) {
                        if (this.arrayPallet[0].NumeroCarpeta !== data.Objeto[0].NumeroCarpeta) {
                            this.presentToast('El Pallet corresponde a una orden diferente.', 4000, 'warning');
                        }
                        this.arrayPallet.push(data.Objeto[0]);
                    }
                    else {
                        this.arrayPallet.push(data.Objeto[0]);
                    }
                }
                else {
                    this.presentToast('Pallet no encontrado.', 4000, 'warning');
                }
            }
            else {
                this.presentToast(data.Status.Message, 4000, 'warning');
            }
        }, (err) => {
            console.warn(err);
        }).finally(() => {
            this.codBarra.disabled = false;
            this.loadCodbar = false;
            this.codBarra.value = '';
            setTimeout(() => {
                this.codBarra.setFocus();
            }, 10);
        });
    }
    listaEliminarPallet(codbarra) {
        const i = this.arrayPallet.indexOf(codbarra);
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        if (i !== -1) {
            this.arrayPallet.splice(i, 1);
            this.presentToast('Pallet Quitado.', 2000, 'medium');
        }
    }
    enviarEntradaMercancia() {
        const em = new _models_sapbo_model__WEBPACK_IMPORTED_MODULE_4__.EmMateriaPrimaModel();
        em.doc = new _models_sapbo_model__WEBPACK_IMPORTED_MODULE_4__.Doc();
        em.doc.ign1_EMDetalle = [];
        if (this.arrayPallet.length === 0) {
            this.presentToast('Escanea algún Pallet antes de Continuar.', 2000, 'warning');
            return;
        }
        if (!localStorage.getItem('sapusr')) {
            this.presentToast('Inicie Sesión en Sap Business One para continuar.', 2000, 'warning');
            return;
        }
        this.toolService.simpleLoader('Enviando...');
        em.login = localStorage.getItem('sapusr');
        em.doc.oign_Reference1 = this.arrayPallet[0].Reference1.toString();
        em.doc.oign_Comments = 'Handheld Entrada de Mercancia - Materias Primas';
        em.doc.oign_JournalMemo = `Carpeta ${this.arrayPallet[0].NumeroCarpeta}`;
        let ign1 = new _models_sapbo_model__WEBPACK_IMPORTED_MODULE_4__.Ign1EMDetalle();
        this.arrayPallet.forEach(p => {
            ign1.ign1_DiscountPercent = 0;
            ign1.ign1_ItemCode = p.ItemCode;
            ign1.ign1_Price = p.Price;
            ign1.ign1_Quantity = p.Quantity;
            ign1.ign1_Currency = p.Currency;
            ign1.ign1_WarehouseCode = p.WarehouseCode;
            ign1.ign1_AccountCode = p.AccountCode;
            ign1.ign1_LineTotal = p.LineTotal;
            ign1.btnt_BatchNumber = p.CodBarra;
            em.doc.ign1_EMDetalle.push(ign1);
            ign1 = new _models_sapbo_model__WEBPACK_IMPORTED_MODULE_4__.Ign1EMDetalle();
        });
        this.cxpService.enviarEntradaMercanciaMateriasPrimas(em).then((data) => {
            if (data.Status === 'T') {
                this.presentToast(data.Message, 3000, 'success');
                this.arrayPallet = [];
                // console.log(data);
            }
            else {
                this.presentToast(data.Message, 3000, 'warning');
            }
        }, (err) => {
            console.warn(err);
        }).finally(() => this.toolService.dismissLoader());
    }
    presentToast(mensaje, duracion, colr) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: colr, translucent: true
            });
            toast.present();
        });
    }
};
EmMateriasPrimasComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__.ToolService }
];
EmMateriasPrimasComponent.propDecorators = {
    codBarra: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['codbar',] }]
};
EmMateriasPrimasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-em-materias-primas',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_em_materias_primas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_ent_materias_primas_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmMateriasPrimasComponent);



/***/ }),

/***/ 94029:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/em-pallet-bobinas/em-pallet-bobinas.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmPalletBobinaComponent": () => (/* binding */ EmPalletBobinaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_em_pallet_bobinas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./em-pallet-bobinas.component.html */ 19988);
/* harmony import */ var _em_pallet_bobinas_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./em-pallet-bobinas.component.scss */ 94531);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);







let EmPalletBobinaComponent = class EmPalletBobinaComponent {
    constructor(menuCtrl, toastController, alertController, cxpService, toolService) {
        this.menuCtrl = menuCtrl;
        this.toastController = toastController;
        this.alertController = alertController;
        this.cxpService = cxpService;
        this.toolService = toolService;
        this.dtoDatosResponse = {};
        this.arrayDtoDatosResponse = [];
        this.countLoadingDtoDatosResponse = [];
        this.arrayCodigosAlmacenados = [];
    }
    ngOnInit() {
        this.loading = false;
    }
    get disabledBotonImprimir() {
        let sts = true;
        if (this.arrayDtoDatosResponse.length > 0) {
            if (this.arrayDtoDatosResponse.filter(e => e.Data.fase.codStatus !== '200').length > 0) {
                // if (this.loading === false) {
                //   sts = false;
                // } else {
                //   sts = true;
                // }
                console.log(`loading: ${this.loading}`);
                sts = this.loading;
            }
        }
        console.log(sts);
        return sts;
    }
    menuToogle() {
        this.menuCtrl.toggle();
    }
    obtenerInformacionCaja(cod) {
        this.reestablecerDatos();
        if (cod.length === 0) {
            this.presentToast('Escanee un codigo antes de continuar.', 2000, 'warning');
            this.codigoSetFocus();
            return;
        }
        if (this.verificarCodigoExistencialista(cod.trim())) {
            this.presentToast('El Pallet ya se encuentra o esta cargando.', 2000, 'warning');
            return;
        }
        else {
            this.arrayCodigosAlmacenados.push(cod);
        }
        if (!localStorage.getItem('sapusr')) {
            this.presentToast('Inicie sesión en Sap Business One para Continuar.', 2000, 'warning');
            return;
        }
        const datos = { data: '', login: '' };
        datos.data = cod.trim();
        datos.login = localStorage.getItem('sapusr');
        this.countLoadingDtoDatosResponse.push('');
        this.accionBusqueda(true);
        this.cxpService.postSapObtenerDatosEtiquetaBobinaEm(datos).then((resp) => {
            if (resp.Data.status.Status === 'T') {
                this.arrayDtoDatosResponse.push(resp);
            }
            else {
                this.presentToast(resp.Data.status.Message, 2000, 'warning');
                this.eliminarCodigosTemporal(cod);
            }
        }, (err) => {
            this.eliminarCodigosTemporal(cod);
            console.warn(err);
        }).finally(() => {
            this.accionBusqueda(false);
            this.countLoadingDtoDatosResponse.pop();
        });
    }
    alertaEnviarEntradaMercanciaPalletBobina(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            if (!localStorage.getItem('ipimp')) {
                this.presentToast('Seleccione una impresora antes de emitir la etiqueta.', 2000, 'warning');
                return;
            }
            if (!localStorage.getItem('sapusr')) {
                this.presentToast('Inicie sesión en Sap Business One para Continuar.', 2000, 'warning');
                return;
            }
            const alert = yield this.alertController.create({
                header: 'SAP Business One',
                message: 'Desea enviar el Pallet al sistema?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            // if (event) { event.target.complete(); }
                        }
                    }, {
                        text: 'Si, Enviar',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            this.enviarEntradaMercanciaPalletBobina();
                        }
                    }
                ]
            });
            yield alert.present().finally(() => {
                // if (event) { event.target.complete(); }
            });
        });
    }
    enviarEntradaMercanciaPalletBobina() {
        this.accionBusqueda(true);
        const arrayTemporal = this.arrayDtoDatosResponse.filter(e => e.Data.fase.codStatus !== '200');
        this.loading = true;
        let count = 1;
        // this.toolService.simpleLoader('Enviando...');
        arrayTemporal.forEach(em => {
            em.IpPrint = localStorage.getItem('ipimp');
            em.Login = localStorage.getItem('sapusr');
            em.Data.fase.loadingStatus = true;
            em.Data.fase.codStatus = '200';
            this.cxpService.postAgregarEntradaMercanciaPalletBobinas(em).then((resp) => {
                if (em.Data.modelData.codQr === resp.Data.modelData.codQr) {
                    this.eliminarPallet(em, false);
                    resp.Data.fase.loadingStatus = false;
                    this.arrayDtoDatosResponse.push(resp);
                    this.arrayCodigosAlmacenados.push(resp.Data.modelData.codQr);
                    if (arrayTemporal.length === count) {
                        this.loading = false;
                    }
                    else {
                        count++;
                    }
                }
            }, (err) => {
                this.loading = false;
                console.warn(err);
            }).finally(() => {
                this.loading = false;
            });
            // Prueba NO BORRAR
            // setTimeout(() => {
            //   const resp = em;
            //   resp.Data.fase.loadingStatus = false;
            //   resp.Data.fase.codStatus = '200';
            //   resp.Data.fase.labelStatus = 'success';
            //   resp.Data.fase.messageStatus = 'Prueba - Pallet registrado con exito SAP BO.';
            //   this.eliminarPallet(em, false);
            //   this.arrayDtoDatosResponse.push(resp);
            //   this.arrayCodigosAlmacenados.push(resp.Data.modelData.codQr);
            // }, 8000);
        });
        // this.toolService.dismissLoader();
        this.accionBusqueda(true);
    }
    alertaReimprimirPalletBobina(event, p) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            if (!localStorage.getItem('ipimp')) {
                this.presentToast('Seleccione una impresora antes de emitir la etiqueta.', 2000, 'warning');
                return;
            }
            const alert = yield this.alertController.create({
                header: 'Imprimir etiqueta',
                message: 'Desea imprimir la etiqueta de <strong>Recepcion?</strong>',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            // if (event) { event.target.complete(); }
                        }
                    }, {
                        text: 'Si, Imprimir',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            this.reimprimirPalletBobina(p);
                        }
                    }
                ]
            });
            yield alert.present().finally(() => {
                if (event) {
                    event.close();
                }
            });
        });
    }
    reimprimirPalletBobina(p) {
        p.IpPrint = localStorage.getItem('ipimp');
        p.Data.fase.loadingStatus = true;
        this.cxpService.postReimprimirEtiquetaPalletRecepcion(p).then((resp) => {
            if (resp.Status === 'T') {
                this.presentToast(resp.Message, 2000, 'success');
            }
            else {
                this.presentToast(resp.Message, 2000, 'warning');
            }
        }, (err) => {
            console.warn(err);
        }).finally(() => {
            p.Data.fase.loadingStatus = false;
        });
    }
    accionBusqueda(action) {
        if (action) {
            this.txtCodigo.value = '';
        }
    }
    eliminarPallet(uidd, msgsee) {
        const i = this.arrayDtoDatosResponse.indexOf(uidd);
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        if (i !== -1) {
            this.eliminarCodigosTemporal(uidd.Data.modelData.codQr);
            this.arrayDtoDatosResponse.splice(i, 1);
            if (msgsee) {
                this.presentToast('Registro eliminado.', 2000, 'medium');
            }
        }
    }
    eliminarCodigosTemporal(uidd) {
        const i = this.arrayCodigosAlmacenados.indexOf(uidd);
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        if (i !== -1) {
            this.arrayCodigosAlmacenados.splice(i, 1);
        }
    }
    codigoSetFocus() { setTimeout(() => { this.txtCodigo.setFocus(); }, 300); }
    verificarCodigoExistencialista(cod) {
        let exists = false;
        console.log(this.arrayCodigosAlmacenados);
        this.arrayCodigosAlmacenados.forEach(e => {
            if (e === cod) {
                exists = true;
            }
        });
        return exists;
    }
    reestablecerDatos() {
        this.dtoDatosResponse = {};
        this.txtCodigo.value = '';
        this.codigoSetFocus();
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
};
EmPalletBobinaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__.ToolService }
];
EmPalletBobinaComponent.propDecorators = {
    txtCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['txtCodigo',] }],
    btnCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['btnCodigo',] }]
};
EmPalletBobinaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-em-pallet-bobinas',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_em_pallet_bobinas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_em_pallet_bobinas_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], EmPalletBobinaComponent);



/***/ }),

/***/ 81293:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/entrada-mercancia-routing.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntradaMercanciaRoutingModule": () => (/* binding */ EntradaMercanciaRoutingModule),
/* harmony export */   "entradaMercanciaRouterComponents": () => (/* binding */ entradaMercanciaRouterComponents)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./entrada-mercancia.component */ 65471);
/* harmony import */ var _menu_entrada_mercancia_menu_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu-entrada-mercancia/menu-entrada-mercancia.component */ 79028);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _pt_caja_pt_caja_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pt-caja/pt-caja.component */ 81951);
/* harmony import */ var _em_materias_primas_em_materias_primas_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./em-materias-primas/em-materias-primas.component */ 82909);
/* harmony import */ var _reimprimir_pt_caja_reimprimir_pt_caja_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./reimprimir-pt-caja/reimprimir-pt-caja.component */ 16429);
/* harmony import */ var _etiqueta_bobina_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./etiqueta-bobina/etiqueta-bobina.component */ 1562);
/* harmony import */ var _reimprimir_etiqueta_bobina_reimprimir_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./reimprimir-etiqueta-bobina/reimprimir-etiqueta-bobina.component */ 49641);
/* harmony import */ var _eliminar_etiqueta_bobina_eliminar_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./eliminar-etiqueta-bobina/eliminar-etiqueta-bobina.component */ 10374);
/* harmony import */ var _em_pallet_bobinas_em_pallet_bobinas_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./em-pallet-bobinas/em-pallet-bobinas.component */ 94029);
/* harmony import */ var _reimprimir_etiqueta_bobina_sap_reimprimir_etiqueta_bobina_sap_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./reimprimir-etiqueta-bobina-sap/reimprimir-etiqueta-bobina-sap.component */ 32745);














const routes = [{
        path: '',
        component: _entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_0__.EntradaMercanciaComponent,
        children: [
            {
                path: 'menu',
                component: _menu_entrada_mercancia_menu_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_1__.MenuEntradaMercanciaComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__.AuthGuard],
            },
            {
                path: 'pt-caja',
                component: _pt_caja_pt_caja_component__WEBPACK_IMPORTED_MODULE_2__.PtCajaComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__.AuthGuard],
            },
            {
                path: 'reimprimir-pt-caja',
                component: _reimprimir_pt_caja_reimprimir_pt_caja_component__WEBPACK_IMPORTED_MODULE_4__.ReimprimirPtCajaComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__.AuthGuard],
            },
            {
                path: 'etiqueta-pallet-bobinas',
                component: _etiqueta_bobina_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_5__.EtiquetaBobinaComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__.AuthGuard],
            },
            {
                path: 'reimprimir-etiqueta-pallet-bobinas',
                component: _reimprimir_etiqueta_bobina_reimprimir_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_6__.ReimprimirEtiquetaBobinaComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__.AuthGuard],
            },
            {
                path: 'reimprimir-etiqueta-bobinas-sap',
                component: _reimprimir_etiqueta_bobina_sap_reimprimir_etiqueta_bobina_sap_component__WEBPACK_IMPORTED_MODULE_9__.ReimprimirEtiquetaBobinaSapComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__.AuthGuard],
            },
            {
                path: 'eliminar-etiqueta-pallet-bobinas',
                component: _eliminar_etiqueta_bobina_eliminar_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_7__.EliminarEtiquetaBobinaComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__.AuthGuard],
            },
            {
                path: 'em-pallet-bobina',
                component: _em_pallet_bobinas_em_pallet_bobinas_component__WEBPACK_IMPORTED_MODULE_8__.EmPalletBobinaComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_10__.AuthGuard],
            }
        ]
    }];
let EntradaMercanciaRoutingModule = class EntradaMercanciaRoutingModule {
};
EntradaMercanciaRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_13__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_13__.RouterModule]
    })
], EntradaMercanciaRoutingModule);

const entradaMercanciaRouterComponents = [
    _entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_0__.EntradaMercanciaComponent,
    _menu_entrada_mercancia_menu_entrada_mercancia_component__WEBPACK_IMPORTED_MODULE_1__.MenuEntradaMercanciaComponent,
    _pt_caja_pt_caja_component__WEBPACK_IMPORTED_MODULE_2__.PtCajaComponent,
    _em_materias_primas_em_materias_primas_component__WEBPACK_IMPORTED_MODULE_3__.EmMateriasPrimasComponent,
    _reimprimir_pt_caja_reimprimir_pt_caja_component__WEBPACK_IMPORTED_MODULE_4__.ReimprimirPtCajaComponent,
    _etiqueta_bobina_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_5__.EtiquetaBobinaComponent,
    _reimprimir_etiqueta_bobina_reimprimir_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_6__.ReimprimirEtiquetaBobinaComponent,
    _reimprimir_etiqueta_bobina_sap_reimprimir_etiqueta_bobina_sap_component__WEBPACK_IMPORTED_MODULE_9__.ReimprimirEtiquetaBobinaSapComponent,
    _eliminar_etiqueta_bobina_eliminar_etiqueta_bobina_component__WEBPACK_IMPORTED_MODULE_7__.EliminarEtiquetaBobinaComponent,
    _em_pallet_bobinas_em_pallet_bobinas_component__WEBPACK_IMPORTED_MODULE_8__.EmPalletBobinaComponent,
];


/***/ }),

/***/ 65471:
/*!********************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/entrada-mercancia.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntradaMercanciaComponent": () => (/* binding */ EntradaMercanciaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


let EntradaMercanciaComponent = class EntradaMercanciaComponent {
    contructor() { }
};
EntradaMercanciaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'app-entrada-mercancia',
        template: '<ion-router-outlet></ion-router-outlet>'
    })
], EntradaMercanciaComponent);



/***/ }),

/***/ 93846:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/entrada-mercancia.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntradaMercanciaModule": () => (/* binding */ EntradaMercanciaModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _entrada_mercancia_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./entrada-mercancia-routing.module */ 81293);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);





let EntradaMercanciaModule = class EntradaMercanciaModule {
};
EntradaMercanciaModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _entrada_mercancia_routing_module__WEBPACK_IMPORTED_MODULE_0__.EntradaMercanciaRoutingModule
        ],
        declarations: [
            ..._entrada_mercancia_routing_module__WEBPACK_IMPORTED_MODULE_0__.entradaMercanciaRouterComponents
        ]
    })
], EntradaMercanciaModule);



/***/ }),

/***/ 1562:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/etiqueta-bobina/etiqueta-bobina.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaBobinaComponent": () => (/* binding */ EtiquetaBobinaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_etiqueta_bobina_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./etiqueta-bobina.component.html */ 6047);
/* harmony import */ var _etiqueta_bobina_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./etiqueta-bobina.component.scss */ 69313);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);
/* harmony import */ var _models_entrada_mercancia_etiqueta_bobina_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../models/entrada-mercancia/etiqueta-bobina.model */ 69145);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);









let EtiquetaBobinaComponent = class EtiquetaBobinaComponent {
    constructor(auth, menuCtrl, alertCtrl, toastController, cxpService, toolService) {
        this.auth = auth;
        this.menuCtrl = menuCtrl;
        this.alertCtrl = alertCtrl;
        this.toastController = toastController;
        this.cxpService = cxpService;
        this.toolService = toolService;
        this.usuario = '';
    }
    get isEnabledEnviar() {
        var _a;
        let enabled = false;
        if (this.txtCodigos) {
            enabled = ((_a = this.txtCodigos.value) === null || _a === void 0 ? void 0 : _a.length) !== 0 ? false : true;
        }
        return enabled;
    }
    get contadorCodigos() {
        var _a, _b;
        let contador = 0;
        if (this.txtCodigos) {
            if (((_a = this.txtCodigos.value) === null || _a === void 0 ? void 0 : _a.trim().length) > 0) {
                contador = (_b = this.txtCodigos.value) === null || _b === void 0 ? void 0 : _b.trim().split(' ').length;
            }
        }
        return contador;
    }
    get contadorCodigosNoRepetidos() {
        var _a, _b;
        let contador = 0;
        if (this.txtCodigos) {
            if (((_a = this.txtCodigos.value) === null || _a === void 0 ? void 0 : _a.trim().length) > 0) {
                contador = this.limpiarCodigos((_b = this.txtCodigos.value) === null || _b === void 0 ? void 0 : _b.trim()).length;
            }
        }
        return contador;
    }
    ngOnInit() {
        this.alertaActualizarFuenteDatos();
        this.auth.user$.subscribe(data => {
            this.usuario = data.email;
        });
    }
    menuToogle() {
        this.menuCtrl.toggle();
    }
    alertaActualizarFuenteDatos(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Actualizar datos SCP Coexpan',
                message: 'Desea actualizar la fuente de datos?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            if (event) {
                                event.target.complete();
                            }
                            this.reestablecerDatos();
                        }
                    }, {
                        text: 'Actualizar',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            this.actualizarFuenteDatos();
                        }
                    }
                ]
            });
            yield alert.present().finally(() => {
                if (event) {
                    event.target.complete();
                }
            });
        });
    }
    actualizarFuenteDatos() {
        this.toolService.simpleLoader('Refrescando datos...');
        this.cxpService.getEjecutarEtlPesaje().then((data) => {
            if (data.Status.Status === 'T') {
                console.log(data);
                if (data.Response[0].STATUS === 1) {
                    this.presentToast('Datos refrescados', 2000, 'success');
                }
                else {
                    this.presentToast('Error en la comunicación con el servidor. \n Intente nuevamente.', 5000, 'warning');
                }
            }
            else {
                this.presentToast(data.Status.Message, 5000, 'warning');
            }
        }, err => {
            console.error(err);
        }).finally(() => { this.toolService.dismissLoader(); this.reestablecerDatos(); });
    }
    alertaConfirmarEtiquetaBobina() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const ipPrint = localStorage.getItem('ipimp');
            if (!ipPrint) {
                this.presentToast('Seleccione una impresora antes de emitir la etiqueta.', 2000, 'warning');
                return;
            }
            const alert = yield this.alertCtrl.create({
                header: 'Etiqueta Bobina',
                message: 'Desea generar Etiqueta de Pallet Bobinas?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            // console.log('Confirm Cancel.');
                        }
                    }, {
                        text: 'Enviar',
                        cssClass: 'btnAlertSuccess',
                        handler: (data) => {
                            this.enviarEtiquetaBobina();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    enviarEtiquetaBobina() {
        const etiqueta = new _models_entrada_mercancia_etiqueta_bobina_model__WEBPACK_IMPORTED_MODULE_4__.EtiquetaBobinaModel();
        etiqueta.data = new _models_entrada_mercancia_etiqueta_bobina_model__WEBPACK_IMPORTED_MODULE_4__.Data();
        etiqueta.login = '';
        etiqueta.ipPrint = localStorage.getItem('ipimp');
        etiqueta.sapetiqueta = this.chkSapEtiqueta.checked;
        etiqueta.data.codBarras = this.limpiarCodigos(this.txtCodigos.value);
        etiqueta.data.fechaScan = this.obtenerFecha();
        etiqueta.data.bodega = 1;
        etiqueta.data.idUsuario = 0;
        this.toolService.simpleLoader('Cargando...');
        this.cxpService.postEtiquetaBobinaEm(etiqueta).then((data) => {
            if (data.Status.Status === 'T') {
                this.presentToast(data.Status.Message, 5000, 'success');
                this.reestablecerDatos();
            }
            else {
                this.presentToast(data.Status.Message, 5000, 'warning');
            }
        }, (erro) => {
            console.error(erro);
        }).finally(() => this.toolService.dismissLoader());
    }
    limpiarCodigos(codigos) {
        const arrayCadena = codigos.trim().split(' ');
        const arrayCadenaClean = arrayCadena.filter(Boolean);
        const arrayClean = [...new Set(arrayCadenaClean)];
        return arrayClean;
    }
    reestablecerDatos() {
        this.txtCodigos.value = '';
        setTimeout(() => {
            this.txtCodigos.setFocus();
        }, 250);
    }
    obtenerFecha() {
        const fechaDate = new Date();
        let fechaString = '';
        const anio = fechaDate.getFullYear();
        let dia = '';
        let mes = '';
        let hora = '';
        let minuto = '';
        let segundo = '';
        if (fechaDate.getDate() < 10) {
            dia = `0${fechaDate.getDate()}`;
        }
        else {
            dia = fechaDate.getDate().toString();
        }
        if (fechaDate.getMonth() < 9) {
            mes = `0${fechaDate.getMonth() + 1}`;
        }
        else {
            mes = (fechaDate.getMonth() + 1).toString();
        }
        if (fechaDate.getHours() < 10) {
            hora = `0${fechaDate.getHours()}`;
        }
        else {
            hora = fechaDate.getHours().toString();
        }
        if (fechaDate.getMinutes() < 10) {
            minuto = `0${fechaDate.getMinutes()}`;
        }
        else {
            minuto = fechaDate.getMinutes().toString();
        }
        if (fechaDate.getSeconds() < 10) {
            segundo = `0${fechaDate.getSeconds()}`;
        }
        else {
            segundo = fechaDate.getSeconds().toString();
        }
        fechaString = `${anio}${mes}${dia} ${hora}:${minuto}:${segundo}`;
        console.log(mes);
        return fechaString;
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
};
EtiquetaBobinaComponent.ctorParameters = () => [
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__.ToolService }
];
EtiquetaBobinaComponent.propDecorators = {
    btnEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['btnEnviar',] }],
    txtCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['codigos',] }],
    chkSapEtiqueta: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['sapetiqueta',] }]
};
EtiquetaBobinaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-etiqueta-bobina',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_etiqueta_bobina_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_etiqueta_bobina_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], EtiquetaBobinaComponent);



/***/ }),

/***/ 79028:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/menu-entrada-mercancia/menu-entrada-mercancia.component.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuEntradaMercanciaComponent": () => (/* binding */ MenuEntradaMercanciaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_menu_entrada_mercancia_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./menu-entrada-mercancia.component.html */ 25571);
/* harmony import */ var _menu_entrada_mercancia_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu-entrada-mercancia.component.scss */ 62073);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/security.service */ 46691);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);











let MenuEntradaMercanciaComponent = class MenuEntradaMercanciaComponent {
    constructor(menu, route, auth, auth0Serv, securityService, toolService) {
        this.menu = menu;
        this.route = route;
        this.auth = auth;
        this.auth0Serv = auth0Serv;
        this.securityService = securityService;
        this.toolService = toolService;
        this.enabled = {
            etr01: false,
            etr02: false,
            etr03: false,
            etr04: false,
            etr05: false,
            etr06: false,
        };
        this.showThisContent$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject({});
    }
    ngOnInit() { }
    ngAfterViewInit() {
        this.toolService.simpleLoader('Cargando...');
        this.obtenerRoles();
    }
    obtenerRoles() {
        this.auth.user$.subscribe((user) => {
            this.auth0Serv.getAuth().then((resp) => {
                const userdata = {
                    idToken: resp.access_token,
                    idUser: user.sub,
                };
                const datarest = this.securityService.encrypt(JSON.stringify(userdata));
                this.auth0Serv.getUserRoles(datarest).then((restuser) => {
                    this.showThisContent$.next({ datauser: restuser.app_metadata.roles });
                    this.habilitarModulos();
                }, (err) => {
                    // Todo Falta informacion adicional
                });
            }, (err) => {
                // Todo Falta informacion adicional
            }).finally(() => this.toolService.dismissLoader());
        });
    }
    habilitarModulos() {
        const etr01 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'etr01' && el.enabled === true);
        const etr02 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'etr02' && el.enabled === true);
        const etr03 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'etr03' && el.enabled === true);
        const etr04 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'etr04' && el.enabled === true);
        const etr05 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'etr05' && el.enabled === true);
        const etr06 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'etr06' && el.enabled === true);
        if (etr01 !== undefined) {
            this.enabled.etr01 = true;
        }
        if (etr02 !== undefined) {
            this.enabled.etr02 = true;
        }
        if (etr03 !== undefined) {
            this.enabled.etr03 = true;
        }
        if (etr04 !== undefined) {
            this.enabled.etr04 = true;
        }
        if (etr05 !== undefined) {
            this.enabled.etr05 = true;
        }
        if (etr06 !== undefined) {
            this.enabled.etr06 = true;
        }
    }
    menuToogle() {
        this.menu.toggle();
    }
    irPtCaja() {
        this.route.navigateByUrl('/pages/entrada-mercancia/pt-caja');
    }
    irReimprimirPtCaja() {
        this.route.navigateByUrl('/pages/entrada-mercancia/reimprimir-pt-caja');
    }
    irEtiquetaPalletBobina() {
        this.route.navigateByUrl('/pages/entrada-mercancia/etiqueta-pallet-bobinas');
    }
    irReimprimirEtiquetaPalletBobina() {
        this.route.navigateByUrl('/pages/entrada-mercancia/reimprimir-etiqueta-pallet-bobinas');
    }
    irReimprimirEtiquetaPalletBobinaSap() {
        this.route.navigateByUrl('/pages/entrada-mercancia/reimprimir-etiqueta-bobinas-sap');
    }
    irEliminarEtiquetaPalletBobina() {
        this.route.navigateByUrl('/pages/entrada-mercancia/eliminar-etiqueta-pallet-bobinas');
    }
    irEmPalletBobina() {
        this.route.navigateByUrl('/pages/entrada-mercancia/em-pallet-bobina');
    }
};
MenuEntradaMercanciaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__.AuthService },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__.SecurityService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__.ToolService }
];
MenuEntradaMercanciaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-menu-entrada-mercancia',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_menu_entrada_mercancia_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_menu_entrada_mercancia_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MenuEntradaMercanciaComponent);



/***/ }),

/***/ 81951:
/*!******************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/pt-caja/pt-caja.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PtCajaComponent": () => (/* binding */ PtCajaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_pt_caja_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./pt-caja.component.html */ 39160);
/* harmony import */ var _pt_caja_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pt-caja.component.scss */ 32949);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);
/* harmony import */ var src_models_requestEntradaMercanciaCajasModel_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/models/requestEntradaMercanciaCajasModel.model */ 70393);








let PtCajaComponent = class PtCajaComponent {
    constructor(menuCtrl, cxpService, toastController, toolService, alertController) {
        this.menuCtrl = menuCtrl;
        this.cxpService = cxpService;
        this.toastController = toastController;
        this.toolService = toolService;
        this.alertController = alertController;
        this.loading = false;
        this.cliente = '';
        this.ordenFab = '';
        this.producto = '';
    }
    ngOnInit() { }
    ngAfterViewInit() {
        this.btnEmision.disabled = true;
        this.alertaActualizarFuenteDatos();
    }
    menuToogle() {
        this.menuCtrl.toggle();
    }
    obtenerInformacionCaja(cod) {
        this.reestablecerDatos();
        this.loading = true;
        const data = { login: '', data: '' };
        if (cod.length === 0) {
            this.presentToast('Escanee un codigo antes de continuar.', 2000, 'warning');
            this.codigoSetFocus();
            return;
        }
        if (!localStorage.getItem('sapusr')) {
            this.presentToast('Inicie sesión en Sap Business One para Continuar.', 5000, 'warning');
            return;
        }
        data.login = localStorage.getItem('sapusr');
        data.data = cod.trim();
        this.accionBusqueda(true);
        this.cxpService.postBuscarDatosCaja(data).then((resp) => {
            if (resp.Status.Status === 'T') {
                console.log(resp);
                this.dtoDatosResponse = resp;
                this.cliente = this.dtoDatosResponse.Response.cliente;
                this.ordenFab = this.dtoDatosResponse.Response.lote;
                this.producto = this.dtoDatosResponse.Response.codigoProducto;
                this.cantidadCajasSetFocus();
            }
            else {
                this.presentToast(resp.Status.Message, 2000, 'warning');
            }
            // console.log(resp);
        }, (err) => {
            console.warn(err);
        }).finally(() => {
            this.accionBusqueda(false);
        });
    }
    alertaActualizarFuenteDatos(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Actualizar datos SCP Coembal',
                message: 'Desea actualizar la fuente de datos?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            if (event) {
                                event.target.complete();
                            }
                        }
                    }, {
                        text: 'Actualizar',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            this.actualizarFuenteDatos();
                        }
                    }
                ]
            });
            yield alert.present().finally(() => {
                if (event) {
                    event.target.complete();
                }
            });
        });
    }
    alertaConfirmarEtiqueta() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (!this.successEntradaMercancia() || !this.revisionDatosEntradaMercancia()) {
                return;
            }
            const alert = yield this.alertController.create({
                header: 'Entrada de Mercancía',
                message: 'Desea cargar los productos al sistema?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            // console.log('Confirm Cancel.');
                        }
                    }, {
                        text: 'Enviar',
                        cssClass: 'btnAlertSuccess',
                        handler: (data) => {
                            this.emitirPalletCajaCoembal();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    emitirPalletCajaCoembal() {
        const req = new src_models_requestEntradaMercanciaCajasModel_model__WEBPACK_IMPORTED_MODULE_4__.RequestEntradaMercancia();
        req.data = new src_models_requestEntradaMercanciaCajasModel_model__WEBPACK_IMPORTED_MODULE_4__.Data();
        req.data = this.dtoDatosResponse.Response;
        req.login = localStorage.getItem('sapusr');
        req.data.ipImpresora = localStorage.getItem('ipimp');
        req.data.cantidadCajas = Number(this.txtCantCajas.value.toString());
        console.log(req);
        this.toolService.simpleLoader('Enviando datos...');
        this.cxpService.postSapEntradaMercanciaCajaPallet(req).then((data) => {
            if (data.Status === 'T') {
                this.presentToast('Imprimiendo etiqueta...', 2000, 'success');
                this.reestablecerDatos();
            }
            else {
                this.presentToast(data.Message, 5000, 'warning');
                setTimeout(() => {
                    this.presentToast(`Sap: ${data.Sap_Message}`, 4000, 'warning');
                }, 5000);
            }
        }, err => {
            console.error(err);
        }).finally(() => this.toolService.dismissLoader());
    }
    actualizarFuenteDatos() {
        this.toolService.simpleLoader('Refrescando datos...');
        this.cxpService.getEjecutarEtlExtrusion().then((data) => {
            if (data.Status.Status === 'T') {
                console.log(data);
                if (data.Response[0].STATUS === 1) {
                    this.presentToast('Datos refrescados', 2000, 'success');
                }
                else {
                    this.presentToast('Error en la comunicación con el servidor. \n Intente nuevamente.', 5000, 'warning');
                }
            }
            else {
                this.presentToast(data.Status.Message, 5000, 'warning');
            }
        }, err => {
            console.error(err);
        }).finally(() => this.toolService.dismissLoader());
    }
    codigoSetFocus() { setTimeout(() => { this.txtCodigo.setFocus(); }, 300); }
    cantidadCajasSetFocus() { setTimeout(() => { this.txtCantCajas.setFocus(); }, 300); }
    get deshabilitarBotonEnviar() {
        let resp = true;
        if (this.dtoDatosResponse && this.txtCantCajas) {
            if (this.txtCantCajas.value) {
                if (this.txtCantCajas.value !== undefined && this.txtCantCajas.value !== '0') {
                    resp = false;
                }
            }
        }
        return resp;
    }
    accionBusqueda(action) {
        this.txtCodigo.disabled = action;
        this.btnCodigo.disabled = action;
        this.loading = action;
        if (action) {
            this.txtCodigo.value = '';
        }
    }
    reestablecerDatos() {
        this.cliente = '';
        this.ordenFab = '';
        this.producto = '';
        this.dtoDatosResponse = null;
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
    successEntradaMercancia() {
        let ok = true;
        const ipPrint = localStorage.getItem('ipimp');
        const login = localStorage.getItem('sapusr');
        if (!ipPrint) {
            this.presentToast('Seleccione una impresora antes de emitir la etiqueta.', 2000, 'warning');
            ok = false;
            return ok;
        }
        if (!login) {
            this.presentToast('Inicie sesión en Sap Business One para Continuar.', 5000, 'warning');
            ok = false;
            return ok;
        }
        if (this.dtoDatosResponse.Response.cantxCaja === '0') {
            this.presentToast('SAPBO: Und/Caja o Kg/Bob sin parámetros, modifique en Sap Business One y vuelva a intentar.', 5000, 'warning');
            ok = false;
            return ok;
        }
        return ok;
    }
    revisionDatosEntradaMercancia() {
        const status = {
            message: ''
        };
        let result = false;
        const list = [];
        if (this.dtoDatosResponse.Response.bodega === null) {
            status.message = 'Sap BO: Sin asignación de bodega.';
            list.push(status.message);
        }
        if (this.dtoDatosResponse.Response.cantxCaja === null) {
            status.message = 'Sap BO: Cantidad por cajas vacío.';
            list.push(status.message);
        }
        if (this.dtoDatosResponse.Response.color === null ||
            this.dtoDatosResponse.Response.color === '') {
            status.message = 'Sap BO: Color no puede estar vacío.';
            list.push(status.message);
        }
        if (this.dtoDatosResponse.Response.codCosto === null) {
            status.message = 'Sap BO: Sin asignación de código de costo.';
            list.push(status.message);
        }
        if (this.dtoDatosResponse.Response.codigoProducto === null) {
            status.message = 'SCP2: Sin asignación de código de producto.';
            list.push(status.message);
        }
        if (this.dtoDatosResponse.Response.peso === null) {
            status.message = 'Sap BO: Sin asignación de peso envase.';
            list.push(status.message);
        }
        if (this.dtoDatosResponse.Response.precio === null) {
            status.message = 'Sap BO: Precio resina no asignado.';
            list.push(status.message);
        }
        if (this.dtoDatosResponse.Response.precioEnvase === null) {
            status.message = 'Sap BO: Precio envase no válido.';
            list.push(status.message);
        }
        let msg = `Error al enviar Entrada Mercancia. <br> <ul>`;
        if (list.length > 0) {
            list.forEach(e => {
                msg += `<li>${e}</li>`;
            });
            msg += '</ul>';
            this.presentToast(`${msg}`, 5000, 'warning');
        }
        else {
            result = true;
        }
        return result;
    }
};
PtCajaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__.ToolService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController }
];
PtCajaComponent.propDecorators = {
    txtCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['txtCodigo',] }],
    txtCantCajas: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['cantCajas',] }],
    btnCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['btnCodigo',] }],
    btnEmision: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['btnEmision',] }]
};
PtCajaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-pt-caja',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_pt_caja_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_pt_caja_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], PtCajaComponent);



/***/ }),

/***/ 32745:
/*!****************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/reimprimir-etiqueta-bobina-sap/reimprimir-etiqueta-bobina-sap.component.ts ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReimprimirEtiquetaBobinaSapComponent": () => (/* binding */ ReimprimirEtiquetaBobinaSapComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_reimprimir_etiqueta_bobina_sap_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./reimprimir-etiqueta-bobina-sap.component.html */ 96982);
/* harmony import */ var _reimprimir_etiqueta_bobina_sap_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reimprimir-etiqueta-bobina-sap.component.scss */ 24832);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/models/anymodels.model */ 58301);









let ReimprimirEtiquetaBobinaSapComponent = class ReimprimirEtiquetaBobinaSapComponent {
    constructor(auth, menuCtrl, alertCtrl, toastController, cxpService, toolService) {
        this.auth = auth;
        this.menuCtrl = menuCtrl;
        this.alertCtrl = alertCtrl;
        this.toastController = toastController;
        this.cxpService = cxpService;
        this.toolService = toolService;
        this.usuario = '';
    }
    get isEnabledEnviar() {
        var _a;
        let enabled = false;
        if (this.txtCodigos) {
            enabled = ((_a = this.txtCodigos.value) === null || _a === void 0 ? void 0 : _a.length) !== 0 ? false : true;
        }
        return enabled;
    }
    get contadorCodigos() {
        var _a, _b;
        let contador = 0;
        if (this.txtCodigos) {
            if (((_a = this.txtCodigos.value) === null || _a === void 0 ? void 0 : _a.trim().length) > 0) {
                contador = (_b = this.txtCodigos.value) === null || _b === void 0 ? void 0 : _b.trim().split(' ').length;
            }
        }
        return contador;
    }
    get contadorCodigosNoRepetidos() {
        var _a, _b;
        let contador = 0;
        if (this.txtCodigos) {
            if (((_a = this.txtCodigos.value) === null || _a === void 0 ? void 0 : _a.trim().length) > 0) {
                contador = this.limpiarCodigos((_b = this.txtCodigos.value) === null || _b === void 0 ? void 0 : _b.trim()).length;
            }
        }
        return contador;
    }
    ngOnInit() {
        // this.alertaActualizarFuenteDatos();
        this.auth.user$.subscribe(data => {
            this.usuario = data.email;
        });
    }
    menuToogle() {
        this.menuCtrl.toggle();
    }
    alertaConfirmarEtiquetaBobina() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const ipPrint = localStorage.getItem('ipimp');
            if (!ipPrint) {
                this.presentToast('Seleccione una impresora antes de emitir la etiqueta.', 2000, 'warning');
                return;
            }
            const alert = yield this.alertCtrl.create({
                header: 'Reimprimir Etiqueta Bobina SAP',
                message: 'Desea reimprimir Etiqueta de Bobinas SAP?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            // console.log('Confirm Cancel.');
                        }
                    }, {
                        text: 'Enviar',
                        cssClass: 'btnAlertSuccess',
                        handler: (data) => {
                            this.enviarEtiquetaBobina();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    enviarEtiquetaBobina() {
        const etiqueta = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_4__.imprimirEtiquetaModel();
        etiqueta.ipAddress = localStorage.getItem('ipimp');
        etiqueta.modelData = this.txtCodigos.value;
        this.toolService.simpleLoader('Cargando...');
        this.cxpService.postReimprimirEtiquetaBobinaSap(etiqueta).then((data) => {
            if (data.Status === 'T') {
                this.presentToast(data.Message, 5000, 'success');
                this.reestablecerDatos();
            }
            else {
                this.presentToast(data.Message, 5000, 'warning');
            }
        }, (error) => {
            console.error(error);
        }).finally(() => this.toolService.dismissLoader());
    }
    limpiarCodigos(codigos) {
        const arrayCadena = codigos.trim().split(' ');
        const arrayCadenaClean = arrayCadena.filter(Boolean);
        const arrayClean = [...new Set(arrayCadenaClean)];
        return arrayClean;
    }
    reestablecerDatos() {
        this.txtCodigos.value = '';
        setTimeout(() => {
            this.txtCodigos.setFocus();
        }, 250);
    }
    obtenerFecha() {
        const fechaDate = new Date();
        let fechaString = '';
        const anio = fechaDate.getFullYear();
        let dia = '';
        let mes = '';
        let hora = '';
        let minuto = '';
        let segundo = '';
        if (fechaDate.getDate() < 10) {
            dia = `0${fechaDate.getDate()}`;
        }
        else {
            dia = fechaDate.getDate().toString();
        }
        if (fechaDate.getMonth() < 9) {
            mes = `0${fechaDate.getMonth() + 1}`;
        }
        else {
            mes = (fechaDate.getMonth() + 1).toString();
        }
        if (fechaDate.getHours() < 10) {
            hora = `0${fechaDate.getHours()}`;
        }
        else {
            hora = fechaDate.getHours().toString();
        }
        if (fechaDate.getMinutes() < 10) {
            minuto = `0${fechaDate.getMinutes()}`;
        }
        else {
            minuto = fechaDate.getMinutes().toString();
        }
        if (fechaDate.getSeconds() < 10) {
            segundo = `0${fechaDate.getSeconds()}`;
        }
        else {
            segundo = fechaDate.getSeconds().toString();
        }
        fechaString = `${anio}${mes}${dia} ${hora}:${minuto}:${segundo}`;
        console.log(mes);
        return fechaString;
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
};
ReimprimirEtiquetaBobinaSapComponent.ctorParameters = () => [
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_6__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__.ToolService }
];
ReimprimirEtiquetaBobinaSapComponent.propDecorators = {
    btnEnviar: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['btnEnviar',] }],
    txtCodigos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['codigos',] }],
    chkSapEtiqueta: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['sapetiqueta',] }]
};
ReimprimirEtiquetaBobinaSapComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-reimprimir-etiqueta-bobina-sap',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_reimprimir_etiqueta_bobina_sap_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_reimprimir_etiqueta_bobina_sap_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReimprimirEtiquetaBobinaSapComponent);



/***/ }),

/***/ 49641:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/reimprimir-etiqueta-bobina/reimprimir-etiqueta-bobina.component.ts ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReimprimirEtiquetaBobinaComponent": () => (/* binding */ ReimprimirEtiquetaBobinaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_reimprimir_etiqueta_bobina_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./reimprimir-etiqueta-bobina.component.html */ 54454);
/* harmony import */ var _reimprimir_etiqueta_bobina_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reimprimir-etiqueta-bobina.component.scss */ 65611);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);
/* harmony import */ var src_models_entrada_mercancia_etiqueta_pallet_bobina_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/models/entrada-mercancia/etiqueta-pallet-bobina.model */ 10714);








let ReimprimirEtiquetaBobinaComponent = class ReimprimirEtiquetaBobinaComponent {
    constructor(menuCtrl, toastController, alertController, cxpService, toolService) {
        this.menuCtrl = menuCtrl;
        this.toastController = toastController;
        this.alertController = alertController;
        this.cxpService = cxpService;
        this.toolService = toolService;
        this.dtoDatosResponse = {};
    }
    ngOnInit() {
        this.loading = false;
    }
    get disabledBotonImprimir() {
        let sts = true;
        if (this.dtoDatosResponse) {
            if (this.dtoDatosResponse.NOM_PRODUCTO) {
                sts = false;
            }
        }
        return sts;
    }
    menuToogle() {
        this.menuCtrl.toggle();
    }
    obtenerInformacionCaja(cod) {
        this.reestablecerDatos();
        this.loading = true;
        const data = { data: '', ipPrint: '' };
        if (cod.length === 0) {
            this.presentToast('Escanee un codigo antes de continuar.', 2000, 'warning');
            this.loading = false;
            this.codigoSetFocus();
            return;
        }
        data.data = cod.trim();
        this.accionBusqueda(true);
        this.cxpService.postObtenerDatosEtiquetaBobinaEm(data).then((resp) => {
            if (resp.Status.Status === 'T') {
                this.dtoDatosResponse = resp.Response[0];
                console.log(this.dtoDatosResponse);
            }
            else {
                this.presentToast(resp.Status.Message, 2000, 'warning');
            }
        }, (err) => {
            console.warn(err);
        }).finally(() => {
            this.accionBusqueda(false);
        });
    }
    alertaReimprimirEtiquetaPalletBobina(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (!localStorage.getItem('ipimp')) {
                this.presentToast('Seleccione una impresora antes de emitir la etiqueta.', 2000, 'warning');
                return;
            }
            const alert = yield this.alertController.create({
                header: 'Reimprimir Etiqueta',
                message: 'Desea imprimir la etiqueta Pallet Bobina?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            if (event) {
                                event.target.complete();
                            }
                        }
                    }, {
                        text: 'Imprimir',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            this.reimprimirEtiquetaPalletBobina();
                        }
                    }
                ]
            });
            yield alert.present().finally(() => {
                if (event) {
                    event.target.complete();
                }
            });
        });
    }
    reimprimirEtiquetaPalletBobina() {
        this.toolService.simpleLoader('Enviando datos...');
        const etq = new src_models_entrada_mercancia_etiqueta_pallet_bobina_model__WEBPACK_IMPORTED_MODULE_4__.EtiquetaPalletBobinaModel();
        etq.modelData = new src_models_entrada_mercancia_etiqueta_pallet_bobina_model__WEBPACK_IMPORTED_MODULE_4__.ModelData();
        etq.ipAddress = localStorage.getItem('ipimp');
        etq.modelData.descProducto = this.dtoDatosResponse.NOM_PRODUCTO;
        etq.modelData.cliente = this.dtoDatosResponse.CLIENTE;
        etq.modelData.medidas = this.dtoDatosResponse.MEDIDAS;
        etq.modelData.pesoBruto = this.dtoDatosResponse.PESO_BRUTO;
        etq.modelData.pesoNeto = this.dtoDatosResponse.PESO_NETO;
        etq.modelData.ordenFab = this.dtoDatosResponse.ORDEN_FAB;
        etq.modelData.codProducto = this.dtoDatosResponse.COD_PRODUCTO;
        etq.modelData.cantBobinas = this.dtoDatosResponse.CANT_BOB;
        etq.modelData.correlativo = this.dtoDatosResponse.CORRELATIVO;
        etq.modelData.fecha = this.dtoDatosResponse.FECHA;
        // etq.modelData.hora = this.dtoDatosResponse.HORA;
        etq.modelData.codQr = this.dtoDatosResponse.CODBAR_MULTI;
        etq.modelData.sapCorrel = this.dtoDatosResponse.SAP_CORREL;
        this.accionBusqueda(true);
        this.cxpService.postReimprimirEtiquetaBobinaEm(etq).then((resp) => {
            if (resp.Status === 'T') {
                this.presentToast(resp.Message, 3000, 'success');
            }
            else {
                this.presentToast(resp.Message, 4000, 'warning');
            }
        }, (err) => {
            console.warn(err);
        }).finally(() => {
            this.toolService.dismissLoader();
            this.reestablecerDatos();
            this.accionBusqueda(false);
        });
    }
    accionBusqueda(action) {
        this.txtCodigo.disabled = action;
        this.btnCodigo.disabled = action;
        this.loading = action;
        if (action) {
            this.txtCodigo.value = '';
        }
    }
    codigoSetFocus() { setTimeout(() => { this.txtCodigo.setFocus(); }, 300); }
    reestablecerDatos() {
        this.dtoDatosResponse = {};
        this.txtCodigo.value = '';
        this.codigoSetFocus();
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
};
ReimprimirEtiquetaBobinaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__.ToolService }
];
ReimprimirEtiquetaBobinaComponent.propDecorators = {
    txtCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['txtCodigo',] }],
    btnCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['btnCodigo',] }]
};
ReimprimirEtiquetaBobinaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-reimprimir-etiqueta-bobina',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_reimprimir_etiqueta_bobina_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_reimprimir_etiqueta_bobina_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReimprimirEtiquetaBobinaComponent);



/***/ }),

/***/ 16429:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/reimprimir-pt-caja/reimprimir-pt-caja.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReimprimirPtCajaComponent": () => (/* binding */ ReimprimirPtCajaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_reimprimir_pt_caja_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./reimprimir-pt-caja.component.html */ 89915);
/* harmony import */ var _reimprimir_pt_caja_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reimprimir-pt-caja.component.scss */ 36215);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);
/* harmony import */ var src_models_requestEtqCajaPalletModel_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/models/requestEtqCajaPalletModel.model */ 42005);








let ReimprimirPtCajaComponent = class ReimprimirPtCajaComponent {
    constructor(menuCtrl, cxpService, toastController, toolService, alertController) {
        this.menuCtrl = menuCtrl;
        this.cxpService = cxpService;
        this.toastController = toastController;
        this.toolService = toolService;
        this.alertController = alertController;
        this.etRows = [];
        this.loading = false;
    }
    ngOnInit() { }
    ngAfterViewInit() { }
    menuToogle() {
        this.menuCtrl.toggle();
    }
    obtenerInformacionCaja(cod) {
        this.reestablecerDatos();
        this.loading = true;
        if (cod.length === 0) {
            this.presentToast('Escanee un codigo antes de continuar.', 2000, 'warning');
            this.codigoSetFocus();
            return;
        }
        this.accionBusqueda(true);
        this.cxpService.postObtenerDatosEtiqueta(cod).then((resp) => {
            if (resp.Status.Status === 'T') {
                this.dtoDatosResponse = resp;
                this.etRows = this.dtoDatosResponse.Response;
            }
            else {
                this.presentToast(resp.Status.Message, 2000, 'warning');
            }
        }, (err) => {
            console.warn(err);
        }).finally(() => {
            this.accionBusqueda(false);
        });
    }
    alertaConfirmarEtiqueta(data) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Imprimir Etiqueta',
                message: 'Desea imprimir la etiqueta?',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'btnAlertDanger',
                        handler: () => {
                            // console.log('Confirm Cancel.');
                        }
                    }, {
                        text: 'Imprimir',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            this.emitirPalletCajaCoembal(data);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    emitirPalletCajaCoembal(data) {
        const req = new src_models_requestEtqCajaPalletModel_model__WEBPACK_IMPORTED_MODULE_4__.RequestDatosEtiqueta();
        req.data = new src_models_requestEtqCajaPalletModel_model__WEBPACK_IMPORTED_MODULE_4__.Data();
        req.ipPrint = localStorage.getItem('ipimp');
        req.data.descProducto = data.DESC_PRODUCTO;
        req.data.cliente = data.CLIENTE;
        req.data.proceso = data.PROCESO;
        req.data.cantxCaja = data.CANTIDADXCAJA;
        req.data.lote = data.LOTE;
        req.data.color = data.COLOR;
        req.data.codProducto = data.COD_PRODUCTO;
        req.data.cantidadCajas = data.CANTIDAD_CAJAS;
        req.data.correlativo = data.CORRELATIVO;
        req.data.fecha = data.FECHA;
        req.data.codigoQr = data.CODIGO_QR;
        req.data.tipoResina = 'ND';
        req.data.codProceso = 'ND';
        req.data.sapCorrel = data.SAP_CORREL;
        console.log(req);
        this.toolService.simpleLoader('Enviando datos...');
        this.cxpService.postReimprimirCajaPallet(req).then((resp) => {
            if (resp.Status === 'T') {
                this.presentToast('Imprimiendo etiqueta...', 2000, 'success');
                this.reestablecerDatos();
            }
            else {
                this.presentToast(resp.Message, 5000, 'warning');
            }
        }, err => {
            console.error(err);
        }).finally(() => this.toolService.dismissLoader());
    }
    get deshabilitarBotonEnviar() {
        let resp = true;
        if (this.dtoDatosResponse) {
            resp = false;
        }
        return resp;
    }
    codigoSetFocus() { setTimeout(() => { this.txtCodigo.setFocus(); }, 300); }
    accionBusqueda(action) {
        this.txtCodigo.disabled = action;
        this.btnCodigo.disabled = action;
        this.loading = action;
        if (action) {
            this.txtCodigo.value = '';
        }
    }
    reestablecerDatos() {
        this.etRows = [];
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
    successEntradaMercancia() {
        let ok = true;
        const ipPrint = localStorage.getItem('ipimp');
        const login = localStorage.getItem('sapusr');
        if (!ipPrint) {
            this.presentToast('Seleccione una impresora antes de emitir la etiqueta.', 2000, 'warning');
            ok = false;
        }
        if (!login) {
            this.presentToast('Inicie sesión en Sap Business One para Continuar.', 5000, 'warning');
            ok = false;
        }
        return ok;
    }
};
ReimprimirPtCajaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_2__.CxpService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_3__.ToolService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController }
];
ReimprimirPtCajaComponent.propDecorators = {
    txtCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['txtCodigo',] }],
    txtCantCajas: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['cantCajas',] }],
    btnCodigo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: ['btnCodigo',] }]
};
ReimprimirPtCajaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-reimprimir-pt-caja',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_reimprimir_pt_caja_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_reimprimir_pt_caja_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReimprimirPtCajaComponent);



/***/ }),

/***/ 69145:
/*!***************************************************************!*\
  !*** ./src/models/entrada-mercancia/etiqueta-bobina.model.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaBobinaModel": () => (/* binding */ EtiquetaBobinaModel),
/* harmony export */   "Data": () => (/* binding */ Data)
/* harmony export */ });
class EtiquetaBobinaModel {
}
class Data {
}


/***/ }),

/***/ 10714:
/*!**********************************************************************!*\
  !*** ./src/models/entrada-mercancia/etiqueta-pallet-bobina.model.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EtiquetaPalletBobinaModel": () => (/* binding */ EtiquetaPalletBobinaModel),
/* harmony export */   "ModelData": () => (/* binding */ ModelData)
/* harmony export */ });
class EtiquetaPalletBobinaModel {
}
class ModelData {
}


/***/ }),

/***/ 70393:
/*!***************************************************************!*\
  !*** ./src/models/requestEntradaMercanciaCajasModel.model.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RequestEntradaMercancia": () => (/* binding */ RequestEntradaMercancia),
/* harmony export */   "Data": () => (/* binding */ Data)
/* harmony export */ });
class RequestEntradaMercancia {
}
class Data {
}


/***/ }),

/***/ 42005:
/*!*******************************************************!*\
  !*** ./src/models/requestEtqCajaPalletModel.model.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RequestDatosEtiqueta": () => (/* binding */ RequestDatosEtiqueta),
/* harmony export */   "Data": () => (/* binding */ Data)
/* harmony export */ });
class RequestDatosEtiqueta {
}
class Data {
}


/***/ }),

/***/ 30396:
/*!*********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/eliminar-etiqueta-bobina/eliminar-etiqueta-bobina.component.html ***!
  \*********************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n\r\n<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title>Eliminar Etq. Pallet Bobinas</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"background-image\">\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-align-items-center ion-header-row\">\r\n      <ion-col size=\"10\">\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Código de Barra o QR</ion-label>\r\n          <ion-input type=\"text\" #txtCodigo (keyup.enter)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\r\n          </ion-input>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"2\">\r\n        <ion-item button lines=\"none\" #btnCodigo (click)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\r\n          <ion-icon color=\"dark\" name=\"search-outline\"></ion-icon>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-grid fixed *ngIf=\"!disabledBotonImprimir\">\r\n    <ion-row>\r\n      <ion-col size=\"12\">\r\n        <ion-card color=\"danger\">\r\n          <ion-card-header>\r\n            <ion-card-subtitle>Nombre Producto: <strong>{{dtoDatosResponse.NOM_PRODUCTO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Cliente: <strong>{{dtoDatosResponse.CLIENTE}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Medidas: <strong>{{dtoDatosResponse.MEDIDAS}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Peso Bruto: <strong>{{dtoDatosResponse.PESO_BRUTO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Peso Neto: <strong>{{dtoDatosResponse.PESO_NETO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>OF: <strong>{{dtoDatosResponse.ORDEN_FAB}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Código Producto: <strong>{{dtoDatosResponse.COD_PRODUCTO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Nro. Bobinas: <strong>{{dtoDatosResponse.CANT_BOB}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Correlativo: <strong>{{dtoDatosResponse.CORRELATIVO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Fecha: <strong>{{dtoDatosResponse.FECHA}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Hora: <strong>{{dtoDatosResponse.HORA}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Id: <strong>{{dtoDatosResponse.CODBAR_MULTI}}</strong></ion-card-subtitle>\r\n          </ion-card-header>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n\r\n  <ion-grid fixed  *ngIf=\"loading\">\r\n    <ion-row>\r\n      <ion-col size=\"12\">\r\n        <ion-card>\r\n          <ion-card-header class=\"ion-no-padding\">\r\n            <ion-grid fixed>\r\n              <ion-row>\r\n                <ion-col size=\"12\">\r\n                  <ion-skeleton-text animated style=\"width: 50%; padding: 4px;\"></ion-skeleton-text>\r\n                </ion-col>\r\n              </ion-row>\r\n              <ion-row>\r\n                <ion-col size=\"12\">\r\n                  <ion-skeleton-text animated style=\"width: 100%; padding: 5px;\"></ion-skeleton-text>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-grid>\r\n          </ion-card-header>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-title class=\"ion-no-padding-x\">\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col size=\"12\">\r\n\r\n            <ion-button #btnEmision color=\"danger\" expand=\"block\" fill=\"outline\" [disabled]=\"disabledBotonImprimir\"\r\n            (click)=\"alertaReimprimirEtiquetaPalletBobina()\">\r\n              Eliminar\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ }),

/***/ 83401:
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/em-materias-primas/em-materias-primas.component.html ***!
  \*********************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title color=\"medium\"><strong>Entrada Materias Primas</strong></ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n    <ion-grid fixed>\r\n      <ion-row>\r\n        <ion-col size=\"9\">\r\n          <ion-item enterkeyhint=\"prueba()\">\r\n            <ion-label color=\"medium\" position=\"floating\">Escaner de Código</ion-label>\r\n            <ion-input #codbar (keyup.enter)=\"obtenerPallet(codbar.value.toString())\"></ion-input>\r\n            <ion-spinner *ngIf=\"loadCodbar\" slot=\"end\" name=\"lines\"></ion-spinner>\r\n          </ion-item>\r\n        </ion-col>\r\n        <ion-col size=\"3\" class=\"col-barbutton\">\r\n          <ion-button expand=\"block\" shape=\"clear\" fill=\"clear\"\r\n          (click)=\"obtenerPallet(codbar.value.toString())\">\r\n            <ion-icon size=\"large\" slot=\"icon-only\" style=\"zoom:1.5;\" name=\"barcode-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n    <ion-grid fixed>\r\n      <ion-row>\r\n        <ion-col size=\"8\">\r\n          <ion-item>\r\n            <ion-label color=\"medium\"><strong>Cantidad Productos:</strong></ion-label>\r\n          </ion-item>\r\n        </ion-col>\r\n        <ion-col size=\"3\" class=\"ion-padding-start\">\r\n          <ion-item class=\"ion-text-center\">\r\n            <ion-label><strong>{{getCantidadPallet}}</strong></ion-label>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n\r\n<ion-list>\r\n  <ion-item-sliding id=\"{{p.CodBarra}}\"  *ngFor=\"let p of arrayPallet\">\r\n    <ion-item lines=\"none\" id=\"{{p.CodBarra}}\">\r\n      <ion-card style=\"width: 100%;\">\r\n        <ion-item>\r\n          <ion-label color=\"medium\"><strong>{{p.CardName}}</strong></ion-label>\r\n          <ion-button expand=\"block\" fill=\"clear\" disabled>\r\n            Ver\r\n          </ion-button>\r\n        </ion-item>\r\n        <ion-card-content>\r\n          <ion-item>\r\n            <ion-label color=\"medium\"><strong>Cod.Pro.:</strong></ion-label>\r\n            <ion-label><strong>{{p.ItemCode}}</strong></ion-label>\r\n          </ion-item>\r\n          <ion-item>\r\n            <ion-label color=\"medium\"><strong>Cantidad:</strong></ion-label>\r\n            <ion-label><strong>{{p.Quantity}} Kg.</strong></ion-label>\r\n          </ion-item>\r\n          <ion-item class=\"ion-text-center\">\r\n            <ion-label color=\"medium\"><strong>\r\n              {{p.NumeroCarpeta}}\r\n            </strong></ion-label>\r\n          </ion-item>\r\n        </ion-card-content>\r\n      </ion-card>\r\n    </ion-item>\r\n    <ion-item-options side=\"end\" (click)=\"listaEliminarPallet(p)\">\r\n      <ion-item-option color=\"danger\">Remover</ion-item-option>\r\n    </ion-item-options>\r\n  </ion-item-sliding>\r\n</ion-list>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-title>\r\n      <ion-button color=\"success\" expand=\"block\" fill=\"outline\" (click)=\"enviarEntradaMercancia()\">\r\n        Enviar\r\n      </ion-button>\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n\r\n");

/***/ }),

/***/ 19988:
/*!*******************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/em-pallet-bobinas/em-pallet-bobinas.component.html ***!
  \*******************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n\r\n<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title>E.M. Pallet Bobinas</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"10\">\r\n          <ion-item>\r\n            <ion-label position=\"floating\">Código de Barra o QR</ion-label>\r\n            <ion-input type=\"text\" #txtCodigo (keyup.enter)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\r\n            </ion-input>\r\n          </ion-item>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n          <ion-item button lines=\"none\" #btnCodigo (click)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\r\n            <ion-icon color=\"dark\" name=\"search-outline\"></ion-icon>\r\n          </ion-item>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n    <!-- <ion-grid fixed>\r\n\r\n    </ion-grid> -->\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"background-image\">\r\n\r\n  <ion-list>\r\n    <ion-item-sliding #itemSliding id=\"{{p.uidd}}\" *ngFor=\"let p of arrayDtoDatosResponse\" [disabled]=\"p.Data.fase.loadingStatus\">\r\n      <ion-item [disabled]=\"p.Data.fase.loadingStatus\">\r\n        <ion-grid fixed>\r\n          <ion-row>\r\n            <ion-col size=\"12\">\r\n              <ion-card color=\"{{p.Data.fase.labelStatus}}\">\r\n                <ion-card-header>\r\n                  <ion-card-subtitle>Nombre Producto:\r\n                    <strong>{{p.Data.modelData.descProducto}}</strong></ion-card-subtitle>\r\n                  <ion-card-subtitle>Cod. SAP:\r\n                    <strong>{{p.Data.modelData.codProducto}}</strong></ion-card-subtitle>\r\n                  <ion-card-subtitle>Cant. Bobinas:\r\n                    <strong>{{p.Data.modelData.cantBobinas}}</strong></ion-card-subtitle>\r\n                  <ion-card-subtitle>Iden: <strong>{{p.Data.modelData.codQr}}</strong></ion-card-subtitle>\r\n                  <ion-card-subtitle>Estado: <strong>{{p.Data.fase.messageStatus}}</strong></ion-card-subtitle>\r\n                </ion-card-header>\r\n              </ion-card>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n      </ion-item>\r\n      <ion-item-options side=\"end\" (click)=\"eliminarPallet(p, true)\">\r\n        <ion-item-option color=\"danger\">Remover</ion-item-option>\r\n      </ion-item-options>\r\n      <ion-item-options side=\"start\" *ngIf=\"p.Data.fase.labelStatus === 'success'\"\r\n        (click)=\"alertaReimprimirPalletBobina(itemSliding, p)\">\r\n        <ion-item-option color=\"primary\">Imprimir</ion-item-option>\r\n      </ion-item-options>\r\n    </ion-item-sliding>\r\n  </ion-list>\r\n\r\n  <ion-grid fixed  *ngIf=\"countLoadingDtoDatosResponse.length > 0\">\r\n    <ion-row *ngFor=\"let item of countLoadingDtoDatosResponse\" >\r\n      <ion-col size=\"12\">\r\n        <ion-card>\r\n          <ion-card-header class=\"ion-no-padding\">\r\n            <ion-grid fixed>\r\n              <ion-row>\r\n                <ion-col size=\"12\">\r\n                  <ion-skeleton-text animated style=\"width: 50%; padding: 4px;\"></ion-skeleton-text>\r\n                </ion-col>\r\n              </ion-row>\r\n              <ion-row>\r\n                <ion-col size=\"12\">\r\n                  <ion-skeleton-text animated style=\"width: 100%; padding: 5px;\"></ion-skeleton-text>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-grid>\r\n          </ion-card-header>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-title class=\"ion-no-padding-x\">\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col size=\"12\">\r\n            <ion-button #btnEmision color=\"success\" expand=\"block\" fill=\"outline\"  [disabled]=\"disabledBotonImprimir\"\r\n            (click)=\"alertaEnviarEntradaMercanciaPalletBobina()\">\r\n              Enviar\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ }),

/***/ 6047:
/*!***************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/etiqueta-bobina/etiqueta-bobina.component.html ***!
  \***************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"ion-text-left\">\r\n          <ion-title>Etiqueta Pallet Bobinas</ion-title>\r\n        </ion-col>\r\n        <ion-col size=\"2\" class=\"ion-text-left\">\r\n          <ion-title class=\"ion-no-padding\">SAP</ion-title>\r\n          <ion-checkbox #sapetiqueta checked=\"true\"></ion-checkbox>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"alertaActualizarFuenteDatos($event)\">\r\n    <ion-refresher-content></ion-refresher-content>\r\n  </ion-refresher>\r\n\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-row-1 ion-justify-content-center\">\r\n      <ion-col size=\"12\">\r\n        <ion-item class=\"ion-item-1\">\r\n          <ion-textarea #codigos rows=\"18\" placeholder=\"Escanea las bobinas para ingresar...\">\r\n          </ion-textarea>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <ion-col size=\"6\">\r\n        <ion-item>\r\n          <ion-card-subtitle><strong>Cant. de Códigos: {{contadorCodigos}}</strong></ion-card-subtitle>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"6\">\r\n        <ion-item>\r\n          <ion-card-subtitle><strong>Total a Enviar: {{contadorCodigosNoRepetidos}}</strong></ion-card-subtitle>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-title class=\"ion-no-padding-x\">\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col size=\"2\" class=\"ion-no-padding\">\r\n            <ion-button color=\"danger\" expand=\"block\" fill=\"outline\" [disabled]=\"isEnabledEnviar\"\r\n              (click)=\"reestablecerDatos()\">\r\n              <ion-icon style=\"zoom: 10;\" name=\"trash-bin-outline\"></ion-icon>\r\n            </ion-button>\r\n          </ion-col>\r\n          <ion-col size=\"10\" class=\"ion-no-padding\">\r\n            <ion-button #btnEmision color=\"success\" expand=\"block\" fill=\"outline\" [disabled]=\"isEnabledEnviar\"\r\n              (click)=\"alertaConfirmarEtiquetaBobina()\">\r\n              Enviar\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n\r\n<!-- <ion-row class=\"ion-row-2 ion-justify-content-center\">\r\n  <ion-col size=\"12\" class=\"ion-padding\">\r\n    <ion-button #btnEnviar size=\"large\" expand=\"block\" class=\"btn-1\">\r\n      Enviar\r\n    </ion-button>\r\n  </ion-col>\r\n</ion-row> -->");

/***/ }),

/***/ 25571:
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/menu-entrada-mercancia/menu-entrada-mercancia.component.html ***!
  \*****************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-grid fixed>\n      <ion-row class=\"ion-align-items-center ion-header-row\">\n        <ion-col size=\"2\">\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\n            <ion-icon name=\"menu-outline\"></ion-icon>\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"10\" class=\"ion-text-left\">\n          <ion-title color=\"medium\"><strong>Menu Entrada Mercancia</strong></ion-title>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content class=\"background-image\">\n  <ion-grid>\n    <ion-row class=\"ion-margin-top\">\n      <ion-col size=\"12\" *ngIf=\"enabled.etr01 || enabled.etr02\">\n        <ion-label color=\"medium\"><strong>Cajas</strong></ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"ion-justify-content-start\">\n      <ion-col size=\"6\" *ngIf=\"enabled.etr01\">\n        <ion-button class=\"btn-color-cxp\" size=\"large\" expand=\"block\" (click)=\"irPtCaja()\">\n          <span class=\"btn-text\">PT Caja</span>\n        </ion-button>\n      </ion-col>\n\n      <ion-col size=\"6\" *ngIf=\"enabled.etr02\">\n        <ion-button class=\"btn-color-cxp\" size=\"large\" expand=\"block\" (click)=\"irReimprimirPtCaja()\">\n          <ion-grid>\n            <ion-row class=\"ion-no-margin ion-no-padding\">\n              <ion-col>\n                <span class=\"btn-text\">Re-Imprimir Etiqueta</span><br>\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <span class=\"btn-text\">PT Caja</span><br>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-button>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"ion-margin-top\">\n      <ion-col size=\"12\" *ngIf=\"enabled.etr03 || enabled.etr04 || enabled.etr05 || enabled.etr06\">\n        <ion-label color=\"medium\"><strong>Bobinas</strong></ion-label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"ion-justify-content-start\">\n      <ion-col size=\"6\" *ngIf=\"enabled.etr03\">\n        <ion-button class=\"btn-color-cxp\" size=\"large\" expand=\"block\" (click)=\"irEtiquetaPalletBobina()\">\n          <ion-grid>\n            <ion-row class=\"ion-no-margin ion-no-padding\">\n              <ion-col>\n                <span class=\"btn-text\">Emisión</span><br>\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <span class=\"btn-text\">Etiqueta Bobina</span><br>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-button>\n      </ion-col>\n\n      <ion-col size=\"6\" *ngIf=\"enabled.etr04\">\n        <ion-button class=\"btn-color-cxp\" size=\"large\" expand=\"block\" (click)=\"irReimprimirEtiquetaPalletBobina()\">\n          <ion-grid>\n            <ion-row class=\"ion-no-margin ion-no-padding\">\n              <ion-col>\n                <span class=\"btn-text\">Reimpresión</span><br>\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <span class=\"btn-text\">Etiqueta Bobina</span><br>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-button>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"ion-justify-content-start\">\n      <ion-col size=\"6\" *ngIf=\"enabled.etr05\">\n        <ion-button class=\"btn-color-cxp\" size=\"large\" expand=\"block\" (click)=\"irEliminarEtiquetaPalletBobina()\">\n          <ion-grid>\n            <ion-row class=\"ion-no-margin ion-no-padding\">\n              <ion-col>\n                <span class=\"btn-text\">Eliminar</span><br>\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <span class=\"btn-text\">Etiqueta Bobina</span><br>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-button>\n      </ion-col>\n\n      <ion-col size=\"6\" *ngIf=\"enabled.etr06\">\n        <ion-button class=\"btn-color-cxp\" size=\"large\" expand=\"block\" (click)=\"irEmPalletBobina()\">\n          <ion-grid>\n            <ion-row class=\"ion-no-margin ion-no-padding\">\n              <ion-col>\n                <span class=\"btn-text\">Entrada Mercancia</span><br>\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <span class=\"btn-text\">Pallets Bobina</span><br>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-button>\n      </ion-col>\n    </ion-row>\n\n\n    <ion-row class=\"ion-justify-content-start\">\n      <ion-col size=\"6\" *ngIf=\"enabled.etr04\">\n        <ion-button class=\"btn-color-cxp\" size=\"large\" expand=\"block\" (click)=\"irReimprimirEtiquetaPalletBobinaSap()\">\n          <ion-grid>\n            <ion-row class=\"ion-no-margin ion-no-padding\">\n              <ion-col>\n                <span class=\"btn-text\">Reimpresión</span><br>\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <span class=\"btn-text\">Correl. Bobina Sap</span><br>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-button>\n      </ion-col>\n\n    </ion-row>\n\n  </ion-grid>\n</ion-content>");

/***/ }),

/***/ 39160:
/*!***********************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/pt-caja/pt-caja.component.html ***!
  \***********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-grid fixed>\n      <ion-row class=\"ion-align-items-center ion-header-row\">\n        <ion-col size=\"2\">\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\n            <ion-icon name=\"menu-outline\"></ion-icon>\n          </ion-button>\n        </ion-col>\n        <ion-col size=\"10\" class=\"ion-text-left\">\n          <ion-title>Entrada Pallet Cajas</ion-title>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"background-image\">\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"alertaActualizarFuenteDatos($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n  <ion-grid fixed>\n    <ion-row class=\"ion-align-items-center ion-header-row\">\n      <ion-col size=\"10\">\n        <ion-item>\n          <ion-label position=\"floating\">Código de Barra o QR</ion-label>\n          <ion-input type=\"text\" #txtCodigo (keyup.enter)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\n          </ion-input>\n        </ion-item>\n      </ion-col>\n      <ion-col size=\"2\">\n        <ion-item button lines=\"none\" #btnCodigo (click)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\n          <ion-icon color=\"dark\" name=\"search-outline\"></ion-icon>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid fixed *ngIf=\"dtoDatosResponse\">\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-subtitle>Cliente: <strong>{{cliente}}</strong></ion-card-subtitle>\n            <ion-card-subtitle>\n              <ion-grid fixed class=\"ion-no-padding\">\n                <ion-row>\n                  <ion-col size=\"3\">OF: <strong>{{ordenFab}}</strong></ion-col>\n                  <ion-col size=\"9\"><strong>{{producto}}</strong></ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-card-subtitle>\n          </ion-card-header>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n  <ion-grid *ngIf=\"loading\" fixed>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card>\n          <ion-card-header class=\"ion-no-padding\">\n            <ion-grid fixed>\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-skeleton-text animated style=\"width: 50%; padding: 4px;\"></ion-skeleton-text>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-skeleton-text animated style=\"width: 100%; padding: 5px;\"></ion-skeleton-text>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-card-header>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid fixed class=\"ion-margin-top\" *ngIf=\"dtoDatosResponse\">\n    <ion-row class=\"ion-align-items-center\">\n      <ion-item style=\"width: 100%;\">\n        <ion-col size=\"8\">\n          <ion-label position=\"relative\">Cantidad de Cajas: </ion-label>\n        </ion-col>\n        <ion-col size=\"4\" class=\"\">\n          <ion-input type=\"number\" #cantCajas min=\"0\" max=\"1000\">\n          </ion-input>\n        </ion-col>\n      </ion-item>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar>\n    <ion-title class=\"ion-no-padding-x\">\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"3\">\n            <ion-button color=\"danger\" expand=\"block\" fill=\"outline\" (click)=\"reestablecerDatos()\">\n              Borrar\n            </ion-button>\n          </ion-col>\n          <ion-col size=\"9\">\n            <ion-button #btnEmision color=\"success\" expand=\"block\" fill=\"outline\" [disabled]=\"deshabilitarBotonEnviar\"\n              (click)=\"alertaConfirmarEtiqueta()\">\n              Emitir\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-title>\n  </ion-toolbar>\n</ion-footer>\n");

/***/ }),

/***/ 96982:
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/reimprimir-etiqueta-bobina-sap/reimprimir-etiqueta-bobina-sap.component.html ***!
  \*********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" class=\"ion-text-left\">\r\n          <ion-title>(RE) Bobina Sap</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n  <!-- <ion-refresher slot=\"fixed\" (ionRefresh)=\"alertaActualizarFuenteDatos($event)\">\r\n    <ion-refresher-content></ion-refresher-content>\r\n  </ion-refresher> -->\r\n\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-row-1 ion-justify-content-center\">\r\n      <ion-col size=\"12\">\r\n        <ion-item class=\"ion-item-1\">\r\n          <ion-textarea #codigos rows=\"18\" placeholder=\"Escanea las bobinas para ingresar...\">\r\n          </ion-textarea>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <ion-col size=\"6\">\r\n        <ion-item>\r\n          <ion-card-subtitle><strong>Cant. de Códigos: {{contadorCodigos}}</strong></ion-card-subtitle>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"6\">\r\n        <ion-item>\r\n          <ion-card-subtitle><strong>Total Reimprimir: {{contadorCodigosNoRepetidos}}</strong></ion-card-subtitle>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-title class=\"ion-no-padding-x\">\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col size=\"2\" class=\"ion-no-padding\">\r\n            <ion-button color=\"danger\" expand=\"block\" fill=\"outline\" [disabled]=\"isEnabledEnviar\"\r\n              (click)=\"reestablecerDatos()\">\r\n              <ion-icon style=\"zoom: 10;\" name=\"trash-bin-outline\"></ion-icon>\r\n            </ion-button>\r\n          </ion-col>\r\n          <ion-col size=\"10\" class=\"ion-no-padding\">\r\n            <ion-button #btnEmision color=\"success\" expand=\"block\" fill=\"outline\" [disabled]=\"isEnabledEnviar\"\r\n              (click)=\"alertaConfirmarEtiquetaBobina()\">\r\n              Enviar\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-footer>");

/***/ }),

/***/ 54454:
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/reimprimir-etiqueta-bobina/reimprimir-etiqueta-bobina.component.html ***!
  \*************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n\r\n<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title>Reimp. Etq. Pallet Bobinas</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"background-image\">\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-align-items-center ion-header-row\">\r\n      <ion-col size=\"10\">\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Código de Barra o QR</ion-label>\r\n          <ion-input type=\"text\" #txtCodigo (keyup.enter)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\r\n          </ion-input>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"2\">\r\n        <ion-item button lines=\"none\" #btnCodigo (click)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\r\n          <ion-icon color=\"dark\" name=\"search-outline\"></ion-icon>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-grid fixed *ngIf=\"!disabledBotonImprimir\">\r\n    <ion-row>\r\n      <ion-col size=\"12\">\r\n        <ion-card color=\"success\">\r\n          <ion-card-header>\r\n            <ion-card-subtitle>Nombre Producto: <strong>{{dtoDatosResponse.NOM_PRODUCTO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Cliente: <strong>{{dtoDatosResponse.CLIENTE}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Medidas: <strong>{{dtoDatosResponse.MEDIDAS}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Peso Bruto: <strong>{{dtoDatosResponse.PESO_BRUTO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Peso Neto: <strong>{{dtoDatosResponse.PESO_NETO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>OF: <strong>{{dtoDatosResponse.ORDEN_FAB}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Código Producto: <strong>{{dtoDatosResponse.COD_PRODUCTO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Nro. Bobinas: <strong>{{dtoDatosResponse.CANT_BOB}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Correlativo: <strong>{{dtoDatosResponse.CORRELATIVO}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Fecha: <strong>{{dtoDatosResponse.FECHA}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Hora: <strong>{{dtoDatosResponse.HORA}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>Id: <strong>{{dtoDatosResponse.CODBAR_MULTI}}</strong></ion-card-subtitle>\r\n          </ion-card-header>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n\r\n  <ion-grid fixed  *ngIf=\"loading\">\r\n    <ion-row>\r\n      <ion-col size=\"12\">\r\n        <ion-card>\r\n          <ion-card-header class=\"ion-no-padding\">\r\n            <ion-grid fixed>\r\n              <ion-row>\r\n                <ion-col size=\"12\">\r\n                  <ion-skeleton-text animated style=\"width: 50%; padding: 4px;\"></ion-skeleton-text>\r\n                </ion-col>\r\n              </ion-row>\r\n              <ion-row>\r\n                <ion-col size=\"12\">\r\n                  <ion-skeleton-text animated style=\"width: 100%; padding: 5px;\"></ion-skeleton-text>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-grid>\r\n          </ion-card-header>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-title class=\"ion-no-padding-x\">\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col size=\"12\">\r\n\r\n            <ion-button #btnEmision color=\"success\" expand=\"block\" fill=\"outline\" [disabled]=\"disabledBotonImprimir\"\r\n            (click)=\"alertaReimprimirEtiquetaPalletBobina()\">\r\n              Imprimir\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ }),

/***/ 89915:
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/entrada-mercancia/reimprimir-pt-caja/reimprimir-pt-caja.component.html ***!
  \*********************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title>Reimprimir Pallet Cajas</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"background-image\">\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-align-items-center ion-header-row\">\r\n      <ion-col size=\"10\">\r\n        <ion-item>\r\n          <ion-label position=\"floating\">QR/Orden</ion-label>\r\n          <ion-input type=\"text\" #txtCodigo (keyup.enter)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\r\n          </ion-input>\r\n        </ion-item>\r\n      </ion-col>\r\n      <ion-col size=\"2\">\r\n        <ion-item button lines=\"none\" #btnCodigo (click)=\"obtenerInformacionCaja(txtCodigo.value.toString())\">\r\n          <ion-icon color=\"dark\" name=\"search-outline\"></ion-icon>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-grid fixed *ngIf=\"etRows.length > 0\">\r\n    <ion-row>\r\n      <ion-col size=\"12\" *ngFor=\"let row of etRows\" >\r\n        <ion-card>\r\n          <ion-card-header>\r\n            <ion-card-subtitle>Cliente: <strong>{{row['CLIENTE']}}</strong></ion-card-subtitle>\r\n            <ion-card-subtitle>\r\n              <ion-grid fixed class=\"ion-no-padding\">\r\n                <ion-row>\r\n                  <ion-col style=\"padding-bottom: 8px;\" size=\"12\">OF: <strong>{{row['LOTE']}}</strong></ion-col>\r\n                </ion-row>\r\n              </ion-grid>\r\n            </ion-card-subtitle>\r\n            <ion-card-subtitle>\r\n              <ion-grid fixed class=\"ion-no-padding\">\r\n                <ion-row>\r\n                  <ion-col style=\"padding-bottom: 8px;\" size=\"12\">Correlativo: <strong>{{row['CORRELATIVO']}}</strong></ion-col>\r\n                </ion-row>\r\n              </ion-grid>\r\n            </ion-card-subtitle>\r\n            <ion-row>\r\n              <ion-col class=\"ion-no-padding\" size=\"12\"><strong>{{row['CODIGO_QR']}}</strong></ion-col>\r\n            </ion-row>\r\n            <ion-grid fixed>\r\n              <ion-row class=\"ion-justify-content-center\">\r\n                <ion-col size=\"10\">\r\n                  <ion-button expand=\"block\" color=\"success\" (click)=\"alertaConfirmarEtiqueta(row)\">\r\n                    Seleccionar\r\n                  </ion-button>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-grid>\r\n          </ion-card-header>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n\r\n  <ion-grid *ngIf=\"loading\" fixed>\r\n    <ion-row>\r\n      <ion-col size=\"12\">\r\n        <ion-card>\r\n          <ion-card-header class=\"ion-no-padding\">\r\n            <ion-grid fixed>\r\n              <ion-row>\r\n                <ion-col size=\"12\">\r\n                  <ion-skeleton-text animated style=\"width: 50%; padding: 4px;\"></ion-skeleton-text>\r\n                </ion-col>\r\n              </ion-row>\r\n              <ion-row>\r\n                <ion-col size=\"12\">\r\n                  <ion-skeleton-text animated style=\"width: 100%; padding: 5px;\"></ion-skeleton-text>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-grid>\r\n          </ion-card-header>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n<!-- <ion-footer>\r\n  <ion-toolbar>\r\n    <ion-title class=\"ion-no-padding-x\">\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col size=\"3\">\r\n            <ion-button color=\"danger\" expand=\"block\" fill=\"outline\" (click)=\"reestablecerDatos()\">\r\n              Borrar\r\n            </ion-button>\r\n          </ion-col>\r\n          <ion-col size=\"9\">\r\n            <ion-button #btnEmision color=\"success\" expand=\"block\" fill=\"outline\" [disabled]=\"deshabilitarBotonEnviar\"\r\n              (click)=\"alertaConfirmarEtiqueta()\">\r\n              Emitir\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-title>\r\n  </ion-toolbar>\r\n</ion-footer> -->\r\n");

/***/ }),

/***/ 66751:
/*!******************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/eliminar-etiqueta-bobina/eliminar-etiqueta-bobina.component.scss ***!
  \******************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGltaW5hci1ldGlxdWV0YS1ib2JpbmEuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 19815:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/em-materias-primas/ent-materias-primas.component.scss ***!
  \*******************************************************************************************************/
/***/ ((module) => {

module.exports = ".col-barbutton {\n  display: flex;\n  align-content: center;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVudC1tYXRlcmlhcy1wcmltYXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSxhQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtBQUFGIiwiZmlsZSI6ImVudC1tYXRlcmlhcy1wcmltYXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLmNvbC1iYXJidXR0b24ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 94531:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/em-pallet-bobinas/em-pallet-bobinas.component.scss ***!
  \****************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbS1wYWxsZXQtYm9iaW5hcy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 69313:
/*!************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/etiqueta-bobina/etiqueta-bobina.component.scss ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJldGlxdWV0YS1ib2JpbmEuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 62073:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/menu-entrada-mercancia/menu-entrada-mercancia.component.scss ***!
  \**************************************************************************************************************/
/***/ ((module) => {

module.exports = ".background-image {\n  --background: url('background-login.png') 0 0/100% 100% no-repeat;\n}\n\n.ion-header-row {\n  padding-left: 0px;\n}\n\n.btn-text {\n  font-size: 0.6em;\n  font-weight: bold;\n  color: #797979;\n}\n\n.btn-prop {\n  --background: #8d8f050b;\n}\n\n.row {\n  margin-top: 2em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnUtZW50cmFkYS1tZXJjYW5jaWEuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxpRUFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSx1QkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtBQUNGIiwiZmlsZSI6Im1lbnUtZW50cmFkYS1tZXJjYW5jaWEuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmFja2dyb3VuZC1pbWFnZSB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB1cmwoJy4uLy4uLy4uLy4uLy4uL2Fzc2V0cy9pbWcvbG9naW4vYmFja2dyb3VuZC1sb2dpbi5wbmcnKSAwIDAvMTAwJSAxMDAlIG5vLXJlcGVhdDtcclxufVxyXG5cclxuLmlvbi1oZWFkZXItcm93IHtcclxuICBwYWRkaW5nLWxlZnQ6IDBweDtcclxufVxyXG5cclxuLmJ0bi10ZXh0IHtcclxuICBmb250LXNpemU6IDAuNmVtO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIGNvbG9yOiByZ2IoMTIxLCAxMjEsIDEyMSk7XHJcbn1cclxuXHJcbi5idG4tcHJvcCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjOGQ4ZjA1MGI7XHJcbn1cclxuXHJcbi5yb3cge1xyXG4gIG1hcmdpbi10b3A6IDJlbTtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 32949:
/*!********************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/pt-caja/pt-caja.component.scss ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwdC1jYWphLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 24832:
/*!******************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/reimprimir-etiqueta-bobina-sap/reimprimir-etiqueta-bobina-sap.component.scss ***!
  \******************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWltcHJpbWlyLWV0aXF1ZXRhLWJvYmluYS1zYXAuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 65611:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/reimprimir-etiqueta-bobina/reimprimir-etiqueta-bobina.component.scss ***!
  \**********************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWltcHJpbWlyLWV0aXF1ZXRhLWJvYmluYS5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 36215:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/coembal/entrada-mercancia/reimprimir-pt-caja/reimprimir-pt-caja.component.scss ***!
  \******************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWltcHJpbWlyLXB0LWNhamEuY29tcG9uZW50LnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coembal_entrada-mercancia_entrada-mercancia_module_ts.js.map