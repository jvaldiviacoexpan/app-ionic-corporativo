"use strict";
(self["webpackChunkapp_ionic_corporativo"] = self["webpackChunkapp_ionic_corporativo"] || []).push([["src_app_pages_root_configuracion_configuracion_module_ts"],{

/***/ 66353:
/*!***************************************************************************!*\
  !*** ./src/app/pages/root/configuracion/conf-menu/conf-menu.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfMenuComponent": () => (/* binding */ ConfMenuComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_conf_menu_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./conf-menu.component.html */ 12681);
/* harmony import */ var _conf_menu_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./conf-menu.component.scss */ 12991);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/security.service */ 46691);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 76491);











let ConfMenuComponent = class ConfMenuComponent {
    constructor(menu, route, auth, auth0Serv, securityService, toolService) {
        this.menu = menu;
        this.route = route;
        this.auth = auth;
        this.auth0Serv = auth0Serv;
        this.securityService = securityService;
        this.toolService = toolService;
        this.enabled = {
            cfg01: false,
            cfg02: false,
        };
        this.showThisContent$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject({});
    }
    menuToogle() {
        this.menu.toggle();
    }
    irPermisos() {
        this.route.navigateByUrl('pages/root/config/lista-usuarios');
    }
    ngAfterViewInit() {
        this.toolService.simpleLoader('Cargando...');
        this.obtenerRoles();
    }
    obtenerRoles() {
        this.auth.user$.subscribe((user) => {
            this.auth0Serv.getAuth().then((resp) => {
                const userdata = {
                    idToken: resp.access_token,
                    idUser: user.sub,
                };
                const datarest = this.securityService.encrypt(JSON.stringify(userdata));
                this.auth0Serv.getUserRoles(datarest).then((restuser) => {
                    this.showThisContent$.next({ datauser: restuser.app_metadata.roles });
                    this.habilitarModulos();
                }, (err) => {
                    // Todo Falta informacion adicional
                });
            }, (err) => {
                // Todo Falta informacion adicional
            }).finally(() => this.toolService.dismissLoader());
        });
    }
    habilitarModulos() {
        const cfg01 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'cfg01' && el.enabled === true);
        const cfg02 = this.showThisContent$.value.datauser
            .find((el) => el.id === 'cfg02' && el.enabled === true);
        if (cfg01 !== undefined) {
            this.enabled.cfg01 = true;
        }
        if (cfg02 !== undefined) {
            this.enabled.cfg02 = true;
        }
    }
};
ConfMenuComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__.AuthService },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__.SecurityService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__.ToolService }
];
ConfMenuComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-conf-menu',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_conf_menu_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_conf_menu_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ConfMenuComponent);



/***/ }),

/***/ 3126:
/*!**************************************************************************!*\
  !*** ./src/app/pages/root/configuracion/configuracion-routing.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfiguracionRoutingModule": () => (/* binding */ ConfiguracionRoutingModule),
/* harmony export */   "configuracionRouterComponents": () => (/* binding */ configuracionRouterComponents)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _configuracion_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./configuracion.component */ 26129);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _conf_menu_conf_menu_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./conf-menu/conf-menu.component */ 66353);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _lista_usuarios_permisos_permisos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lista-usuarios/permisos/permisos.component */ 48708);
/* harmony import */ var _lista_usuarios_lista_usuarios_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lista-usuarios/lista-usuarios.component */ 16494);








const routes = [{
        path: '',
        component: _configuracion_component__WEBPACK_IMPORTED_MODULE_0__.ConfiguracionComponent,
        children: [
            {
                path: 'conf-menu',
                component: _conf_menu_conf_menu_component__WEBPACK_IMPORTED_MODULE_1__.ConfMenuComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_4__.AuthGuard]
            },
            {
                path: 'permisos',
                component: _lista_usuarios_permisos_permisos_component__WEBPACK_IMPORTED_MODULE_2__.PermisosComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_4__.AuthGuard]
            },
            {
                path: 'lista-usuarios',
                component: _lista_usuarios_lista_usuarios_component__WEBPACK_IMPORTED_MODULE_3__.ListaUsuariosComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_4__.AuthGuard]
            }
        ]
    }];
let ConfiguracionRoutingModule = class ConfiguracionRoutingModule {
};
ConfiguracionRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule]
    })
], ConfiguracionRoutingModule);

const configuracionRouterComponents = [
    _conf_menu_conf_menu_component__WEBPACK_IMPORTED_MODULE_1__.ConfMenuComponent,
    _lista_usuarios_permisos_permisos_component__WEBPACK_IMPORTED_MODULE_2__.PermisosComponent,
    _lista_usuarios_lista_usuarios_component__WEBPACK_IMPORTED_MODULE_3__.ListaUsuariosComponent
];


/***/ }),

/***/ 80858:
/*!******************************************************************!*\
  !*** ./src/app/pages/root/configuracion/configuracion.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfiguracionModule": () => (/* binding */ ConfiguracionModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ionic-selectable */ 74068);
/* harmony import */ var _configuracion_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./configuracion-routing.module */ 3126);







let ConfiguracionModule = class ConfiguracionModule {
};
ConfiguracionModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            ionic_selectable__WEBPACK_IMPORTED_MODULE_6__.IonicSelectableModule,
            _configuracion_routing_module__WEBPACK_IMPORTED_MODULE_0__.ConfiguracionRoutingModule
        ],
        declarations: [
            ..._configuracion_routing_module__WEBPACK_IMPORTED_MODULE_0__.configuracionRouterComponents
        ]
    })
], ConfiguracionModule);



/***/ }),

/***/ 16494:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/root/configuracion/lista-usuarios/lista-usuarios.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListaUsuariosComponent": () => (/* binding */ ListaUsuariosComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_lista_usuarios_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./lista-usuarios.component.html */ 6120);
/* harmony import */ var _lista_usuarios_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lista-usuarios.component.scss */ 76994);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/security.service */ 46691);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _permisos_permisos_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./permisos/permisos.component */ 48708);









let ListaUsuariosComponent = class ListaUsuariosComponent {
    constructor(menu, auth0Service, securityService, route, modalController) {
        this.menu = menu;
        this.auth0Service = auth0Service;
        this.securityService = securityService;
        this.route = route;
        this.modalController = modalController;
        this.arrayUsers = [];
    }
    ngOnInit() {
        this.auth0ObtenerListaUsuarios();
    }
    ngAfterViewInit() { }
    menuToogle() {
        this.menu.toggle();
    }
    auth0ObtenerListaUsuarios() {
        this.auth0Service.getAuth().then((resp) => {
            const userdata = {
                idToken: resp.access_token,
            };
            const datarest = this.securityService.encrypt(JSON.stringify(userdata));
            this.auth0Service.getUserList(datarest).then((users) => {
                this.arrayUsers = users.sort((a, b) => {
                    if (a.name < b.name) {
                        return -1;
                    }
                    if (a.name > b.name) {
                        return 1;
                    }
                    return 0;
                });
                console.log(users);
            }, (err) => {
                console.warn(err);
            });
        }, (err) => {
            console.warn(err);
        });
    }
    // Elminar
    irPermisos(user) {
        this.user = user;
        this.route.navigateByUrl('pages/root/config/conf-menu');
    }
    createRange(nmb) {
        return new Array(nmb).fill(0)
            .map((n, index) => index + 1);
    }
    modalPermisos(user) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _permisos_permisos_component__WEBPACK_IMPORTED_MODULE_4__.PermisosComponent,
                componentProps: {
                    usuario: user,
                }
            });
            modal.onDidDismiss().then((data) => {
                console.log(data);
            });
            yield modal.present();
        });
    }
};
ListaUsuariosComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__.SecurityService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController }
];
ListaUsuariosComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-lista-usuarios',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_lista_usuarios_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_lista_usuarios_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ListaUsuariosComponent);



/***/ }),

/***/ 48708:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/root/configuracion/lista-usuarios/permisos/permisos.component.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PermisosComponent": () => (/* binding */ PermisosComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_permisos_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./permisos.component.html */ 12754);
/* harmony import */ var _permisos_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./permisos.component.scss */ 2083);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../providers/external/security.service */ 46691);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../providers/external/tools.service */ 859);








let PermisosComponent = class PermisosComponent {
    constructor(navParams, menu, modalController, auth0Service, securityService, toolService) {
        this.navParams = navParams;
        this.menu = menu;
        this.modalController = modalController;
        this.auth0Service = auth0Service;
        this.securityService = securityService;
        this.toolService = toolService;
        this.roles = [];
    }
    ngOnInit() {
        this.roles = [];
        this.user = this.navParams.data.usuario;
    }
    ngAfterViewInit() {
        this.obtenerRoles();
    }
    obtenerRoles() {
        console.log(this.user);
        this.auth0Service.getAuth().then((resp) => {
            const userdata = {
                idToken: resp.access_token,
                idUser: this.user.user_id,
            };
            const datarest = this.securityService.encrypt(JSON.stringify(userdata));
            this.auth0Service.getUserRoles(datarest).then((respp) => {
                console.log(respp.app_metadata);
                if (respp.app_metadata) {
                    this.roles = respp.app_metadata.roles;
                    setTimeout(() => {
                        this.cargarPermisos();
                    }, 50);
                }
                else {
                    this.roles.push('init');
                }
            }, (err) => {
                console.error(err);
                this.roles = [];
            });
        }, (err) => {
            console.error(err);
        });
    }
    menuToogle() {
        this.menu.toggle();
    }
    tooglePermisos(toogle, empresa, modulo, descripcion, componente) {
        const rol = {
            id: componente,
            enabled: toogle,
            business: empresa,
            zone: modulo,
            description: descripcion,
        };
        this.adminRoles(rol);
    }
    adminRoles(data) {
        console.log(data);
        let find = false;
        this.roles.forEach((obj) => {
            if (obj.id) {
                if (obj.id === data.id) {
                    obj.enabled = data.enabled;
                    find = true;
                }
            }
        });
        if (!find) {
            this.roles.push(data);
        }
        console.log(this.roles);
    }
    dismissData() {
        this.toolService.simpleLoader('Cargando...');
        const roles = {
            roles: this.roles,
        };
        const metadata = {
            // eslint-disable-next-line @typescript-eslint/naming-convention
            app_metadata: roles,
        };
        this.auth0Service.getAuth().then((resp) => {
            const userdata = {
                idToken: resp.access_token,
                idUser: this.user.user_id,
                appMetada: JSON.stringify(metadata),
            };
            console.log(userdata);
            const datarest = this.securityService.encrypt(JSON.stringify(userdata));
            this.auth0Service.updateUser(datarest).then((data) => {
                console.log(data);
            }, (err) => {
                console.error(err);
            });
        }, (err) => {
            console.error(err);
        }).finally(() => {
            this.modalController.dismiss();
            this.toolService.dismissLoader();
        });
    }
    dismiss() {
        this.modalController.dismiss();
    }
    //#endregion CODIGO LOGICO NO MODIFICAR
    cargarPermisos() {
        console.log('cargar permisos');
        this.roles.forEach((data) => {
            console.log(data);
            if (data.id) {
                switch (data.id) {
                    // Configuracion
                    case 'cfg01':
                        this.tglCfg01.checked = data.enabled;
                        break;
                    case 'cfg02':
                        this.tglCfg02.checked = data.enabled;
                        break;
                    // Materias Primas
                    case 'mpr01':
                        this.tglMpr01.checked = data.enabled;
                        break;
                    case 'mpr02':
                        this.tglMpr02.checked = data.enabled;
                        break;
                    // Inventario
                    case 'inv01':
                        this.tglInv01.checked = data.enabled;
                        break;
                    case 'inv02':
                        this.tglInv02.checked = data.enabled;
                        break;
                    case 'inv03':
                        this.tglInv03.checked = data.enabled;
                        break;
                    case 'inv04':
                        this.tglInv04.checked = data.enabled;
                        break;
                    case 'inv05':
                        this.tglInv05.checked = data.enabled;
                        break;
                    case 'inv06':
                        this.tglInv06.checked = data.enabled;
                        break;
                    case 'inv07':
                        this.tglInv07.checked = data.enabled;
                        break;
                    // Entrada Mercancia
                    case 'etr01':
                        this.tglEtr01.checked = data.enabled;
                        break;
                    case 'etr02':
                        this.tglEtr02.checked = data.enabled;
                        break;
                    case 'etr03':
                        this.tglEtr03.checked = data.enabled;
                        break;
                    case 'etr04':
                        this.tglEtr04.checked = data.enabled;
                        break;
                    case 'etr05':
                        this.tglEtr05.checked = data.enabled;
                        break;
                    case 'etr06':
                        this.tglEtr06.checked = data.enabled;
                        break;
                    // Registro Paradas
                    case 'rgp01':
                        this.tglRgp01.checked = data.enabled;
                        break;
                    case 'rgp02':
                        this.tglRgp02.checked = data.enabled;
                        break;
                    default:
                        break;
                }
            }
        });
    }
};
PermisosComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavParams },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__.SecurityService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__.ToolService }
];
PermisosComponent.propDecorators = {
    tglCfg01: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['cfg01',] }],
    tglCfg02: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['cfg02',] }],
    tglMpr01: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['mpr01',] }],
    tglMpr02: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['mpr02',] }],
    tglInv01: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['inv01',] }],
    tglInv02: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['inv02',] }],
    tglInv03: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['inv03',] }],
    tglInv04: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['inv04',] }],
    tglInv05: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['inv05',] }],
    tglInv06: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['inv06',] }],
    tglInv07: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['inv07',] }],
    tglEtr01: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['etr01',] }],
    tglEtr02: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['etr02',] }],
    tglEtr03: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['etr03',] }],
    tglEtr04: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['etr04',] }],
    tglEtr05: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['etr05',] }],
    tglEtr06: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['etr06',] }],
    tglRgp01: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['rgp01',] }],
    tglRgp02: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['rgp02',] }]
};
PermisosComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-permisos',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_permisos_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_permisos_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], PermisosComponent);



/***/ }),

/***/ 12681:
/*!********************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/root/configuracion/conf-menu/conf-menu.component.html ***!
  \********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\" *ngIf=\"enabled.cfg01 || enabled.cfg02\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title>Configuracíon</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"background-image\">\r\n  <ion-grid>\r\n    <ion-row class=\"ion-justify-content-between\" style=\"margin-top: 40px;\">\r\n      <ion-col  class=\"ion-text-center cube ripple\" size=\"6\" (click)=\"irPermisos()\" *ngIf=\"enabled.cfg01\" >\r\n        <ion-icon color=\"warning\" class=\"standard-icon\" name=\"key-outline\" size=\"large\"></ion-icon>\r\n        <ion-text color=\"dark\">\r\n          <h5 class=\"standard-text\">Permisos</h5>\r\n        </ion-text>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"6\" class=\"ion-text-center cube ripple\" *ngIf=\"enabled.cfg02\">\r\n        <ion-icon style=\"color: rgb(66, 66, 66);\" class=\"standard-icon\" name=\"print-outline\" size=\"large\"></ion-icon>\r\n        <ion-text color=\"dark\">\r\n          <h5 class=\"standard-text\">Impresora</h5>\r\n        </ion-text>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n</ion-content>\r\n");

/***/ }),

/***/ 6120:
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/root/configuracion/lista-usuarios/lista-usuarios.component.html ***!
  \******************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title>Lista Usuarios</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-row>\r\n    <ion-col size=\"12\">\r\n      <div *ngIf=\"arrayUsers.length === 0\">\r\n        <ion-item *ngFor=\"let i of createRange(3)\">\r\n          <ion-skeleton-text animated style=\"width: 70%; height: 40%\"></ion-skeleton-text>\r\n        </ion-item>\r\n      </div>\r\n\r\n      <ion-item *ngFor=\"let i of arrayUsers; let n = index\" (click)=\"modalPermisos(i)\">\r\n        <ion-label> {{i.name | titlecase}} </ion-label>\r\n      </ion-item>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-content>\r\n\r\n\r\n\r\n");

/***/ }),

/***/ 12754:
/*!*********************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/root/configuracion/lista-usuarios/permisos/permisos.component.html ***!
  \*********************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title>{{user.name | titlecase}}</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n\r\n  <div class=\"row ion-margin-top\" *ngIf=\"roles.length === 0\">\r\n    <div class=\"col\">\r\n      <ion-skeleton-text animated style=\"width: 100%; height: 600%\"></ion-skeleton-text>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"row ion-margin-top\" *ngIf=\"roles.length !== 0\">\r\n    <div class=\"col\">\r\n      <div class=\"tabs\">\r\n\r\n        <div class=\"tab\">\r\n          <input type=\"checkbox\" id=\"chck0\">\r\n          <label class=\"tab-label\" for=\"chck0\">Configuración</label>\r\n          <div class=\"tab-content\">\r\n            <ion-item>\r\n              <ion-label>Permisos</ion-label>\r\n              <ion-toggle #cfg01 (click)=\"tooglePermisos(!cfg01.checked, 'cfg', 'configuracion', 'permisos', 'cfg01')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Param. Impresoras</ion-label>\r\n              <ion-toggle #cfg02\r\n                (click)=\"tooglePermisos(!cfg02.checked, 'cfg', 'configuracion', 'parametros-impresora', 'cfg02')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"tab\">\r\n          <input type=\"checkbox\" id=\"chck1\">\r\n          <label class=\"tab-label\" for=\"chck1\">Materias Primas</label>\r\n          <div class=\"tab-content\">\r\n\r\n            <ion-item>\r\n              <ion-label>Emisión Etiqueta</ion-label>\r\n              <ion-toggle #mpr01\r\n                (click)=\"tooglePermisos(!mpr01.checked, 'cxp', 'materias-primas', 'emision-etiqueta', 'mpr01')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Re-Imprimir Etiqueta</ion-label>\r\n              <ion-toggle #mpr02\r\n                (click)=\"tooglePermisos(!mpr02.checked, 'cxp', 'materias-primas', 'reimprimir-pallet', 'mpr02')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"tab\">\r\n          <input type=\"checkbox\" id=\"chck6\">\r\n          <label class=\"tab-label\" for=\"chck6\">Inventario</label>\r\n          <div class=\"tab-content\">\r\n            <ion-item>\r\n              <ion-label>Inventario Coembal</ion-label>\r\n              <ion-toggle #inv01\r\n                (click)=\"tooglePermisos(!inv01.checked, 'cmb', 'inventario', 'inventario-coembal', 'inv01')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Inventario Coexpan</ion-label>\r\n              <ion-toggle #inv02\r\n                (click)=\"tooglePermisos(!inv02.checked, 'cmb', 'inventario', 'inventario-coexpan', 'inv02')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Inventario Coembal Correa</ion-label>\r\n              <ion-toggle #inv03\r\n                (click)=\"tooglePermisos(!inv03.checked, 'cmb', 'inventario', 'inventario-coembal-correa', 'inv03')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Inventario Coexpan Correa</ion-label>\r\n              <ion-toggle #inv04\r\n                (click)=\"tooglePermisos(!inv04.checked, 'cmb', 'inventario', 'inventario-coexpan-correa', 'inv04')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Transferencia Stock</ion-label>\r\n              <ion-toggle #inv05\r\n                (click)=\"tooglePermisos(!inv05.checked, 'cmb', 'inventario', 'transferencia-stock', 'inv05')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Transferencia Stock Masivo</ion-label>\r\n              <ion-toggle #inv06\r\n                (click)=\"tooglePermisos(!inv06.checked, 'cmb', 'inventario', 'transferencia-stock-masivo', 'inv06')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Moler Extrusión</ion-label>\r\n              <ion-toggle #inv07\r\n                (click)=\"tooglePermisos(!inv07.checked, 'cmb', 'entrada-mercancia', 'moler-extrusion', 'inv07')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"tab\">\r\n          <input type=\"checkbox\" id=\"chck8\">\r\n          <label class=\"tab-label\" for=\"chck8\">Entrada Mercancía</label>\r\n          <div class=\"tab-content\">\r\n            <ion-item>\r\n              <ion-label>PT Caja</ion-label>\r\n              <ion-toggle #etr01\r\n                (click)=\"tooglePermisos(!etr01.checked, 'cmb', 'entrada-mercancia', 'pt-caja', 'etr01')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Reimpresión Etq. PT Caja</ion-label>\r\n              <ion-toggle #etr02\r\n                (click)=\"tooglePermisos(!etr02.checked, 'cmb', 'entrada-mercancia', 'reimpresion-pt-caja', 'etr02')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Etiqueta Bobina</ion-label>\r\n              <ion-toggle #etr03\r\n                (click)=\"tooglePermisos(!etr03.checked, 'cmb', 'entrada-mercancia', 'etiqueta-bobina', 'etr03')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Reimpresión Etq. Bobina</ion-label>\r\n              <ion-toggle #etr04\r\n                (click)=\"tooglePermisos(!etr04.checked, 'cmb', 'entrada-mercancia', 'reimpresion-etq-bobina', 'etr04')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Eliminar Etq. Bobina</ion-label>\r\n              <ion-toggle #etr05\r\n                (click)=\"tooglePermisos(!etr05.checked, 'cmb', 'entrada-mercancia', 'eliminar-etq-bobina', 'etr05')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Entrada Mercancía Bobina</ion-label>\r\n              <ion-toggle #etr06\r\n                (click)=\"tooglePermisos(!etr06.checked, 'cmb', 'entrada-mercancia', 'entrada-mercancia-bobina', 'etr06')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"tab\">\r\n          <input type=\"checkbox\" id=\"chck7\">\r\n          <label class=\"tab-label\" for=\"chck7\">Registro Paradas</label>\r\n          <div class=\"tab-content\">\r\n            <ion-item>\r\n              <ion-label>Registro Paradas Coembal</ion-label>\r\n              <ion-toggle #rgp01\r\n                (click)=\"tooglePermisos(!rgp01.checked, 'cmb', 'registro-paradas', 'registro-paradas-coembal', 'rgp01')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n              <ion-label>Registro Paradas Coexpan</ion-label>\r\n              <ion-toggle #rgp02\r\n                (click)=\"tooglePermisos(!rgp02.checked, 'cmb', 'registro-paradas', 'registro-paradas-coexpan', 'rgp02')\">\r\n              </ion-toggle>\r\n            </ion-item>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-justify-content-center\">\r\n        <ion-col size=\"6\">\r\n          <ion-button color=\"danger\" expand=\"block\" fill=\"solid\" (click)=\"dismiss()\">\r\n            Cancelar\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"6\">\r\n          <ion-button color=\"success\" expand=\"block\" fill=\"solid\" (click)=\"dismissData()\">\r\n            Guardar\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>");

/***/ }),

/***/ 12991:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/root/configuracion/conf-menu/conf-menu.component.scss ***!
  \*****************************************************************************/
/***/ ((module) => {

module.exports = ".cube {\n  border-radius: 30%;\n  background-color: white;\n  height: 100px;\n  width: 100px;\n}\n\n.standard-icon {\n  zoom: 1.8;\n}\n\n.standard-text {\n  margin: 0px 0px 0px 0px;\n  color: #424242;\n}\n\n.ripple {\n  background-position: center;\n  transition: background 0.7s;\n}\n\n.ripple:hover {\n  background: white radial-gradient(circle, transparent 1%, white 1%) center/15000%;\n}\n\n.ripple:active {\n  background-color: #e6e6ff;\n  background-size: 100%;\n  transition: background 0s;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmYtbWVudS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUtFLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQUpGOztBQU9BO0VBQ0UsU0FBQTtBQUpGOztBQU9BO0VBQ0UsdUJBQUE7RUFDQSxjQUFBO0FBSkY7O0FBT0E7RUFDRSwyQkFBQTtFQUNBLDJCQUFBO0FBSkY7O0FBTUE7RUFDRSxpRkFBQTtBQUhGOztBQUtBO0VBQ0UseUJBQUE7RUFDQSxxQkFBQTtFQUNBLHlCQUFBO0FBRkYiLCJmaWxlIjoiY29uZi1tZW51LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5jdWJlIHtcclxuICAvLyBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gIC8vIGJvcmRlci1jb2xvcjogYmx1ZTtcclxuICAvLyBoZWlnaHQ6IDEwMHB4O1xyXG4gIC8vIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgYm9yZGVyLXJhZGl1czogMzAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTtcclxuICBoZWlnaHQ6IDEwMHB4O1xyXG4gIHdpZHRoOiAxMDBweDtcclxufVxyXG5cclxuLnN0YW5kYXJkLWljb24ge1xyXG4gIHpvb206IDEuODtcclxufVxyXG5cclxuLnN0YW5kYXJkLXRleHQge1xyXG4gIG1hcmdpbjogMHB4IDBweCAwcHggMHB4O1xyXG4gIGNvbG9yOiByZ2IoNjYsIDY2LCA2NilcclxufVxyXG5cclxuLnJpcHBsZSB7XHJcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC43cztcclxufVxyXG4ucmlwcGxlOmhvdmVyIHtcclxuICBiYWNrZ3JvdW5kOiByZ2IoMjU1LCAyNTUsIDI1NSkgcmFkaWFsLWdyYWRpZW50KGNpcmNsZSwgdHJhbnNwYXJlbnQgMSUsIHJnYigyNTUsIDI1NSwgMjU1KSAxJSkgY2VudGVyLzE1MDAwJTtcclxufVxyXG4ucmlwcGxlOmFjdGl2ZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogaHNsKDI0MiwgMTAwJSwgOTUlKTtcclxuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCU7XHJcbiAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwcztcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 76994:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/root/configuracion/lista-usuarios/lista-usuarios.component.scss ***!
  \***************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsaXN0YS11c3Vhcmlvcy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 2083:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/root/configuracion/lista-usuarios/permisos/permisos.component.scss ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "@charset \"UTF-8\";\nbody {\n  color: #818181ca;\n  background: #ecf0f1;\n  padding: 0 1em 1em;\n}\nh1 {\n  margin: 0;\n  line-height: 2;\n  text-align: center;\n}\nh2 {\n  margin: 0 0 0.5em;\n  font-weight: normal;\n}\ninput {\n  position: absolute;\n  opacity: 0;\n  z-index: -1;\n}\n.row {\n  display: flex;\n}\n.row .col {\n  flex: 1;\n}\n.row .col:last-child {\n  margin-left: 1em;\n  margin-right: 1em;\n}\n/* Accordion styles */\n.tabs {\n  border-radius: 8px;\n  overflow: hidden;\n  box-shadow: 0 4px 4px -2px rgba(0, 0, 0, 0.5);\n}\n.tab {\n  width: 100%;\n  color: white;\n  overflow: hidden;\n}\n.tab-label {\n  display: flex;\n  justify-content: space-between;\n  padding: 1em;\n  background: #818181ca;\n  font-weight: bold;\n  cursor: pointer;\n  /* Icon */\n}\n.tab-label:hover {\n  background: rgba(104, 104, 104, 0.7921568627);\n}\n.tab-label::after {\n  content: \"❯\";\n  width: 1em;\n  height: 1em;\n  text-align: center;\n  transition: all 0.35s;\n}\n.tab-content {\n  max-height: 0;\n  padding: 0 1em;\n  color: #818181ca;\n  background: white;\n  transition: all 0.35s;\n}\n.tab-close {\n  display: flex;\n  justify-content: flex-end;\n  padding: 1em;\n  font-size: 0.75em;\n  background: #818181ca;\n  cursor: pointer;\n}\n.tab-close:hover {\n  background: rgba(104, 104, 104, 0.7921568627);\n}\ninput:checked + .tab-label {\n  background: rgba(104, 104, 104, 0.7921568627);\n}\ninput:checked + .tab-label::after {\n  transform: rotate(90deg);\n}\ninput:checked ~ .tab-content {\n  max-height: 100vh;\n  padding: 1em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBlcm1pc29zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQUloQjtFQUNFLGdCQUxTO0VBTVQsbUJBTE87RUFNUCxrQkFBQTtBQUZGO0FBS0E7RUFDRSxTQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBRkY7QUFLQTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7QUFGRjtBQUtBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQUZGO0FBTUE7RUFDRSxhQUFBO0FBSEY7QUFLRTtFQUNFLE9BQUE7QUFISjtBQUtJO0VBQ0UsZ0JBQUE7RUFDQSxpQkFBQTtBQUhOO0FBUUEscUJBQUE7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2Q0FBQTtBQUxGO0FBUUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBTEY7QUFPRTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFlBQUE7RUFDQSxxQkF6RE87RUEwRFAsaUJBQUE7RUFDQSxlQUFBO0VBRUEsU0FBQTtBQU5KO0FBT0k7RUFDRSw2Q0FBQTtBQUxOO0FBUUk7RUFDRSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0FBTk47QUFVRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBOUVPO0VBK0VQLGlCQUFBO0VBQ0EscUJBQUE7QUFSSjtBQVdFO0VBQ0UsYUFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EscUJBeEZPO0VBeUZQLGVBQUE7QUFUSjtBQVdJO0VBQ0UsNkNBQUE7QUFUTjtBQWdCRTtFQUNFLDZDQUFBO0FBYko7QUFlSTtFQUNFLHdCQUFBO0FBYk47QUFpQkU7RUFDRSxpQkFBQTtFQUNBLFlBQUE7QUFmSiIsImZpbGUiOiJwZXJtaXNvcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbmJvZHkge1xuICBjb2xvcjogIzgxODE4MWNhO1xuICBiYWNrZ3JvdW5kOiAjZWNmMGYxO1xuICBwYWRkaW5nOiAwIDFlbSAxZW07XG59XG5cbmgxIHtcbiAgbWFyZ2luOiAwO1xuICBsaW5lLWhlaWdodDogMjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5oMiB7XG4gIG1hcmdpbjogMCAwIDAuNWVtO1xuICBmb250LXdlaWdodDogbm9ybWFsO1xufVxuXG5pbnB1dCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgb3BhY2l0eTogMDtcbiAgei1pbmRleDogLTE7XG59XG5cbi5yb3cge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuLnJvdyAuY29sIHtcbiAgZmxleDogMTtcbn1cbi5yb3cgLmNvbDpsYXN0LWNoaWxkIHtcbiAgbWFyZ2luLWxlZnQ6IDFlbTtcbiAgbWFyZ2luLXJpZ2h0OiAxZW07XG59XG5cbi8qIEFjY29yZGlvbiBzdHlsZXMgKi9cbi50YWJzIHtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3gtc2hhZG93OiAwIDRweCA0cHggLTJweCByZ2JhKDAsIDAsIDAsIDAuNSk7XG59XG5cbi50YWIge1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IHdoaXRlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLnRhYi1sYWJlbCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcGFkZGluZzogMWVtO1xuICBiYWNrZ3JvdW5kOiAjODE4MTgxY2E7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIC8qIEljb24gKi9cbn1cbi50YWItbGFiZWw6aG92ZXIge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDEwNCwgMTA0LCAxMDQsIDAuNzkyMTU2ODYyNyk7XG59XG4udGFiLWxhYmVsOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwi4p2vXCI7XG4gIHdpZHRoOiAxZW07XG4gIGhlaWdodDogMWVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHRyYW5zaXRpb246IGFsbCAwLjM1cztcbn1cbi50YWItY29udGVudCB7XG4gIG1heC1oZWlnaHQ6IDA7XG4gIHBhZGRpbmc6IDAgMWVtO1xuICBjb2xvcjogIzgxODE4MWNhO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgdHJhbnNpdGlvbjogYWxsIDAuMzVzO1xufVxuLnRhYi1jbG9zZSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIHBhZGRpbmc6IDFlbTtcbiAgZm9udC1zaXplOiAwLjc1ZW07XG4gIGJhY2tncm91bmQ6ICM4MTgxODFjYTtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuLnRhYi1jbG9zZTpob3ZlciB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTA0LCAxMDQsIDEwNCwgMC43OTIxNTY4NjI3KTtcbn1cblxuaW5wdXQ6Y2hlY2tlZCArIC50YWItbGFiZWwge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDEwNCwgMTA0LCAxMDQsIDAuNzkyMTU2ODYyNyk7XG59XG5pbnB1dDpjaGVja2VkICsgLnRhYi1sYWJlbDo6YWZ0ZXIge1xuICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG59XG5pbnB1dDpjaGVja2VkIH4gLnRhYi1jb250ZW50IHtcbiAgbWF4LWhlaWdodDogMTAwdmg7XG4gIHBhZGRpbmc6IDFlbTtcbn0iXX0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_root_configuracion_configuracion_module_ts.js.map