"use strict";
(self["webpackChunkapp_ionic_corporativo"] = self["webpackChunkapp_ionic_corporativo"] || []).push([["src_app_pages_coembal_registro-paradas_registro-paradas_module_ts"],{

/***/ 5356:
/*!*****************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/regex.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i);

/***/ }),

/***/ 2580:
/*!***************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/rng.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ rng)
/* harmony export */ });
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
var getRandomValues;
var rnds8 = new Uint8Array(16);
function rng() {
  // lazy load so that environments that need to polyfill have a chance to do so
  if (!getRandomValues) {
    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation. Also,
    // find the complete implementation of crypto (msCrypto) on IE11.
    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto !== 'undefined' && typeof msCrypto.getRandomValues === 'function' && msCrypto.getRandomValues.bind(msCrypto);

    if (!getRandomValues) {
      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
    }
  }

  return getRandomValues(rnds8);
}

/***/ }),

/***/ 15022:
/*!*********************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/stringify.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _validate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validate.js */ 21917);

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

var byteToHex = [];

for (var i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).substr(1));
}

function stringify(arr) {
  var offset = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  var uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase(); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!(0,_validate_js__WEBPACK_IMPORTED_MODULE_0__.default)(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (stringify);

/***/ }),

/***/ 62230:
/*!**************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/v4.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _rng_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rng.js */ 2580);
/* harmony import */ var _stringify_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stringify.js */ 15022);



function v4(options, buf, offset) {
  options = options || {};
  var rnds = options.random || (options.rng || _rng_js__WEBPACK_IMPORTED_MODULE_0__.default)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (var i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return (0,_stringify_js__WEBPACK_IMPORTED_MODULE_1__.default)(rnds);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (v4);

/***/ }),

/***/ 21917:
/*!********************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/validate.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _regex_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./regex.js */ 5356);


function validate(uuid) {
  return typeof uuid === 'string' && _regex_js__WEBPACK_IMPORTED_MODULE_0__.default.test(uuid);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (validate);

/***/ }),

/***/ 53682:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/coembal/cmb-extrusion/registro-paradas/registro-paradas.component.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroParadasComponent": () => (/* binding */ RegistroParadasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


let RegistroParadasComponent = class RegistroParadasComponent {
    constructor() {
    }
};
RegistroParadasComponent.ctorParameters = () => [];
RegistroParadasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'app-registro-paradas',
        template: '<ion-router-outlet></ion-router-outlet>',
    })
], RegistroParadasComponent);



/***/ }),

/***/ 1613:
/*!**************************************************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-modal-registro-parada/cmb-modal-registro-causa/cmb-modal-registro-causa.component.ts ***!
  \**************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CmbModalRegistroCausaComponent": () => (/* binding */ CmbModalRegistroCausaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cmb_modal_registro_causa_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./cmb-modal-registro-causa.component.html */ 25707);
/* harmony import */ var _cmb_modal_registro_causa_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cmb-modal-registro-causa.component.scss */ 56979);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../models/anymodels.model */ 58301);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../providers/internal/cxp.service */ 1743);








let CmbModalRegistroCausaComponent = class CmbModalRegistroCausaComponent {
    constructor(navParams, modalController, toastController, 
    // private motivosService: MotivosService,
    cxpService) {
        this.navParams = navParams;
        this.modalController = modalController;
        this.toastController = toastController;
        this.cxpService = cxpService;
        this.registroMotivos = [];
        // console.log(navParams.get('motivos'));
        if (navParams.get('motivos') !== undefined) {
            this.registroMotivos = navParams.get('motivos');
        }
    }
    ngOnInit() {
        // this.motivos = this.motivosService.getMotivos();
        this.obtenerMotivosParadas();
        this.obtenerMaquinas();
    }
    obtenerMotivosParadas() {
        const obj = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.ParamRequest();
        obj.paramRequest = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.ParamArea();
        obj.paramRequest.area = this.navParams.data.registro.area;
        this.cxpService.obtenerMotivoParadas(obj).then((data) => {
            console.log(data.Objeto);
            this.motivos = data.Objeto;
        }, (err) => {
            console.warn(err);
        });
    }
    obtenerMaquinas() {
        const obj = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.ParamRequest();
        obj.paramRequest = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.ParamArea();
        obj.paramRequest.area = this.navParams.data.registro.area;
        this.cxpService.obtenerMaquinas(obj).then((data) => {
            console.log(data.Objeto);
            this.maquinas = data.Objeto;
        }, (err) => {
            console.warn(err);
        });
    }
    agregarCausa() {
        // console.log('Se agrego un item!');
        this.registroMotivos.push(new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.RegistroMotivosModel({
            motivo: null,
            minutos: null,
        }));
    }
    prueba(data) {
        console.log(data);
        console.log(this.registroMotivos);
    }
    eliminarRegistro(r) {
        const i = this.registroMotivos.indexOf(r);
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        if (i !== -1) {
            this.registroMotivos.splice(i, 1);
            // this.presentToast('Registro Eliminado.', 2000, 'medium');
        }
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
    dismissData() {
        this.modalController.dismiss(this.registroMotivos);
    }
    dismiss() {
        this.modalController.dismiss();
    }
};
CmbModalRegistroCausaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavParams },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_3__.CxpService }
];
CmbModalRegistroCausaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-modal-registro-causa',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cmb_modal_registro_causa_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_cmb_modal_registro_causa_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], CmbModalRegistroCausaComponent);



/***/ }),

/***/ 69011:
/*!**************************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-modal-registro-parada/cmb-modal-registro-parada.component.ts ***!
  \**************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CmbModalRegistroParadaComponent": () => (/* binding */ CmbModalRegistroParadaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cmb_modal_registro_parada_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./cmb-modal-registro-parada.component.html */ 37133);
/* harmony import */ var _cmb_modal_registro_parada_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cmb-modal-registro-parada.component.scss */ 277);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! uuid */ 62230);
/* harmony import */ var _providers_internal_maquinas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../providers/internal/maquinas.service */ 34530);
/* harmony import */ var _providers_internal_motivos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../providers/internal/motivos.service */ 24854);
/* harmony import */ var _models_anymodels_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../models/anymodels.model */ 58301);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _cmb_modal_registro_causa_cmb_modal_registro_causa_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cmb-modal-registro-causa/cmb-modal-registro-causa.component */ 1613);











let CmbModalRegistroParadaComponent = class CmbModalRegistroParadaComponent {
    constructor(navParams, modalController, maquinasService, motivosService, cxpService) {
        this.navParams = navParams;
        this.modalController = modalController;
        this.maquinasService = maquinasService;
        this.motivosService = motivosService;
        this.cxpService = cxpService;
        this.registro = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_4__.RegistroParadaModel();
        if (navParams.get('parada') !== undefined) {
            this.registro = navParams.get('parada');
        }
    }
    get validacionDatos() {
        var _a;
        // console.log(this.registro);
        if (
        // this.registro.maquina     === undefined ||
        this.registro.supervisor === undefined ||
            this.registro.fecha === undefined ||
            this.registro.turno === undefined ||
            ((_a = this.registro.motivos) === null || _a === void 0 ? void 0 : _a.length) < 0 ||
            this.registro.observacion === undefined) {
            return true;
        }
        else {
            return false;
        }
    }
    ngOnInit() {
        this.maquinas = this.maquinasService.getMaquinas();
        this.motivos = this.motivosService.getMotivos();
        this.registro.fecha = new Date();
        // this.obtenerSupervisores();
    }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _cmb_modal_registro_causa_cmb_modal_registro_causa_component__WEBPACK_IMPORTED_MODULE_6__.CmbModalRegistroCausaComponent,
                componentProps: {
                    registro: this.registro,
                }
            });
            modal.onDidDismiss().then((data) => {
                var _a;
                // console.log(data);
                if (data.data === undefined) {
                    // console.log('Sin Datos');
                }
                else {
                    this.registro.motivos = data.data;
                    this.registro.nroMotivos = (_a = this.registro.motivos) === null || _a === void 0 ? void 0 : _a.length;
                }
            });
            yield modal.present();
        });
    }
    dismiss() {
        this.modalController.dismiss();
    }
    dismissData() {
        if (this.registro.uid === undefined) {
            this.registro.uid = (0,uuid__WEBPACK_IMPORTED_MODULE_8__.default)();
        }
        this.modalController.dismiss(this.registro);
    }
    onClick() {
        // console.log(this.registro);
    }
    // Servicios
    obtenerSupervisores(area) {
        const obj = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_4__.ParamRequest();
        obj.paramRequest = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_4__.ParamSupervisores();
        obj.paramRequest.area = area;
        obj.paramRequest.empresa = 'CMB';
        this.cxpService.obtenerSupervisadores(obj).then((data) => {
            this.listaSupervisores = data.Objeto;
        }, err => {
            console.warn(err);
        });
    }
};
CmbModalRegistroParadaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavParams },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _providers_internal_maquinas_service__WEBPACK_IMPORTED_MODULE_2__.MaquinasService },
    { type: _providers_internal_motivos_service__WEBPACK_IMPORTED_MODULE_3__.MotivosService },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_5__.CxpService }
];
CmbModalRegistroParadaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-modal-registro-parada',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cmb_modal_registro_parada_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_cmb_modal_registro_parada_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], CmbModalRegistroParadaComponent);



/***/ }),

/***/ 7341:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-registro-paradas.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CmbRegistroParadasComponent": () => (/* binding */ CmbRegistroParadasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cmb_registro_paradas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./cmb-registro-paradas.component.html */ 59962);
/* harmony import */ var _cmb_registro_paradas_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cmb-registro-paradas.component.scss */ 22873);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _cmb_modal_registro_parada_cmb_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cmb-modal-registro-parada/cmb-modal-registro-parada.component */ 69011);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);








let CmbRegistroParadasComponent = class CmbRegistroParadasComponent {
    constructor(toastController, alertController, modalController, cxpService, toolService) {
        this.toastController = toastController;
        this.alertController = alertController;
        this.modalController = modalController;
        this.cxpService = cxpService;
        this.toolService = toolService;
        this.registros = [];
    }
    ngOnInit() { }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _cmb_modal_registro_parada_cmb_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_2__.CmbModalRegistroParadaComponent,
            });
            modal.onDidDismiss().then((data) => {
                // console.log(data);
                if (data.data === undefined) {
                    // console.log('Sin Datos');
                }
                else {
                    this.registros.push(data.data);
                }
            });
            yield modal.present();
        });
    }
    obtenerArea(id) {
        switch (id) {
            case '1': return 'Extrusión';
            case '2': return 'Termoformado';
            case '3': return 'Impresión';
            case '4': return 'Etiquetado';
            case '5': return 'Rebordeado';
            default: return 'No especificado';
        }
    }
    alertaInformacionParada(r) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Información de Detención',
                message: `
      <strong>Supervisor</strong>: ${this.obtenerArea(r.area)}<hr>
      <strong>Supervisor</strong>: ${r.supervisor}<hr>
      <strong>Turno:</strong> ${r.turno}<hr>
      <strong>Motivos:</strong> ${r.nroMotivos}<hr>
      <strong>Fecha:</strong> ${r.fecha}<hr>
      <strong>Observación:</strong> ${r.observacion}<hr>`,
                buttons: [
                    {
                        text: 'Continuar',
                        role: 'cancel',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            // console.log('Confirm Cancel.');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    enviarRegistros() {
        if (this.registros.length <= 0) {
            this.presentToast('Debe registrar alguna Parada antes de continuar.', 3000, 'warning');
            return;
        }
        this.toolService.simpleLoader('Enviando...');
        // console.log(JSON.stringify(this.registros));
        this.cxpService.enviarRegistrosParadas(this.registros).then((data) => {
            // console.log(data);
            if (data.Status === 'T') {
                this.presentToast('Paradas registradas.', 3000, 'success');
                this.registros = [];
            }
            else {
                this.presentToast(data.Message, 3000, 'danger');
            }
            this.toolService.dismissLoader();
            // console.log(data);
        }, (err) => {
            this.presentToast('Error en registrar Paradas.', 3000, 'danger');
            this.toolService.dismissLoader();
        });
    }
    modificarDatos(rp) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _cmb_modal_registro_parada_cmb_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_2__.CmbModalRegistroParadaComponent,
                componentProps: {
                    parada: rp,
                }
            });
            modal.onDidDismiss().then((data) => {
                // console.log(data);
                if (data.data !== undefined) {
                    if (this.registros.length <= 0) {
                        this.registros.push(data.data);
                        // console.log('se agrego!');
                    }
                    else {
                        // console.log(data.data.uid);
                        this.registros.forEach(el => {
                            if (data.data.uid === el.uid) {
                                el = data.data;
                            }
                            else {
                                this.registros.push(data.data);
                            }
                        });
                    }
                }
            });
            yield modal.present();
        });
    }
    eliminarRegistro(r) {
        const i = this.registros.indexOf(r);
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        if (i !== -1) {
            this.registros.splice(i, 1);
            this.presentToast('Registro Eliminado.', 2000, 'medium');
        }
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
};
CmbRegistroParadasComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_3__.CxpService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__.ToolService }
];
CmbRegistroParadasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-registro-paradas',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cmb_registro_paradas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_cmb_registro_paradas_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], CmbRegistroParadasComponent);



/***/ }),

/***/ 52308:
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/cxp-registro-paradas.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CxpRegistroParadasComponent": () => (/* binding */ CxpRegistroParadasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cxp_registro_paradas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./cxp-registro-paradas.component.html */ 25757);
/* harmony import */ var _cxp_registro_paradas_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cxp-registro-paradas.component.scss */ 11550);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _modal_registro_parada_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-registro-parada/modal-registro-parada.component */ 4712);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/internal/cxp.service */ 1743);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);








let CxpRegistroParadasComponent = class CxpRegistroParadasComponent {
    constructor(toastController, alertController, modalController, cxpService, toolService) {
        this.toastController = toastController;
        this.alertController = alertController;
        this.modalController = modalController;
        this.cxpService = cxpService;
        this.toolService = toolService;
        this.registros = [];
    }
    ngOnInit() { }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modal_registro_parada_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_2__.ModalRegistroParadaComponent,
            });
            modal.onDidDismiss().then((data) => {
                // console.log(data);
                if (data.data === undefined) {
                    // console.log('Sin Datos');
                }
                else {
                    this.registros.push(data.data);
                }
            });
            yield modal.present();
        });
    }
    obtenerArea(id) {
        switch (id) {
            case '1': return 'Extrusión';
            case '2': return 'Termoformado';
            case '3': return 'Impresión';
            case '4': return 'Etiquetado';
            case '5': return 'Rebordeado';
            default: return 'No especificado';
        }
    }
    alertaInformacionParada(r) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Información de Detención',
                message: `
      <strong>Supervisor</strong>: ${this.obtenerArea(r.area)}<hr>
      <strong>Supervisor</strong>: ${r.supervisor}<hr>
      <strong>Turno:</strong> ${r.turno}<hr>
      <strong>Motivos:</strong> ${r.nroMotivos}<hr>
      <strong>Fecha:</strong> ${r.fecha}<hr>
      <strong>Observación:</strong> ${r.observacion}<hr>`,
                buttons: [
                    {
                        text: 'Continuar',
                        role: 'cancel',
                        cssClass: 'btnAlertSuccess',
                        handler: () => {
                            // console.log('Confirm Cancel.');
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    enviarRegistros() {
        if (this.registros.length <= 0) {
            this.presentToast('Debe registrar alguna Parada antes de continuar.', 3000, 'warning');
            return;
        }
        this.toolService.simpleLoader('Enviando...');
        console.log(JSON.stringify(this.registros));
        this.cxpService.enviarRegistrosParadas(this.registros).then((data) => {
            // console.log(data);
            if (data.Status === 'T') {
                this.presentToast('Paradas registradas.', 3000, 'success');
                this.registros = [];
            }
            else {
                this.presentToast(data.Message, 3000, 'danger');
            }
            this.toolService.dismissLoader();
            // console.log(data);
        }, (err) => {
            this.presentToast('Error en registrar Paradas.', 3000, 'danger');
            this.toolService.dismissLoader();
        });
    }
    modificarDatos(rp) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modal_registro_parada_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_2__.ModalRegistroParadaComponent,
                componentProps: {
                    parada: rp,
                }
            });
            modal.onDidDismiss().then((data) => {
                // console.log(data);
                if (data.data !== undefined) {
                    if (this.registros.length <= 0) {
                        this.registros.push(data.data);
                        // console.log('se agrego!');
                    }
                    else {
                        // console.log(data.data.uid);
                        this.registros.forEach(el => {
                            if (data.data.uid === el.uid) {
                                el = data.data;
                            }
                            else {
                                this.registros.push(data.data);
                            }
                        });
                    }
                }
            });
            yield modal.present();
        });
    }
    eliminarRegistro(r) {
        const i = this.registros.indexOf(r);
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        if (i !== -1) {
            this.registros.splice(i, 1);
            this.presentToast('Registro Eliminado.', 2000, 'medium');
        }
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
};
CxpRegistroParadasComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_3__.CxpService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__.ToolService }
];
CxpRegistroParadasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-cxp-registro-paradas',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_cxp_registro_paradas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_cxp_registro_paradas_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], CxpRegistroParadasComponent);



/***/ }),

/***/ 66072:
/*!**************************************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/modal-registro-parada/modal-registro-causa/modal-registro-causa.component.ts ***!
  \**************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalRegistroCausaComponent": () => (/* binding */ ModalRegistroCausaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_registro_causa_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./modal-registro-causa.component.html */ 90757);
/* harmony import */ var _modal_registro_causa_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-registro-causa.component.scss */ 27601);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../models/anymodels.model */ 58301);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../providers/internal/cxp.service */ 1743);








let ModalRegistroCausaComponent = class ModalRegistroCausaComponent {
    constructor(navParams, modalController, toastController, 
    // private motivosService: MotivosService,
    cxpService) {
        this.navParams = navParams;
        this.modalController = modalController;
        this.toastController = toastController;
        this.cxpService = cxpService;
        this.registroMotivos = [];
        // console.log(navParams.get('motivos'));
        if (navParams.get('motivos') !== undefined) {
            this.registroMotivos = navParams.get('motivos');
        }
    }
    ngOnInit() {
        // this.motivos = this.motivosService.getMotivos();
        this.obtenerMotivosParadas();
        this.obtenerMaquinas();
    }
    obtenerMotivosParadas() {
        const obj = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.ParamRequest();
        obj.paramRequest = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.ParamArea();
        obj.paramRequest.area = 1;
        this.cxpService.obtenerMotivoParadas(obj).then((data) => {
            console.log(data.Objeto);
            this.motivos = data.Objeto;
        }, (err) => {
            console.warn(err);
        });
    }
    obtenerMaquinas() {
        const obj = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.ParamRequest();
        obj.paramRequest = new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.ParamArea();
        obj.paramRequest.area = 1;
        this.cxpService.obtenerMaquinas(obj).then((data) => {
            console.log(data.Objeto);
            this.maquinas = data.Objeto;
        }, (err) => {
            console.warn(err);
        });
    }
    agregarCausa() {
        // console.log('Se agrego un item!');
        this.registroMotivos.push(new src_models_anymodels_model__WEBPACK_IMPORTED_MODULE_2__.RegistroMotivosModel({
            motivo: null,
            minutos: null,
        }));
    }
    prueba(data) {
        console.log(data);
        console.log(this.registroMotivos);
    }
    eliminarRegistro(r) {
        const i = this.registroMotivos.indexOf(r);
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        if (i !== -1) {
            this.registroMotivos.splice(i, 1);
            // this.presentToast('Registro Eliminado.', 2000, 'medium');
        }
    }
    presentToast(mensaje, duracion, tcolor) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje, duration: duracion, color: tcolor
            });
            yield toast.present();
        });
    }
    dismissData() {
        this.modalController.dismiss(this.registroMotivos);
    }
    dismiss() {
        this.modalController.dismiss();
    }
};
ModalRegistroCausaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavParams },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_3__.CxpService }
];
ModalRegistroCausaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-modal-registro-causa',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_registro_causa_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_modal_registro_causa_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalRegistroCausaComponent);



/***/ }),

/***/ 4712:
/*!******************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/modal-registro-parada/modal-registro-parada.component.ts ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalRegistroParadaComponent": () => (/* binding */ ModalRegistroParadaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_registro_parada_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./modal-registro-parada.component.html */ 79225);
/* harmony import */ var _modal_registro_parada_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-registro-parada.component.scss */ 4054);
/* harmony import */ var _modal_registro_causa_modal_registro_causa_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-registro-causa/modal-registro-causa.component */ 66072);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! uuid */ 62230);
/* harmony import */ var _providers_internal_maquinas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../providers/internal/maquinas.service */ 34530);
/* harmony import */ var _providers_internal_motivos_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../providers/internal/motivos.service */ 24854);
/* harmony import */ var _models_anymodels_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../models/anymodels.model */ 58301);
/* harmony import */ var _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../../providers/internal/cxp.service */ 1743);











let ModalRegistroParadaComponent = class ModalRegistroParadaComponent {
    constructor(navParams, modalController, maquinasService, motivosService, cxpService) {
        this.navParams = navParams;
        this.modalController = modalController;
        this.maquinasService = maquinasService;
        this.motivosService = motivosService;
        this.cxpService = cxpService;
        this.registro = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_5__.RegistroParadaModel();
        if (navParams.get('parada') !== undefined) {
            this.registro = navParams.get('parada');
        }
    }
    get validacionDatos() {
        var _a;
        // console.log(this.registro);
        if (
        // this.registro.maquina     === undefined ||
        this.registro.supervisor === undefined ||
            this.registro.fecha === undefined ||
            this.registro.turno === undefined ||
            ((_a = this.registro.motivos) === null || _a === void 0 ? void 0 : _a.length) < 0 ||
            this.registro.observacion === undefined) {
            return true;
        }
        else {
            return false;
        }
    }
    ngOnInit() {
        this.maquinas = this.maquinasService.getMaquinas();
        this.motivos = this.motivosService.getMotivos();
        this.registro.fecha = new Date();
        this.obtenerSupervisores();
    }
    presentModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modal_registro_causa_modal_registro_causa_component__WEBPACK_IMPORTED_MODULE_2__.ModalRegistroCausaComponent,
                componentProps: {
                    motivos: this.registro.motivos,
                }
            });
            modal.onDidDismiss().then((data) => {
                var _a;
                // console.log(data);
                if (data.data === undefined) {
                    // console.log('Sin Datos');
                }
                else {
                    this.registro.motivos = data.data;
                    this.registro.nroMotivos = (_a = this.registro.motivos) === null || _a === void 0 ? void 0 : _a.length;
                }
            });
            yield modal.present();
        });
    }
    dismiss() {
        this.modalController.dismiss();
    }
    dismissData() {
        if (this.registro.uid === undefined) {
            this.registro.uid = (0,uuid__WEBPACK_IMPORTED_MODULE_8__.default)();
        }
        this.modalController.dismiss(this.registro);
    }
    onClick() {
        // console.log(this.registro);
    }
    // Servicios
    obtenerSupervisores() {
        const obj = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_5__.ParamRequest();
        obj.paramRequest = new _models_anymodels_model__WEBPACK_IMPORTED_MODULE_5__.ParamSupervisores();
        obj.paramRequest.area = 1;
        obj.paramRequest.empresa = 'CXP';
        this.cxpService.obtenerSupervisadores(obj).then((data) => {
            this.listaSupervisores = data.Objeto;
        }, err => {
            console.warn(err);
        });
    }
};
ModalRegistroParadaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavParams },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _providers_internal_maquinas_service__WEBPACK_IMPORTED_MODULE_3__.MaquinasService },
    { type: _providers_internal_motivos_service__WEBPACK_IMPORTED_MODULE_4__.MotivosService },
    { type: _providers_internal_cxp_service__WEBPACK_IMPORTED_MODULE_6__.CxpService }
];
ModalRegistroParadaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-modal-registro-parada',
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_registro_parada_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_modal_registro_parada_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalRegistroParadaComponent);



/***/ }),

/***/ 3827:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/menu-registro-paradas/menu-registro-paradas.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuRegistroParadasComponent": () => (/* binding */ MenuRegistroParadasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_menu_registro_paradas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./menu-registro-paradas.component.html */ 42725);
/* harmony import */ var _menu_registro_paradas_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menu-registro-paradas.component.css */ 88800);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../providers/internal/auth0.service */ 32747);
/* harmony import */ var _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../providers/external/security.service */ 46691);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 76491);
/* harmony import */ var _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../providers/external/tools.service */ 859);











let MenuRegistroParadasComponent = class MenuRegistroParadasComponent {
    constructor(menu, route, auth, auth0Serv, securityService, toolService) {
        this.menu = menu;
        this.route = route;
        this.auth = auth;
        this.auth0Serv = auth0Serv;
        this.securityService = securityService;
        this.toolService = toolService;
        this.enabled = {
            rgp01: false,
            rgp02: false,
        };
        this.showThisContent$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject({});
    }
    ngOnInit() {
        // console.log('RegistroParadas menu works');
    }
    ngAfterViewInit() {
        this.toolService.simpleLoader('Cargando...');
        this.obtenerRoles();
    }
    obtenerRoles() {
        this.auth.user$.subscribe((user) => {
            this.auth0Serv.getAuth().then((resp) => {
                const userdata = {
                    idToken: resp.access_token,
                    idUser: user.sub,
                };
                const datarest = this.securityService.encrypt(JSON.stringify(userdata));
                this.auth0Serv.getUserRoles(datarest).then((restuser) => {
                    this.showThisContent$.next({ datauser: restuser.app_metadata.roles });
                    this.habilitarModulos();
                }, (err) => {
                });
            }, (err) => {
            }).finally(() => this.toolService.dismissLoader());
        });
    }
    menuToogle() {
        this.menu.toggle();
    }
    irRegistroParadasCoembal() {
        this.route.navigateByUrl('/pages/registro-paradas/rgp-coembal');
    }
    irRegistroParadasCoexpan() {
        this.route.navigateByUrl('/pages/registro-paradas/rgp-coexpan');
    }
    habilitarModulos() {
        const rgp01 = this.showThisContent$.value.datauser.find((el) => el.id === 'rgp01' && el.enabled === true);
        const rgp02 = this.showThisContent$.value.datauser.find((el) => el.id === 'rgp02' && el.enabled === true);
        if (rgp01 !== undefined) {
            this.enabled.rgp01 = true;
        }
        if (rgp02 !== undefined) {
            this.enabled.rgp02 = true;
        }
    }
};
MenuRegistroParadasComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__.AuthService },
    { type: _providers_internal_auth0_service__WEBPACK_IMPORTED_MODULE_2__.Auth0Service },
    { type: _providers_external_security_service__WEBPACK_IMPORTED_MODULE_3__.SecurityService },
    { type: _providers_external_tools_service__WEBPACK_IMPORTED_MODULE_4__.ToolService }
];
MenuRegistroParadasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        template: _D_Coexpan_Area_TI_VisualStudioCode_app_movil_app_ionic_corporativo_node_modules_ngtools_webpack_src_loaders_direct_resource_js_menu_registro_paradas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_menu_registro_paradas_component_css__WEBPACK_IMPORTED_MODULE_1__]
    })
], MenuRegistroParadasComponent);



/***/ }),

/***/ 98280:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/registro-paradas-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroParadasRoutingModule": () => (/* binding */ RegistroParadasRoutingModule),
/* harmony export */   "registroParadasRouterComponents": () => (/* binding */ registroParadasRouterComponents)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _cmb_registro_paradas_cmb_registro_paradas_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cmb-registro-paradas/cmb-registro-paradas.component */ 7341);
/* harmony import */ var _auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @auth0/auth0-angular */ 70751);
/* harmony import */ var _cxp_registro_paradas_cxp_registro_paradas_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cxp-registro-paradas/cxp-registro-paradas.component */ 52308);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _cmb_extrusion_registro_paradas_registro_paradas_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../cmb-extrusion/registro-paradas/registro-paradas.component */ 53682);
/* harmony import */ var _menu_registro_paradas_menu_registro_paradas_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./menu-registro-paradas/menu-registro-paradas.component */ 3827);
/* harmony import */ var _cmb_registro_paradas_cmb_modal_registro_parada_cmb_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cmb-registro-paradas/cmb-modal-registro-parada/cmb-modal-registro-parada.component */ 69011);
/* harmony import */ var _cxp_registro_paradas_modal_registro_parada_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cxp-registro-paradas/modal-registro-parada/modal-registro-parada.component */ 4712);
/* harmony import */ var _cmb_registro_paradas_cmb_modal_registro_parada_cmb_modal_registro_causa_cmb_modal_registro_causa_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cmb-registro-paradas/cmb-modal-registro-parada/cmb-modal-registro-causa/cmb-modal-registro-causa.component */ 1613);
/* harmony import */ var _cxp_registro_paradas_modal_registro_parada_modal_registro_causa_modal_registro_causa_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./cxp-registro-paradas/modal-registro-parada/modal-registro-causa/modal-registro-causa.component */ 66072);












const routes = [{
        path: '',
        component: _cmb_extrusion_registro_paradas_registro_paradas_component__WEBPACK_IMPORTED_MODULE_2__.RegistroParadasComponent,
        children: [
            {
                path: 'menu',
                component: _menu_registro_paradas_menu_registro_paradas_component__WEBPACK_IMPORTED_MODULE_3__.MenuRegistroParadasComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__.AuthGuard],
            },
            {
                path: 'rgp-coembal',
                component: _cmb_registro_paradas_cmb_registro_paradas_component__WEBPACK_IMPORTED_MODULE_0__.CmbRegistroParadasComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__.AuthGuard],
            },
            {
                path: 'rgp-coexpan',
                component: _cxp_registro_paradas_cxp_registro_paradas_component__WEBPACK_IMPORTED_MODULE_1__.CxpRegistroParadasComponent,
                canActivate: [_auth0_auth0_angular__WEBPACK_IMPORTED_MODULE_8__.AuthGuard],
            }
        ]
    }];
let RegistroParadasRoutingModule = class RegistroParadasRoutingModule {
};
RegistroParadasRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule]
    })
], RegistroParadasRoutingModule);

const registroParadasRouterComponents = [
    _cmb_extrusion_registro_paradas_registro_paradas_component__WEBPACK_IMPORTED_MODULE_2__.RegistroParadasComponent,
    _menu_registro_paradas_menu_registro_paradas_component__WEBPACK_IMPORTED_MODULE_3__.MenuRegistroParadasComponent,
    _cmb_registro_paradas_cmb_registro_paradas_component__WEBPACK_IMPORTED_MODULE_0__.CmbRegistroParadasComponent,
    _cmb_registro_paradas_cmb_modal_registro_parada_cmb_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_4__.CmbModalRegistroParadaComponent,
    _cmb_registro_paradas_cmb_modal_registro_parada_cmb_modal_registro_causa_cmb_modal_registro_causa_component__WEBPACK_IMPORTED_MODULE_6__.CmbModalRegistroCausaComponent,
    _cxp_registro_paradas_cxp_registro_paradas_component__WEBPACK_IMPORTED_MODULE_1__.CxpRegistroParadasComponent,
    _cxp_registro_paradas_modal_registro_parada_modal_registro_parada_component__WEBPACK_IMPORTED_MODULE_5__.ModalRegistroParadaComponent,
    _cxp_registro_paradas_modal_registro_parada_modal_registro_causa_modal_registro_causa_component__WEBPACK_IMPORTED_MODULE_7__.ModalRegistroCausaComponent,
];


/***/ }),

/***/ 98367:
/*!***************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/registro-paradas.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroParadasModule": () => (/* binding */ RegistroParadasModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _registro_paradas_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-paradas-routing.module */ 98280);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ionic-selectable */ 74068);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);







let RegistroParadasModule = class RegistroParadasModule {
};
RegistroParadasModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _registro_paradas_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegistroParadasRoutingModule,
        ],
        declarations: [
            ..._registro_paradas_routing_module__WEBPACK_IMPORTED_MODULE_0__.registroParadasRouterComponents
        ]
    })
], RegistroParadasModule);



/***/ }),

/***/ 97326:
/*!*************************************!*\
  !*** ./src/models/maquina.model.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaquinaModel": () => (/* binding */ MaquinaModel)
/* harmony export */ });
class MaquinaModel {
    constructor(maquina) {
        this.id = maquina.id;
        this.nombre = maquina.nombre;
        this.familia = maquina.familia;
    }
}


/***/ }),

/***/ 37462:
/*!************************************!*\
  !*** ./src/models/motivo.model.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MotivoModel": () => (/* binding */ MotivoModel),
/* harmony export */   "SegmentoModel": () => (/* binding */ SegmentoModel)
/* harmony export */ });
class MotivoModel {
    // segmentos: SegmentoModel[];
    constructor(motivo) {
        this.id = motivo.id;
        this.descripcion = motivo.descripcion;
        // this.segmentos = motivo.segmentos;
    }
}
class SegmentoModel {
    constructor(segmento) {
        this.id = segmento.id;
        this.descripcion = segmento.descripcion;
    }
}


/***/ }),

/***/ 34530:
/*!****************************************************!*\
  !*** ./src/providers/internal/maquinas.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaquinasService": () => (/* binding */ MaquinasService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/models/maquina.model */ 97326);



let MaquinasService = class MaquinasService {
    constructor() {
        this.maquinas = [
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 1, nombre: 'ETIQ.11', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 2, nombre: 'ETIQ.12', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 3, nombre: 'ETIQ.13', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 4, nombre: 'ETIQ.18', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 5, nombre: 'ETIQ.N1', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 6, nombre: 'ETIQ.N2', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 7, nombre: 'ETIQ.N3', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 8, nombre: 'ETIQ.N4', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 9, nombre: 'ETIQ.N4', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 10, nombre: 'ETIQ.N5', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 11, nombre: 'ETIQ.N6', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 12, nombre: 'ETIQ.N7', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 13, nombre: 'ETIQ.N8', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 14, nombre: 'PERFORADORA', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 15, nombre: 'ROBOT-1', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 16, nombre: 'SIROPACK', familia: 'Etiquetado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 17, nombre: 'ETIQ.10', familia: 'Etiquetado Bod 2260' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 18, nombre: 'MOBAPACK', familia: 'Etiquetado Bod 2260' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 19, nombre: 'S.O.S.', familia: 'Etiquetado Bod 2260' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 20, nombre: 'SERVITAL MANUAL', familia: 'Etiquetado Bod 2260' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 21, nombre: 'TALLER CMB', familia: 'Etiquetado Bod 2260' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 22, nombre: 'DM-44', familia: 'Impresión' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 23, nombre: 'POLITYPE', familia: 'Impresión' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 24, nombre: 'VD-560(1)', familia: 'Impresión' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 25, nombre: 'VD560L-3', familia: 'Impresión' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 26, nombre: 'VDCM-608', familia: 'Impresión' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 27, nombre: 'PERFORADORA', familia: 'Perforado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 28, nombre: 'REB N1', familia: 'Rebordeado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 29, nombre: '45-2', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 30, nombre: '45-3', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 31, nombre: '50K-1', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 32, nombre: '50K-2', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 33, nombre: '54K-1', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 34, nombre: '54KC', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 35, nombre: '70K-2', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 36, nombre: '70k-3', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 37, nombre: 'KIEFEL-1', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 38, nombre: 'KIEFEL-2', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 39, nombre: 'KIEFEL-3', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 41, nombre: 'KIEFEL-4', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 42, nombre: 'KIEFEL-5', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 43, nombre: 'KTR4-2', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 44, nombre: 'KTR4-3', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 45, nombre: 'KTR4-4', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 46, nombre: 'KTR4-5PP', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 47, nombre: 'RDM/1', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 48, nombre: 'RDM/2', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 49, nombre: 'RDM/3', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 50, nombre: 'RDM/6', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 51, nombre: 'RDM/63', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 52, nombre: 'RDM58-3', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 53, nombre: 'SWING 6005', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 54, nombre: 'SWING 6053', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 55, nombre: 'SWING 6054', familia: 'Termoformado' }),
            new src_models_maquina_model__WEBPACK_IMPORTED_MODULE_0__.MaquinaModel({ id: 56, nombre: 'TR-4', familia: 'Termoformado' })
        ];
    }
    getMaquinas() {
        return this.maquinas;
    }
};
MaquinasService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root',
    })
], MaquinasService);



/***/ }),

/***/ 24854:
/*!***************************************************!*\
  !*** ./src/providers/internal/motivos.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MotivosService": () => (/* binding */ MotivosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/motivo.model */ 37462);



let MotivosService = class MotivosService {
    constructor() {
        this.motivos = [
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 1, descripcion: 'Producción' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 2, descripcion: 'Pruebas' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 3, descripcion: 'Control de Calidad' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 4, descripcion: 'Regulación de Máquina' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 5, descripcion: 'Problemas de Producción' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 6, descripcion: 'Falta de Operario' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 7, descripcion: 'Cambio de Programa' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 8, descripcion: 'Falla Electrica' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 9, descripcion: 'Falla Mecánica' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 10, descripcion: 'Mantención Programada' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 11, descripcion: 'Parada Programada' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 12, descripcion: 'Máquina sin Programa' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 13, descripcion: 'Cambio de Bobina' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 14, descripcion: 'Problema de Corte' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 15, descripcion: 'Mantención Matriceria' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 16, descripcion: 'Detenida sin Lámina' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 17, descripcion: 'Problema de Lámina' }),
            new _models_motivo_model__WEBPACK_IMPORTED_MODULE_0__.MotivoModel({ id: 18, descripcion: 'Falla Equipo Suplementario' }),
        ];
    }
    getMotivos() {
        return this.motivos;
    }
};
MotivosService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], MotivosService);



/***/ }),

/***/ 25707:
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-modal-registro-parada/cmb-modal-registro-causa/cmb-modal-registro-causa.component.html ***!
  \*******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button color=\"primary\" expand=\"block\" fill=\"clear\" (click)=\"dismiss()\">\r\n        Cerrar\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title color=\"medium\"><strong>Registro de Causas</strong></ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-item *ngIf=\"registroMotivos.length <= 0\" class=\"ion-padding-top\">\r\n    <ion-label color=\"medium\"><strong>Sin Causas Registradas.</strong></ion-label>\r\n  </ion-item>\r\n\r\n  <ion-list class=\"\">\r\n      <ion-item-sliding *ngFor=\"let i of registroMotivos; let n = index\">\r\n        <ion-item>\r\n          <ion-grid fixed>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <ion-label color=\"medium\"><strong>Causa {{n+1}}</strong></ion-label>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row class=\"ion-justify-content-between\">\r\n              <ion-col size=\"5\" #colmotivo>\r\n                <ion-item>\r\n                  <ionic-selectable id=\"motivos-{{i}}\" #pmotivos item-content itemValueField=\"Id\" itemTextField=\"DetalleMotivo\" [items]=\"motivos\" [canSearch]=\"true\" [(ngModel)]=\"i.motivo\" placeholder=\"Seleccione...\" required>\r\n                  </ionic-selectable>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col size=\"5\" *ngIf=\"i.motivo\" >\r\n                <ion-item *ngIf=\"i.motivo.Segmentos.length > 1\">\r\n                  <ionic-selectable id=\"segmento-{{i}}\" item-content itemValueField=\"Id\" itemTextField=\"DetalleSegmento\" [items]=\"i.motivo.Segmentos\" [canSearch]=\"true\"\r\n                    [(ngModel)]=\"i.segmento\" placeholder=\"Seleccione...\" (ngModelChange)=\"prueba(colmotivo)\" required>\r\n                  </ionic-selectable>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col size=\"2\">\r\n                <ion-input type=\"number\" placeholder=\"Min.\" [(ngModel)]=\"i.minutos\" required>\r\n                </ion-input>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <ion-item>\r\n                  <ionic-selectable id=\"maquinas-{{i}}\" #pmaquinas item-content itemValueField=\"ID\" itemTextField=\"NOMBRE\"\r\n                    [items]=\"maquinas\" [canSearch]=\"true\" [(ngModel)]=\"i.maquina\" placeholder=\"Seleccione...\" required>\r\n                  </ionic-selectable>\r\n                </ion-item>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n        </ion-item>\r\n\r\n        <ion-item-options side=\"end\">\r\n          <ion-item-option (click)=\"eliminarRegistro(i)\" color=\"terteary\">\r\n            <ion-icon style=\"font-size: 2.5rem;\" color=\"danger\" name=\"trash-outline\"></ion-icon>\r\n          </ion-item-option>\r\n        </ion-item-options>\r\n      </ion-item-sliding>\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-justify-content-between\">\r\n        <ion-col size=\"8\">\r\n          <ion-button color=\"success\" expand=\"block\" fill=\"outline\" (click)=\"dismissData()\">\r\n            Confirmar\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n          <ion-button color=\"primary\" expand=\"block\" fill=\"outline\"\r\n          (click)=\"agregarCausa()\" class=\"ion-no-padding\">\r\n            <ion-icon  name=\"add\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ }),

/***/ 37133:
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-modal-registro-parada/cmb-modal-registro-parada.component.html ***!
  \*******************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button color=\"primary\" expand=\"block\" fill=\"clear\" (click)=\"dismiss()\">\r\n        Cerrar\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title color=\"medium\"><strong>Registro Parada</strong></ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n\r\n  <ion-item-divider class=\"ion-padding-top\">\r\n  </ion-item-divider>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\"><strong>Area</strong></ion-label>\r\n    <ion-select #area (ionChange)=\"obtenerSupervisores(area.value)\" [(ngModel)]=\"registro.area\" value=\"1\">\r\n      <ion-select-option value=\"2\">Termoformado</ion-select-option>\r\n      <ion-select-option value=\"3\">Impresión</ion-select-option>\r\n      <ion-select-option value=\"4\">Etiquetado</ion-select-option>\r\n      <ion-select-option value=\"5\">Rebordeado</ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <ion-item [attr.disabled]=\"!listaSupervisores\">\r\n    <ion-label color=\"medium\"><strong>Supervisor</strong></ion-label>\r\n    <ion-select [(ngModel)]=\"registro.supervisor\" itemValueField=\"id\" placeholder=\"Selecciona Uno\" required>\r\n      <ion-select-option *ngFor=\"let i of listaSupervisores\" value=\"{{i.ID}}\">{{i.NOMBRE}}</ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\"><strong>Fecha</strong></ion-label>\r\n    <ion-datetime-button ngDefaultControl [(ngModel)]=\"registro.fecha\"  datetime=\"datetime\"></ion-datetime-button>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\"><strong>Turno</strong></ion-label>\r\n    <ion-select [(ngModel)]=\"registro.turno\" placeholder=\"Seleccione Uno\" required>\r\n      <ion-select-option value=\"T1\">Turno 1</ion-select-option>\r\n      <ion-select-option value=\"T2\">Turno 2</ion-select-option>\r\n      <ion-select-option value=\"T3\">Turno 3</ion-select-option>\r\n      <ion-select-option value=\"T20\">Turno 20</ion-select-option>\r\n      <ion-select-option value=\"T21\">Turno 21</ion-select-option>\r\n      <ion-select-option value=\"T24\">Turno 24</ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <ion-item button (click)=\"presentModal()\" [attr.disabled]=\"!listaSupervisores\">\r\n    <ion-label color=\"medium\"><strong>Motivos</strong></ion-label>\r\n    <ion-label color=\"medium\" slot=\"end\"><strong>{{registro.motivos?.length}}</strong></ion-label>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\" position=\"floating\"><strong>Observación</strong></ion-label>\r\n    <ion-textarea [(ngModel)]=\"registro.observacion\" required></ion-textarea>\r\n  </ion-item>\r\n\r\n</ion-content>\r\n\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-justify-content-center\">\r\n        <ion-col size=\"8\" *ngIf=\"!registro.uid\">\r\n          <ion-button color=\"success\" [disabled]=\"validacionDatos\" expand=\"block\" fill=\"outline\"\r\n          (click)=\"dismissData()\">\r\n            Registrar\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" *ngIf=\"registro.uid\">\r\n          <ion-button color=\"success\" [disabled]=\"validacionDatos\" expand=\"block\" fill=\"outline\" (click)=\"dismissData()\" >\r\n            Modificar\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n\r\n<ion-modal [keepContentsMounted]=\"true\">\r\n  <ng-template>\r\n    <ion-datetime id=\"datetime\"></ion-datetime>\r\n  </ng-template>\r\n</ion-modal>\r\n");

/***/ }),

/***/ 59962:
/*!************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-registro-paradas.component.html ***!
  \************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button color=\"primary\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title color=\"medium\"><strong>Reg. Paradas Coembal</strong></ion-title>\r\n  </ion-toolbar>\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-justify-content-center\">\r\n      <ion-col size=\"12\">\r\n        <ion-progress-bar color=\"medium\"></ion-progress-bar>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"ion-justify-content-center\">\r\n      <ion-col size=\"7\">\r\n        <ion-button expand=\"block\" (click)=\"presentModal()\">\r\n          Nueva Causa\r\n          <ion-icon slot=\"end\" name=\"add\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-item-sliding *ngFor=\"let r of registros\" >\r\n      <ion-item (click)=\"modificarDatos(r)\">\r\n        <ion-label color=\"medium\"><strong>\r\n          {{obtenerArea(r.area)}} - Motivos: {{r.motivos?.length}}\r\n        </strong></ion-label>\r\n        <ion-button slot=\"end\" color =\"medium\" expand=\"block\" shape=\"round\"\r\n        (click)=\"alertaInformacionParada(r)\">\r\n          Info.\r\n        </ion-button>\r\n      </ion-item>\r\n      <ion-item-options side=\"end\">\r\n        <ion-item-option color=\"terteary\" (click)=\"eliminarRegistro(r)\">\r\n          <ion-icon style=\"font-size: 2.5rem;\" color=\"danger\" name=\"trash-outline\"></ion-icon>\r\n        </ion-item-option>\r\n      </ion-item-options>\r\n    </ion-item-sliding>\r\n  </ion-list>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-justify-content-center\">\r\n        <ion-col size=\"8\">\r\n          <ion-button color=\"success\" expand=\"block\" fill=\"outline\" (click)=\"enviarRegistros()\">\r\n            Enviar Registros\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ }),

/***/ 25757:
/*!************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/cxp-registro-paradas.component.html ***!
  \************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button color=\"primary\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title color=\"medium\"><strong>Reg. Paradas Coexpan</strong></ion-title>\r\n  </ion-toolbar>\r\n  <ion-grid fixed>\r\n    <ion-row class=\"ion-justify-content-center\">\r\n      <ion-col size=\"12\">\r\n        <ion-progress-bar color=\"medium\"></ion-progress-bar>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"ion-justify-content-center\">\r\n      <ion-col size=\"7\">\r\n        <ion-button expand=\"block\" (click)=\"presentModal()\">\r\n          Nueva Causa\r\n          <ion-icon slot=\"end\" name=\"add\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-item-sliding *ngFor=\"let r of registros\" >\r\n      <ion-item (click)=\"modificarDatos(r)\">\r\n        <ion-label color=\"medium\"><strong>\r\n          {{obtenerArea(r.area)}} - Motivos: {{r.motivos?.length}}\r\n        </strong></ion-label>\r\n        <ion-button slot=\"end\" color =\"medium\" expand=\"block\" shape=\"round\"\r\n        (click)=\"alertaInformacionParada(r)\">\r\n          Info.\r\n        </ion-button>\r\n      </ion-item>\r\n      <ion-item-options side=\"end\">\r\n        <ion-item-option color=\"terteary\" (click)=\"eliminarRegistro(r)\">\r\n          <ion-icon style=\"font-size: 2.5rem;\" color=\"danger\" name=\"trash-outline\"></ion-icon>\r\n        </ion-item-option>\r\n      </ion-item-options>\r\n    </ion-item-sliding>\r\n  </ion-list>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-justify-content-center\">\r\n        <ion-col size=\"8\">\r\n          <ion-button color=\"success\" expand=\"block\" fill=\"outline\" (click)=\"enviarRegistros()\">\r\n            Enviar Registros\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ }),

/***/ 90757:
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/modal-registro-parada/modal-registro-causa/modal-registro-causa.component.html ***!
  \*******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button color=\"primary\" expand=\"block\" fill=\"clear\" (click)=\"dismiss()\">\r\n        Cerrar\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title color=\"medium\"><strong>Registro de Causas</strong></ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-item *ngIf=\"registroMotivos.length <= 0\" class=\"ion-padding-top\">\r\n    <ion-label color=\"medium\"><strong>Sin Causas Registradas.</strong></ion-label>\r\n  </ion-item>\r\n\r\n  <ion-list class=\"\">\r\n      <ion-item-sliding *ngFor=\"let i of registroMotivos; let n = index\">\r\n        <ion-item>\r\n          <ion-grid fixed>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <ion-label color=\"medium\"><strong>Causa {{n+1}}</strong></ion-label>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row class=\"ion-justify-content-between\">\r\n              <ion-col size=\"5\" #colmotivo>\r\n                <ion-item>\r\n                  <ionic-selectable id=\"motivos-{{i}}\" #pmotivos item-content itemValueField=\"Id\" itemTextField=\"DetalleMotivo\" [items]=\"motivos\" [canSearch]=\"true\" [(ngModel)]=\"i.motivo\" placeholder=\"Seleccione...\" required>\r\n                  </ionic-selectable>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col size=\"5\" *ngIf=\"i.motivo\" >\r\n                <ion-item *ngIf=\"i.motivo.Segmentos.length > 1\">\r\n                  <ionic-selectable id=\"segmento-{{i}}\" item-content itemValueField=\"Id\" itemTextField=\"DetalleSegmento\" [items]=\"i.motivo.Segmentos\" [canSearch]=\"true\"\r\n                    [(ngModel)]=\"i.segmento\" placeholder=\"Seleccione...\" (ngModelChange)=\"prueba(colmotivo)\" required>\r\n                  </ionic-selectable>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col size=\"2\">\r\n                <ion-input type=\"number\" placeholder=\"Min.\" [(ngModel)]=\"i.minutos\" required>\r\n                </ion-input>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <ion-item>\r\n                  <ionic-selectable id=\"maquinas-{{i}}\" #pmaquinas item-content itemValueField=\"ID\" itemTextField=\"NOMBRE\"\r\n                    [items]=\"maquinas\" [canSearch]=\"true\" [(ngModel)]=\"i.maquina\" placeholder=\"Seleccione...\" required>\r\n                  </ionic-selectable>\r\n                </ion-item>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n        </ion-item>\r\n\r\n        <ion-item-options side=\"end\">\r\n          <ion-item-option (click)=\"eliminarRegistro(i)\" color=\"terteary\">\r\n            <ion-icon style=\"font-size: 2.5rem;\" color=\"danger\" name=\"trash-outline\"></ion-icon>\r\n          </ion-item-option>\r\n        </ion-item-options>\r\n      </ion-item-sliding>\r\n  </ion-list>\r\n\r\n\r\n</ion-content>\r\n\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-justify-content-between\">\r\n        <ion-col size=\"8\">\r\n          <ion-button color=\"success\" expand=\"block\" fill=\"outline\" (click)=\"dismissData()\">\r\n            Confirmar\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"2\">\r\n          <ion-button color=\"primary\" expand=\"block\" fill=\"outline\"\r\n          (click)=\"agregarCausa()\" class=\"ion-no-padding\">\r\n            <ion-icon  name=\"add\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n");

/***/ }),

/***/ 79225:
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/modal-registro-parada/modal-registro-parada.component.html ***!
  \***********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button color=\"primary\" expand=\"block\" fill=\"clear\" (click)=\"dismiss()\">\r\n        Cerrar\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title color=\"medium\"><strong>Registro Parada</strong></ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n\r\n  <ion-item-divider class=\"ion-padding-top\">\r\n  </ion-item-divider>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\"><strong>Area</strong></ion-label>\r\n    <ion-select [(ngModel)]=\"registro.area\" value=\"1\">\r\n      <ion-select-option value=\"1\">Extrusión</ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\"><strong>Supervisor</strong></ion-label>\r\n    <ion-select [(ngModel)]=\"registro.supervisor\" itemValueField=\"id\" placeholder=\"Selecciona Uno\" required>\r\n      <ion-select-option *ngFor=\"let i of listaSupervisores\" value=\"{{i.ID}}\">{{i.NOMBRE}}</ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\"><strong>Fecha</strong></ion-label>\r\n    <ion-datetime-button ngDefaultControl [(ngModel)]=\"registro.fecha\" datetime=\"datetime\"></ion-datetime-button>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\"><strong>Turno</strong></ion-label>\r\n    <ion-select [(ngModel)]=\"registro.turno\" placeholder=\"Seleccione Uno\" required>\r\n      <ion-select-option value=\"T1\">Turno 1</ion-select-option>\r\n      <ion-select-option value=\"T2\">Turno 2</ion-select-option>\r\n      <ion-select-option value=\"T3\">Turno 3</ion-select-option>\r\n      <ion-select-option value=\"T20\">Turno 20</ion-select-option>\r\n      <ion-select-option value=\"T21\">Turno 21</ion-select-option>\r\n      <ion-select-option value=\"T24\">Turno 24</ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <ion-item button (click)=\"presentModal()\">\r\n    <ion-label color=\"medium\"><strong>Motivos</strong></ion-label>\r\n    <ion-label color=\"medium\" slot=\"end\"><strong>{{registro.motivos?.length}}</strong></ion-label>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label color=\"medium\" position=\"floating\"><strong>Observación</strong></ion-label>\r\n    <ion-textarea [(ngModel)]=\"registro.observacion\" required></ion-textarea>\r\n  </ion-item>\r\n\r\n</ion-content>\r\n\r\n\r\n<ion-footer>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-justify-content-center\">\r\n        <ion-col size=\"8\" *ngIf=\"!registro.uid\">\r\n          <ion-button color=\"success\" [disabled]=\"validacionDatos\" expand=\"block\" fill=\"outline\"\r\n          (click)=\"dismissData()\">\r\n            Registrar\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"8\" *ngIf=\"registro.uid\">\r\n          <ion-button color=\"success\" [disabled]=\"validacionDatos\" expand=\"block\" fill=\"outline\" (click)=\"dismissData()\" >\r\n            Modificar\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-footer>\r\n\r\n<ion-modal [keepContentsMounted]=\"true\">\r\n  <ng-template>\r\n    <ion-datetime id=\"datetime\"></ion-datetime>\r\n  </ng-template>\r\n</ion-modal>\r\n\r\n\r\n\r\n\r\n");

/***/ }),

/***/ 42725:
/*!**************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coembal/registro-paradas/menu-registro-paradas/menu-registro-paradas.component.html ***!
  \**************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-grid fixed>\r\n      <ion-row class=\"ion-align-items-center ion-header-row\">\r\n        <ion-col size=\"2\">\r\n          <ion-button fill=\"clear\" (click)=\"menuToogle()\">\r\n            <ion-icon name=\"menu-outline\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n        <ion-col size=\"10\" class=\"ion-text-left\">\r\n          <ion-title>Menu Reg. Paradas</ion-title>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content class=\"background-image\">\r\n  <ion-grid>\r\n\r\n    <ion-row class=\"row\">\r\n      <ion-col size=\"12\" *ngIf=\"enabled.rgp01 || enabled.rgp02\">\r\n        <ion-label color=\"medium\"><strong>Registro Paradas</strong></ion-label>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"ion-justify-content-start\">\r\n      <ion-col size=\"6\" *ngIf=\"enabled.rgp01\">\r\n        <ion-button class=\"btn-color-cmb\" shape=\"\" size=\"large\" expand=\"block\" (click)=\"irRegistroParadasCoembal()\">\r\n          <ion-grid>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <span class=\"btn-text\">Reg. Paradas</span>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <span class=\"btn-text\">Coembal</span>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n        </ion-button>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"6\" *ngIf=\"enabled.rgp02\">\r\n        <ion-button class=\"btn-color-cmb\" shape=\"\" size=\"large\" expand=\"block\" (click)=\"irRegistroParadasCoexpan()\">\r\n          <ion-grid>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <span class=\"btn-text\">Reg. Paradas</span>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <span class=\"btn-text\">Coexpan</span>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ 88800:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/menu-registro-paradas/menu-registro-paradas.component.css ***!
  \**********************************************************************************************************/
/***/ ((module) => {

module.exports = ".background-image{\r\n    --background: url('background-login.png') 0 0/100% 100% no-repeat;\r\n}\r\n\r\n.ion-header-row {\r\n  padding-left: 0px;\r\n}\r\n\r\n.btn-text {\r\n  font-size: 0.6em;\r\n  font-weight: 700;\r\n}\r\n\r\n/* .btn-prop {\r\n  --background: #E2A4B5;\r\n} */\r\n\r\n.row {\r\n  margin-top: 2em;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnUtcmVnaXN0cm8tcGFyYWRhcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksaUVBQWlHO0FBQ3JHOztBQUVBO0VBQ0UsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtBQUNsQjs7QUFFQTs7R0FFRzs7QUFFSDtFQUNFLGVBQWU7QUFDakIiLCJmaWxlIjoibWVudS1yZWdpc3Ryby1wYXJhZGFzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmFja2dyb3VuZC1pbWFnZXtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKCcuLi8uLi8uLi8uLi8uLi9hc3NldHMvaW1nL2xvZ2luL2JhY2tncm91bmQtbG9naW4ucG5nJykgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XHJcbn1cclxuXHJcbi5pb24taGVhZGVyLXJvdyB7XHJcbiAgcGFkZGluZy1sZWZ0OiAwcHg7XHJcbn1cclxuXHJcbi5idG4tdGV4dCB7XHJcbiAgZm9udC1zaXplOiAwLjZlbTtcclxuICBmb250LXdlaWdodDogNzAwO1xyXG59XHJcblxyXG4vKiAuYnRuLXByb3Age1xyXG4gIC0tYmFja2dyb3VuZDogI0UyQTRCNTtcclxufSAqL1xyXG5cclxuLnJvdyB7XHJcbiAgbWFyZ2luLXRvcDogMmVtO1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 56979:
/*!****************************************************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-modal-registro-parada/cmb-modal-registro-causa/cmb-modal-registro-causa.component.scss ***!
  \****************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjbWItbW9kYWwtcmVnaXN0cm8tY2F1c2EuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 277:
/*!****************************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-modal-registro-parada/cmb-modal-registro-parada.component.scss ***!
  \****************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjbWItbW9kYWwtcmVnaXN0cm8tcGFyYWRhLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 22873:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cmb-registro-paradas/cmb-registro-paradas.component.scss ***!
  \*********************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjbWItcmVnaXN0cm8tcGFyYWRhcy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 11550:
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/cxp-registro-paradas.component.scss ***!
  \*********************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjeHAtcmVnaXN0cm8tcGFyYWRhcy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 27601:
/*!****************************************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/modal-registro-parada/modal-registro-causa/modal-registro-causa.component.scss ***!
  \****************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1yZWdpc3Ryby1jYXVzYS5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 4054:
/*!********************************************************************************************************************************!*\
  !*** ./src/app/pages/coembal/registro-paradas/cxp-registro-paradas/modal-registro-parada/modal-registro-parada.component.scss ***!
  \********************************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1yZWdpc3Ryby1wYXJhZGEuY29tcG9uZW50LnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coembal_registro-paradas_registro-paradas_module_ts.js.map