"use strict";
(self["webpackChunkapp_ionic_corporativo"] = self["webpackChunkapp_ionic_corporativo"] || []).push([["src_app_pages_pages_module_ts"],{

/***/ 39730:
/*!***********************************************!*\
  !*** ./src/app/pages/pages-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PagesRoutingModule": () => (/* binding */ PagesRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _pages_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages.component */ 37664);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);




const routes = [{
        path: '',
        component: _pages_component__WEBPACK_IMPORTED_MODULE_0__.PagesComponent,
        children: [
            {
                path: 'root',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_root_root_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./root/root.module */ 10480))
                    .then(m => m.RootModule),
            },
            {
                path: 'materias-primas',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_coembal_materias-primas_materias-primas_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./coembal/materias-primas/materias-primas.module */ 11947))
                    .then(m => m.MateriasPrimasModule)
            },
            {
                path: 'inventario',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_coembal_inventario_inventario_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./coembal/inventario/inventario.module */ 43538))
                    .then(m => m.InventarioModule)
            },
            {
                path: 'registro-paradas',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_coembal_registro-paradas_registro-paradas_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./coembal/registro-paradas/registro-paradas.module */ 98367))
                    .then(m => m.RegistroParadasModule)
            },
            {
                path: 'entrada-mercancia',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_coembal_entrada-mercancia_entrada-mercancia_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./coembal/entrada-mercancia/entrada-mercancia.module */ 93846))
                    .then(m => m.EntradaMercanciaModule)
            },
            {
                path: '',
                redirectTo: 'root',
                pathMatch: 'full',
            }
        ]
    }];
let PagesRoutingModule = class PagesRoutingModule {
};
PagesRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PagesRoutingModule);



/***/ }),

/***/ 37664:
/*!******************************************!*\
  !*** ./src/app/pages/pages.component.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PagesComponent": () => (/* binding */ PagesComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);


let PagesComponent = class PagesComponent {
    constructor() { }
    ngOnInit() { }
};
PagesComponent.ctorParameters = () => [];
PagesComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'app-pages',
        template: '<ion-router-outlet></ion-router-outlet>'
    })
], PagesComponent);



/***/ }),

/***/ 18950:
/*!***************************************!*\
  !*** ./src/app/pages/pages.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PagesModule": () => (/* binding */ PagesModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _pages_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages-routing.module */ 39730);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _pages_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages.component */ 37664);





let PagesModule = class PagesModule {
};
PagesModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _pages_routing_module__WEBPACK_IMPORTED_MODULE_0__.PagesRoutingModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
        ],
        exports: [],
        declarations: [
            _pages_component__WEBPACK_IMPORTED_MODULE_1__.PagesComponent,
        ]
    })
], PagesModule);



/***/ })

}]);
//# sourceMappingURL=src_app_pages_pages_module_ts.js.map